'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Key, 
  Plus, 
  Search, 
  RefreshCw, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  XCircle,
  Shield, 
  Activity,
  Copy,
  Check
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import AdminNav from '@/components/AdminNav';
import { useAppContext } from '@/lib/AppContext';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  alert(`Failed to save data: ${errInfo.error}`);
}

export default function AdminKeysPage() {
  const { isAdmin, isLoadingAuth } = useAppContext();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [keys, setKeys] = useState<any[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyValue, setNewKeyValue] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('Google Gemini');
  const [isAdding, setIsAdding] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);

  useEffect(() => {
    if (!isAdmin || !db) {
      setIsLoadingData(false);
      return;
    }

    const unsubscribe = onSnapshot(collection(db, 'apiKeys'), (snapshot) => {
      const keysData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setKeys(keysData);
      setIsLoadingData(false);
    }, (error) => {
      console.error("Snapshot error:", error);
      setIsLoadingData(false);
    });

    return () => unsubscribe();
  }, [isAdmin]);

  const handleAddKey = async () => {
    if (!db) {
      alert('Database is not initialized. Please check your Firebase configuration.');
      return;
    }

    if (!newKeyName.trim() || !newKeyValue.trim()) {
      alert('Please enter both a key name and an API key.');
      return;
    }

    setIsAdding(true);
    try {
      await addDoc(collection(db, 'apiKeys'), {
        provider: selectedProvider,
        name: newKeyName,
        key: newKeyValue,
        status: 'Active',
        health: 'Healthy',
        lastUsed: 'Never',
        createdAt: serverTimestamp()
      });
      setNewKeyName('');
      setNewKeyValue('');
      alert('API Key added successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'apiKeys');
    } finally {
      setIsAdding(false);
    }
  };

  const handleDeleteKey = async (id: string) => {
    if (!db) return;
    await deleteDoc(doc(db, 'apiKeys', id));
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (isLoadingAuth || isLoadingData) {
    return (
      <AppLayout title="API Key Management">
        <div className="h-[60vh] flex items-center justify-center">
          <RefreshCw className="animate-spin text-indigo-500" size={32} />
        </div>
      </AppLayout>
    );
  }

  if (!isAdmin) {
    return (
      <AppLayout title="Access Denied">
        <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
          <XCircle className="text-rose-500" size={64} />
          <h2 className="text-2xl font-bold">Unauthorized Access</h2>
          <p className="text-muted-foreground">You do not have permission to view this page.</p>
          <button 
            onClick={() => window.location.href = '/dashboard'}
            className="px-6 py-2 bg-indigo-600 rounded-xl font-bold"
          >
            Back to Dashboard
          </button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="API Key Management">
      <div className="max-w-7xl mx-auto space-y-8">
        <AdminNav />
        <div className="glass p-6 md:p-8 rounded-[2rem] depth-1 border border-white/5 flex flex-col lg:flex-row lg:items-center justify-between gap-8 hover:border-indigo-500/20 transition-all duration-500">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight flex items-center gap-3">
              <Shield className="text-indigo-400" size={28} />
              API Key Rotation
            </h2>
            <p className="text-muted-foreground">Manage and rotate API keys for AI analysis services</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              <input 
                placeholder="Key Name"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                className="bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 outline-none transition-all w-full sm:w-40"
              />
              <select 
                value={selectedProvider}
                onChange={(e) => setSelectedProvider(e.target.value)}
                className="bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 outline-none transition-all w-full sm:w-auto"
              >
                <option value="Google Gemini">Google Gemini</option>
                <option value="Groq">Groq</option>
                <option value="OpenRouter">OpenRouter</option>
                <option value="OpenAI">OpenAI</option>
              </select>
            </div>
            <div className="flex gap-3 w-full sm:w-auto">
              <input 
                placeholder="API Key"
                value={newKeyValue}
                onChange={(e) => setNewKeyValue(e.target.value)}
                className="bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 outline-none transition-all flex-1 sm:w-64"
              />
              <button 
                onClick={handleAddKey}
                disabled={isAdding}
                className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/20 whitespace-nowrap"
              >
                {isAdding ? (
                  <RefreshCw size={16} className="animate-spin" />
                ) : (
                  <Plus size={16} />
                )}
                {isAdding ? 'Adding...' : 'Add Key'}
              </button>
            </div>
          </div>
        </div>

        <div className="glass rounded-3xl depth-1 overflow-hidden">
          <div className="p-8 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-lg font-bold">Managed API Keys</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-white/5 text-muted-foreground uppercase text-[10px] font-bold tracking-widest">
                  <th className="px-8 py-4">Provider / Name</th>
                  <th className="px-8 py-4">Key Preview</th>
                  <th className="px-8 py-4">Status</th>
                  <th className="px-8 py-4">Date Added</th>
                  <th className="px-8 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {keys.map((k) => (
                  <tr key={k.id} className="hover:bg-white/5 transition-colors group">
                    <td className="px-8 py-5">
                      <div>
                        <p className="font-bold text-white">{k.name}</p>
                        <p className="text-xs text-muted-foreground">{k.provider}</p>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-2">
                        <code className="bg-white/5 px-2 py-1 rounded text-xs text-muted-foreground font-mono">
                          {k.key.slice(0, 8)}...
                        </code>
                        <button 
                          onClick={() => handleCopy(k.key, k.id)}
                          className="text-muted-foreground hover:text-white transition-colors"
                        >
                          {copiedId === k.id ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                        </button>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-2">
                        {k.status === 'Active' && <CheckCircle2 size={14} className="text-emerald-400" />}
                        {k.status === 'Exhausted' && <AlertCircle size={14} className="text-amber-400" />}
                        {k.status === 'Disabled' && <XCircle size={14} className="text-rose-400" />}
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border ${
                          k.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                          k.status === 'Exhausted' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                          'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        }`}>
                          {k.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <p className="text-xs text-muted-foreground">
                        {k.createdAt?.toDate ? k.createdAt.toDate().toLocaleString() : 'Pending...'}
                      </p>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button 
                        onClick={() => handleDeleteKey(k.id)}
                        className="p-2 rounded-lg hover:bg-white/10 text-rose-400 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function KeyStatsCard({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) {
  return (
    <div className="glass p-6 rounded-3xl depth-1 border border-white/5 space-y-4">
      <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className="text-2xl font-bold mt-1">{value}</p>
      </div>
    </div>
  );
}

function AdminStatCard({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) {
  return (
    <div className="glass p-6 rounded-3xl depth-1 border border-white/5 space-y-4">
      <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className="text-2xl font-bold mt-1">{value}</p>
      </div>
    </div>
  );
}

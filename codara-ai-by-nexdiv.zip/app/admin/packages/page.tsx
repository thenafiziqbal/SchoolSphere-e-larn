'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Package, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Shield, 
  X,
  Edit2
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import AdminNav from '@/components/AdminNav';
import { useAppContext } from '@/lib/AppContext';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore';

export default function AdminPackagesPage() {
  const { isAdmin, siteConfig } = useAppContext();
  const [packages, setPackages] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPkgId, setEditingPkgId] = useState<string | null>(null);
  
  const [pkgName, setPkgName] = useState('');
  const [pkgPrice, setPkgPrice] = useState('');
  const [pkgBilling, setPkgBilling] = useState('per month');
  const [pkgDailyLimit, setPkgDailyLimit] = useState(10);
  const [pkgMonthlyLimit, setPkgMonthlyLimit] = useState(100);
  const [pkgStatus, setPkgStatus] = useState('Active');
  const [pkgFeatures, setPkgFeatures] = useState('');
  const [pkgDescription, setPkgDescription] = useState('');
  const [pkgIsPopular, setPkgIsPopular] = useState(false);

  useEffect(() => {
    if (!isAdmin || !db) return;

    const unsubscribePackages = onSnapshot(collection(db, 'packages'), async (snapshot) => {
      const pkgsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      
      try {
        // Fetch user counts per package to show real data
        const { getDocs } = await import('firebase/firestore');
        const usersSnapshot = await getDocs(collection(db!, 'users'));
        const planCounts: Record<string, number> = {};
        usersSnapshot.forEach(userDoc => {
          const plan = userDoc.data().plan || 'Free';
          planCounts[plan] = (planCounts[plan] || 0) + 1;
        });

        const pkgsWithCounts = pkgsData.map(pkg => ({
          ...pkg,
          users: planCounts[pkg.name] || 0
        }));

        setPackages(pkgsWithCounts);
      } catch (error) {
        console.error("Error fetching user counts for packages:", error);
        setPackages(pkgsData);
      }
    });

    return () => unsubscribePackages();
  }, [isAdmin]);

  const openModal = (pkg?: any) => {
    if (pkg) {
      setEditingPkgId(pkg.id);
      setPkgName(pkg.name);
      setPkgPrice(pkg.price.toString());
      setPkgBilling(pkg.billing);
      setPkgDailyLimit(pkg.limits?.dailyAnalysis || 10);
      setPkgMonthlyLimit(pkg.limits?.monthlyRequests || 100);
      setPkgStatus(pkg.status || 'Active');
      setPkgFeatures(pkg.features?.join('\n') || '');
      setPkgDescription(pkg.description || '');
      setPkgIsPopular(pkg.isPopular || false);
    } else {
      setEditingPkgId(null);
      setPkgName('');
      setPkgPrice('');
      setPkgBilling('per month');
      setPkgDailyLimit(10);
      setPkgMonthlyLimit(100);
      setPkgStatus('Active');
      setPkgFeatures('');
      setPkgDescription('');
      setPkgIsPopular(false);
    }
    setIsModalOpen(true);
  };

  const handleSavePackage = async () => {
    if (!db || !pkgName.trim() || !pkgPrice.trim()) {
      alert('Please enter package name and price.');
      return;
    }

    const packageData = {
      name: pkgName,
      price: Number(pkgPrice),
      billing: pkgBilling,
      limits: {
        dailyAnalysis: Number(pkgDailyLimit),
        monthlyRequests: Number(pkgMonthlyLimit)
      },
      features: pkgFeatures.split('\n').filter(f => f.trim() !== ''),
      status: pkgStatus,
      description: pkgDescription,
      isPopular: pkgIsPopular,
      users: 0 // Default for new packages, we might want to preserve this on edit
    };

    try {
      if (editingPkgId) {
        // Don't overwrite users count on edit
        const { users, ...updateData } = packageData;
        await updateDoc(doc(db, 'packages', editingPkgId), updateData);
      } else {
        await addDoc(collection(db, 'packages'), packageData);
      }
      setIsModalOpen(false);
    } catch (error) {
      console.error("Error saving package:", error);
      alert("Failed to save package.");
    }
  };

  const handleDeletePackage = async (id: string) => {
    if (!db) return;
    if (confirm('Are you sure you want to delete this package?')) {
      await deleteDoc(doc(db, 'packages', id));
    }
  };

  const toggleStatus = async (pkg: any) => {
    if (!db) return;
    const newStatus = pkg.status === 'Active' ? 'Inactive' : 'Active';
    await updateDoc(doc(db, 'packages', pkg.id), { status: newStatus });
  };

  return (
    <AppLayout title="Package Customization">
      <div className="max-w-7xl mx-auto space-y-8">
        <AdminNav />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold">Subscription Packages</h2>
            <p className="text-sm text-muted-foreground">Manage pricing plans and feature limits</p>
          </div>
          <button 
            onClick={() => openModal()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-white text-sm font-bold hover:opacity-90 transition-all"
          >
            <Plus size={16} />
            Create Package
          </button>
        </div>

        {isModalOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="glass p-8 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto custom-scrollbar space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-bold">{editingPkgId ? 'Edit Package' : 'Create New Package'}</h3>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white/10 rounded-xl transition-colors"><X size={20} /></button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Package Name</label>
                  <input placeholder="e.g., Pro Plan" value={pkgName} onChange={(e) => setPkgName(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Price</label>
                  <input type="number" placeholder="e.g., 29" value={pkgPrice} onChange={(e) => setPkgPrice(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Billing Cycle</label>
                  <select value={pkgBilling} onChange={(e) => setPkgBilling(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                    <option value="per month">Per Month</option>
                    <option value="per year">Per Year</option>
                    <option value="forever">Forever</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Status</label>
                  <select value={pkgStatus} onChange={(e) => setPkgStatus(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Daily Analysis Limit</label>
                  <input type="number" value={pkgDailyLimit} onChange={(e) => setPkgDailyLimit(Number(e.target.value))} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Monthly Requests Limit</label>
                  <input type="number" value={pkgMonthlyLimit} onChange={(e) => setPkgMonthlyLimit(Number(e.target.value))} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Short Description</label>
                  <input placeholder="e.g., Perfect for professional developers" value={pkgDescription} onChange={(e) => setPkgDescription(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
                    <input 
                      type="checkbox"
                      checked={pkgIsPopular}
                      onChange={(e) => setPkgIsPopular(e.target.checked)}
                      className="rounded border-white/10 bg-black/20 text-primary focus:ring-primary/50"
                    />
                    Mark as Popular (Featured)
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">System Features (Logic Enabled)</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 bg-black/20 p-4 rounded-xl border border-white/10">
                    {siteConfig.features?.map(feature => (
                      <label key={feature.id} className="flex items-center gap-2 text-sm cursor-pointer hover:text-white transition-colors">
                        <input 
                          type="checkbox"
                          checked={pkgFeatures.split('\n').includes(feature.id)}
                          onChange={(e) => {
                            const currentFeatures = pkgFeatures.split('\n').filter(f => f.trim() !== '');
                            if (e.target.checked) {
                              setPkgFeatures([...currentFeatures, feature.id].join('\n'));
                            } else {
                              setPkgFeatures(currentFeatures.filter(f => f !== feature.id).join('\n'));
                            }
                          }}
                          className="rounded border-white/10 bg-black/40 text-primary focus:ring-primary/50"
                        />
                        <span>{feature.title}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Custom Features (Display Only - One per line)</label>
                  <textarea 
                    rows={4}
                    placeholder="Unlimited Repositories&#10;Advanced Architecture Maps&#10;Priority Support" 
                    value={pkgFeatures.split('\n').filter(f => !siteConfig.features.some(sf => sf.id === f)).join('\n')} 
                    onChange={(e) => {
                      const systemFeatures = pkgFeatures.split('\n').filter(f => siteConfig.features.some(sf => sf.id === f));
                      const customFeatures = e.target.value.split('\n').filter(f => f.trim() !== '');
                      setPkgFeatures([...systemFeatures, ...customFeatures].join('\n'));
                    }} 
                    className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none" 
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/5">
                <button onClick={() => setIsModalOpen(false)} className="px-4 py-2.5 rounded-xl bg-white/5 text-white text-sm font-bold hover:bg-white/10 transition-all">Cancel</button>
                <button onClick={handleSavePackage} className="px-6 py-2.5 rounded-xl bg-primary text-white text-sm font-bold hover:opacity-90 transition-all">
                  {editingPkgId ? 'Save Changes' : 'Create Package'}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {packages.map((pkg) => (
            <div key={pkg.id} className={`glass p-6 rounded-3xl depth-1 border transition-all ${pkg.status === 'Active' ? 'border-white/10 hover:border-primary/50' : 'border-white/5 opacity-70'} space-y-6 relative group flex flex-col`}>
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                <button onClick={() => openModal(pkg)} className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors">
                  <Edit2 size={14} />
                </button>
                <button onClick={() => handleDeletePackage(pkg.id)} className="p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <button 
                    onClick={() => toggleStatus(pkg)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border transition-colors ${
                      pkg.status === 'Active' 
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20' 
                        : 'bg-white/5 text-muted-foreground border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {pkg.status}
                  </button>
                  <span className="text-xs text-muted-foreground font-medium">{pkg.users || 0} Subscribers</span>
                </div>
                <h3 className="text-2xl font-bold text-white">{pkg.name}</h3>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-4xl font-black">${pkg.price}</span>
                  <span className="text-sm text-muted-foreground">/{pkg.billing}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 py-4 border-y border-white/5">
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Daily Analysis</p>
                  <p className="text-sm font-medium">{pkg.limits?.dailyAnalysis || 'Unlimited'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Monthly Requests</p>
                  <p className="text-sm font-medium">{pkg.limits?.monthlyRequests || 'Unlimited'}</p>
                </div>
              </div>

              <div className="flex-1 space-y-3">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold mb-2">Features</p>
                {pkg.features?.map((feature: string, idx: number) => (
                  <div key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <CheckCircle2 size={16} className="text-primary shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}

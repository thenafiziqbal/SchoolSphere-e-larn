'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  ShieldCheck, 
  Users, 
  Key, 
  CreditCard, 
  TrendingUp, 
  Activity, 
  Globe, 
  Zap, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  PieChart as PieChartIcon,
  Search,
  Filter,
  Loader2
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import AdminNav from '@/components/AdminNav';
import { useAppContext } from '@/lib/AppContext';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  AreaChart, 
  Area 
} from 'recharts';

export default function AdminOverviewPage() {
  const { isAdmin, isLoadingAuth } = useAppContext();
  const [stats, setStats] = useState({
    totalUsers: 0,
    monthlyRevenue: 0,
    totalAnalyses: 0,
    activeSubscribers: 0
  });
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [chartData, setChartData] = useState<{revenue: any[], users: any[]}>({ revenue: [], users: [] });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin || !db) {
      setIsLoading(false);
      return;
    }

    const fetchData = async () => {
      if (!db) return;
      try {
        // Initialize chart data structure for last 6 months
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const chartDataMap = new Map();
        const d = new Date();
        for (let i = 5; i >= 0; i--) {
          const dTemp = new Date(d.getFullYear(), d.getMonth() - i, 1);
          const key = `${dTemp.getFullYear()}-${dTemp.getMonth()}`;
          chartDataMap.set(key, {
            name: monthNames[dTemp.getMonth()],
            revenue: 0,
            users: 0,
            sortIndex: dTemp.getTime()
          });
        }

        // Fetch Users Count
        const usersSnapshot = await getDocs(collection(db, 'users'));
        const totalUsers = usersSnapshot.size;
        let activeSubscribers = 0;

        usersSnapshot.forEach(doc => {
          const data = doc.data();
          const plan = data.subscription?.plan || data.plan || 'free';
          if (plan.toLowerCase() !== 'free') {
            activeSubscribers += 1;
          }
          if (data.joined) {
            const date = new Date(data.joined);
            const key = `${date.getFullYear()}-${date.getMonth()}`;
            if (chartDataMap.has(key)) {
              chartDataMap.get(key).users += 1;
            }
          }
        });

        // Fetch Analyses Count
        const analysesSnapshot = await getDocs(collection(db, 'analyses'));
        const totalAnalyses = analysesSnapshot.size;

        // Fetch Subscription Requests for Revenue and Activity
        const subsQuery = query(collection(db, 'subscriptionRequests'), orderBy('createdAt', 'desc'));
        const subsSnapshot = await getDocs(subsQuery);
        
        let monthlyRevenue = 0;
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        
        const activities: any[] = [];

        subsSnapshot.forEach((doc) => {
          const data = doc.data();
          
          if (data.status === 'approved' && data.createdAt) {
            const date = data.createdAt.toDate();
            
            // Calculate Revenue (Approved requests this month)
            if (date.getMonth() === currentMonth && date.getFullYear() === currentYear) {
              monthlyRevenue += Number(data.amount) || 0;
            }

            // Add to chart data
            const key = `${date.getFullYear()}-${date.getMonth()}`;
            if (chartDataMap.has(key)) {
              chartDataMap.get(key).revenue += Number(data.amount) || 0;
            }
          }

          // Add to recent activity
          if (activities.length < 5) {
            activities.push({
              id: doc.id,
              user: data.userEmail,
              action: `Subscription: ${data.planId}`,
              status: data.status,
              time: data.createdAt ? data.createdAt.toDate().toLocaleDateString() : 'Just now',
              statusColor: data.status === 'approved' ? 'text-emerald-400' : data.status === 'rejected' ? 'text-rose-400' : 'text-amber-400'
            });
          }
        });

        setStats({
          totalUsers,
          monthlyRevenue,
          totalAnalyses,
          activeSubscribers
        });
        
        setRecentActivity(activities);

        // Format chart data
        const sortedChartData = Array.from(chartDataMap.values()).sort((a, b) => a.sortIndex - b.sortIndex);
        
        // Calculate cumulative users for the chart
        let cumulativeUsers = totalUsers - sortedChartData.reduce((sum, item) => sum + item.users, 0);
        const finalUserGrowthData = sortedChartData.map(item => {
          cumulativeUsers += item.users;
          return { name: item.name, value: cumulativeUsers };
        });

        const finalRevenueData = sortedChartData.map(item => ({ name: item.name, value: item.revenue }));

        setChartData({
          revenue: finalRevenueData,
          users: finalUserGrowthData
        });

      } catch (error) {
        console.error("Error fetching admin stats:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [isAdmin]);

  if (isLoadingAuth || isLoading) {
    return (
      <AppLayout title="Admin Overview">
        <div className="h-[60vh] flex items-center justify-center">
          <Loader2 className="animate-spin text-indigo-500" size={32} />
        </div>
      </AppLayout>
    );
  }

  if (!isAdmin) {
    return (
      <AppLayout title="Access Denied">
        <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-4">
          <ShieldCheck size={48} className="text-rose-500" />
          <p className="text-xl font-bold text-white">Admin Access Required</p>
          <p className="text-sm max-w-xs text-center">You do not have the necessary permissions to view this page.</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Admin Overview">
      <div className="max-w-7xl mx-auto space-y-10">
        <AdminNav />
        {/* Platform Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <AdminStatCard 
            icon={<Users size={20} />} 
            label="Total Users" 
            value={stats.totalUsers.toLocaleString()} 
            trend="Real-time" 
            trendUp 
            color="text-indigo-400" 
          />
          <AdminStatCard 
            icon={<CreditCard size={20} />} 
            label="Monthly Revenue" 
            value={`৳${stats.monthlyRevenue.toLocaleString()}`} 
            trend="This Month" 
            trendUp 
            color="text-emerald-400" 
          />
          <AdminStatCard 
            icon={<Zap size={20} />} 
            label="Total Analyses" 
            value={stats.totalAnalyses.toLocaleString()} 
            trend="Real-time" 
            trendUp 
            color="text-amber-400" 
          />
          <AdminStatCard 
            icon={<ShieldCheck size={20} />} 
            label="Active Subscribers" 
            value={stats.activeSubscribers.toLocaleString()} 
            trend="Real-time" 
            trendUp 
            color="text-purple-400" 
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Revenue Chart */}
          <div className="glass p-8 rounded-3xl depth-1">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <TrendingUp size={20} className="text-emerald-400" />
                Revenue Growth
              </h3>
              <select className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-muted-foreground focus:outline-none">
                <option>Last 6 Months</option>
              </select>
            </div>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData.revenue}>
                  <defs>
                    <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#888888', fontSize: 12 }} />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0a0a0a', border: '1px solid #ffffff10', borderRadius: '12px' }}
                    itemStyle={{ color: '#10b981' }}
                    formatter={(value: any) => [`৳${value}`, 'Revenue']}
                  />
                  <Area type="monotone" dataKey="value" stroke="#10b981" fillOpacity={1} fill="url(#colorRev)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* User Growth Chart */}
          <div className="glass p-8 rounded-3xl depth-1">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Users size={20} className="text-indigo-400" />
                User Acquisition
              </h3>
              <select className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-muted-foreground focus:outline-none">
                <option>Last 6 Months</option>
              </select>
            </div>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData.users}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#888888', fontSize: 12 }} />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0a0a0a', border: '1px solid #ffffff10', borderRadius: '12px' }}
                    itemStyle={{ color: '#6366f1' }}
                    formatter={(value: any) => [value, 'Total Users']}
                  />
                  <Line type="monotone" dataKey="value" stroke="#6366f1" strokeWidth={3} dot={{ fill: '#6366f1', r: 4 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recent Activity Table */}
        <div className="glass rounded-3xl depth-1 overflow-hidden">
          <div className="p-8 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-lg font-bold">Recent Subscription Activity</h3>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={14} />
                <input 
                  type="text" 
                  placeholder="Search activity..." 
                  className="bg-black/20 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs focus:outline-none"
                />
              </div>
              <button className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-muted-foreground hover:text-white transition-all">
                <Filter size={14} />
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-white/5 text-muted-foreground uppercase text-[10px] font-bold tracking-widest">
                  <th className="px-8 py-4">User</th>
                  <th className="px-8 py-4">Action</th>
                  <th className="px-8 py-4">Status</th>
                  <th className="px-8 py-4">Time</th>
                  <th className="px-8 py-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {recentActivity.length > 0 ? (
                  recentActivity.map((activity) => (
                    <ActivityRow 
                      key={activity.id}
                      user={activity.user} 
                      action={activity.action} 
                      status={activity.status} 
                      time={activity.time} 
                      statusColor={activity.statusColor}
                    />
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-8 py-8 text-center text-muted-foreground">
                      No recent activity found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function AdminStatCard({ icon, label, value, trend, trendUp, color }: { icon: React.ReactNode, label: string, value: string, trend: string, trendUp: boolean, color: string }) {
  return (
    <div className="glass p-6 rounded-3xl depth-1 border border-white/5 space-y-4">
      <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <div className="flex items-baseline gap-3 mt-1">
          <p className="text-2xl font-bold">{value}</p>
          <span className={`text-[10px] font-bold flex items-center gap-0.5 ${trendUp ? 'text-emerald-400' : 'text-rose-400'}`}>
            {trendUp ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
            {trend}
          </span>
        </div>
      </div>
    </div>
  );
}

function ActivityRow({ user, action, status, time, statusColor }: { user: string, action: string, status: string, time: string, statusColor: string }) {
  return (
    <tr className="hover:bg-white/5 transition-colors group">
      <td className="px-8 py-4 font-medium">{user}</td>
      <td className="px-8 py-4 text-muted-foreground">{action}</td>
      <td className={`px-8 py-4 font-bold capitalize ${statusColor}`}>{status}</td>
      <td className="px-8 py-4 text-muted-foreground text-xs">{time}</td>
      <td className="px-8 py-4 text-right">
        <button className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors">View</button>
      </td>
    </tr>
  );
}

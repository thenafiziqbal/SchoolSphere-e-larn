'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, Globe, Type, Image as ImageIcon, Link as LinkIcon, Layout, Loader2, Plus, Trash2, Star, CreditCard, CheckCircle2, LayoutDashboard, Eye, EyeOff, Mail } from 'lucide-react';
import { useAppContext, Feature, PricingPlan } from '@/lib/AppContext';
import AdminNav from '@/components/AdminNav';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

export default function AdminSettingsPage() {
  const { siteConfig, updateSiteConfig, isAdmin, isLoadingAuth } = useAppContext();
  const [formData, setFormData] = useState(siteConfig);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const router = useRouter();

  useEffect(() => {
    if (!isLoadingAuth && !isAdmin) {
      router.push('/admin/access-denied');
    }
  }, [isAdmin, isLoadingAuth, router]);

  useEffect(() => {
    setFormData(siteConfig);
  }, [siteConfig]);

  const handleSave = async () => {
    setIsSaving(true);
    setMessage({ type: '', text: '' });
    try {
      await updateSiteConfig(formData);
      setMessage({ type: 'success', text: 'Settings updated successfully!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update settings.' });
    } finally {
      setIsSaving(false);
    }
  };

  const addHeaderLink = () => {
    setFormData(prev => ({
      ...prev,
      headerLinks: [...prev.headerLinks, { label: 'New Link', href: '#' }]
    }));
  };

  const removeHeaderLink = (index: number) => {
    setFormData(prev => ({
      ...prev,
      headerLinks: prev.headerLinks.filter((_, i) => i !== index)
    }));
  };

  const updateHeaderLink = (index: number, field: 'label' | 'href', value: string) => {
    setFormData(prev => ({
      ...prev,
      headerLinks: prev.headerLinks.map((link, i) => i === index ? { ...link, [field]: value } : link)
    }));
  };

  const addFooterLink = () => {
    setFormData(prev => ({
      ...prev,
      footerLinks: [...(prev.footerLinks || []), { label: 'New Link', href: '#' }]
    }));
  };

  const removeFooterLink = (index: number) => {
    setFormData(prev => ({
      ...prev,
      footerLinks: prev.footerLinks.filter((_, i) => i !== index)
    }));
  };

  const updateFooterLink = (index: number, field: 'label' | 'href', value: string) => {
    setFormData(prev => ({
      ...prev,
      footerLinks: prev.footerLinks.map((link, i) => i === index ? { ...link, [field]: value } : link)
    }));
  };

  const addFeature = () => {
    setFormData(prev => ({
      ...prev,
      features: [...(prev.features || []), { id: Math.random().toString(36).substring(7), title: 'New Feature', description: '', iconName: 'Star', isPremium: false }]
    }));
  };

  const removeFeature = (id: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter(f => f.id !== id)
    }));
  };

  const updateFeature = (id: string, field: keyof Feature, value: any) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.map(f => f.id === id ? { ...f, [field]: value } : f)
    }));
  };

  const addPricingPlan = () => {
    setFormData(prev => ({
      ...prev,
      pricingPlans: [...(prev.pricingPlans || []), { id: Math.random().toString(36).substring(7), name: 'New Plan', price: 0, description: '', features: [], limits: { dailyAnalysis: 0, monthlyRequests: 0 }, isPopular: false }]
    }));
  };

  const removePricingPlan = (id: string) => {
    setFormData(prev => ({
      ...prev,
      pricingPlans: prev.pricingPlans.filter(p => p.id !== id)
    }));
  };

  const updatePricingPlan = (id: string, field: keyof PricingPlan, value: any) => {
    setFormData(prev => ({
      ...prev,
      pricingPlans: prev.pricingPlans.map(p => p.id === id ? { ...p, [field]: value } : p)
    }));
  };

  const addGalleryImage = () => {
    setFormData(prev => ({
      ...prev,
      galleryImages: [...(prev.galleryImages || []), { url: '', isVisible: true }]
    }));
  };

  const removeGalleryImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      galleryImages: prev.galleryImages.filter((_, i) => i !== index)
    }));
  };

  const updateGalleryImage = (index: number, field: 'url' | 'isVisible', value: any) => {
    setFormData(prev => ({
      ...prev,
      galleryImages: prev.galleryImages.map((img, i) => i === index ? { ...img, [field]: value } : img)
    }));
  };

  const togglePlanFeature = (planId: string, featureId: string) => {
    setFormData(prev => ({
      ...prev,
      pricingPlans: prev.pricingPlans.map(p => {
        if (p.id === planId) {
          const hasFeature = p.features.includes(featureId);
          return {
            ...p,
            features: hasFeature ? p.features.filter(id => id !== featureId) : [...p.features, featureId]
          };
        }
        return p;
      })
    }));
  };

  if (isLoadingAuth) return null;
  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      <AdminNav />
      
      <main className="max-w-4xl mx-auto px-6 pt-32">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h1 className="text-4xl font-bold tracking-tight mb-2">Site Settings</h1>
            <p className="text-muted-foreground text-lg italic serif">Customize your application appearance and details.</p>
          </div>
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-2xl font-bold transition-all flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
            Save Changes
          </button>
        </div>

        {message.text && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mb-8 p-4 rounded-2xl border ${
              message.type === 'success' 
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                : 'bg-red-500/10 border-red-500/20 text-red-400'
            }`}
          >
            {message.text}
          </motion.div>
        )}

        <div className="space-y-8">
          {/* General Info */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Globe size={20} />
              </div>
              <h2 className="text-xl font-bold">General Information</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Site Name</label>
                <div className="relative">
                  <Type className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <input 
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-muted border border-border rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Logo URL</label>
                <div className="relative">
                  <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <input 
                    type="text"
                    value={formData.logoUrl}
                    onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                    placeholder="https://example.com/logo.png"
                    className="w-full bg-muted border border-border rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Favicon URL</label>
                <div className="relative">
                  <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <input 
                    type="text"
                    value={formData.faviconUrl}
                    onChange={(e) => setFormData({ ...formData, faviconUrl: e.target.value })}
                    placeholder="/favicon.ico"
                    className="w-full bg-muted border border-border rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1">Hero Title Prefix</label>
                  <input 
                    type="text"
                    value={formData.heroTitlePrefix}
                    onChange={(e) => setFormData({ ...formData, heroTitlePrefix: e.target.value })}
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1">Hero Title Gradient</label>
                  <input 
                    type="text"
                    value={formData.heroTitleGradient}
                    onChange={(e) => setFormData({ ...formData, heroTitleGradient: e.target.value })}
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground ml-1">Hero Description</label>
              <textarea 
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all resize-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground ml-1">Hero 3D Image URL</label>
              <div className="relative">
                <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                <input 
                  type="text"
                  value={formData.hero3dImageUrl}
                  onChange={(e) => setFormData({ ...formData, hero3dImageUrl: e.target.value })}
                  placeholder="https://example.com/3d-image.png"
                  className="w-full bg-muted border border-border rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4 p-4 rounded-2xl bg-muted/30 border border-border">
                <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-400">Primary CTA Button</h3>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-muted-foreground ml-1">Button Text</label>
                  <input 
                    type="text"
                    value={formData.heroCtaPrimaryText}
                    onChange={(e) => setFormData({ ...formData, heroCtaPrimaryText: e.target.value })}
                    className="w-full bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-muted-foreground ml-1">Button Link</label>
                  <input 
                    type="text"
                    value={formData.heroCtaPrimaryHref}
                    onChange={(e) => setFormData({ ...formData, heroCtaPrimaryHref: e.target.value })}
                    className="w-full bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-4 p-4 rounded-2xl bg-muted/30 border border-border">
                <h3 className="text-sm font-bold uppercase tracking-wider text-purple-400">Secondary CTA Button</h3>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-muted-foreground ml-1">Button Text</label>
                  <input 
                    type="text"
                    value={formData.heroCtaSecondaryText}
                    onChange={(e) => setFormData({ ...formData, heroCtaSecondaryText: e.target.value })}
                    className="w-full bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-muted-foreground ml-1">Button Link</label>
                  <input 
                    type="text"
                    value={formData.heroCtaSecondaryHref}
                    onChange={(e) => setFormData({ ...formData, heroCtaSecondaryHref: e.target.value })}
                    className="w-full bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-6 pt-6 border-t border-border">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <LayoutDashboard size={18} />
                </div>
                <h3 className="text-lg font-bold">Dashboard Preview Settings</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1">Preview URL Bar</label>
                  <input 
                    type="text"
                    value={formData.previewUrl}
                    onChange={(e) => setFormData({ ...formData, previewUrl: e.target.value })}
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1">Sidebar Header Text</label>
                  <input 
                    type="text"
                    value={formData.previewSidebarText}
                    onChange={(e) => setFormData({ ...formData, previewSidebarText: e.target.value })}
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Main Content Title</label>
                <input 
                  type="text"
                  value={formData.previewMainTitle}
                  onChange={(e) => setFormData({ ...formData, previewMainTitle: e.target.value })}
                  className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Main Content Image URL</label>
                <input 
                  type="text"
                  value={formData.previewMainImage}
                  onChange={(e) => setFormData({ ...formData, previewMainImage: e.target.value })}
                  className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>
            </div>
          </section>

          {/* Gallery Images */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <ImageIcon size={20} />
                </div>
                <h2 className="text-xl font-bold">Gallery Images</h2>
              </div>
              <button 
                onClick={addGalleryImage}
                className="text-xs bg-muted hover:bg-muted/80 px-3 py-1.5 rounded-lg transition-all flex items-center gap-1"
              >
                <Plus size={14} /> Add Image
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {formData.galleryImages?.map((image, index) => (
                <div key={index} className="p-4 bg-muted border border-border rounded-2xl space-y-3">
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-black/20 mb-2">
                    {image.url ? (
                      <Image 
                        src={image.url} 
                        alt={`Gallery ${index}`} 
                        fill 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">No Image URL</div>
                    )}
                    <div className="absolute top-2 right-2 flex gap-2">
                      <button 
                        onClick={() => updateGalleryImage(index, 'isVisible', !image.isVisible)}
                        className={`p-1.5 rounded-lg transition-all ${image.isVisible ? 'bg-indigo-600 text-white' : 'bg-muted text-muted-foreground'}`}
                        title={image.isVisible ? 'Visible' : 'Hidden'}
                      >
                        {image.isVisible ? <Eye size={14} /> : <EyeOff size={14} />}
                      </button>
                      <button 
                        onClick={() => removeGalleryImage(index)}
                        className="p-1.5 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500 transition-all hover:text-white"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                  <input 
                    type="text"
                    value={image.url}
                    onChange={(e) => updateGalleryImage(index, 'url', e.target.value)}
                    placeholder="Image URL"
                    className="w-full bg-background border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              ))}
            </div>
          </section>

          {/* Features */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                  <Star size={20} />
                </div>
                <h2 className="text-xl font-bold">Features</h2>
              </div>
              <button 
                onClick={addFeature}
                className="text-xs bg-muted hover:bg-muted/80 px-3 py-1.5 rounded-lg transition-all flex items-center gap-1"
              >
                <Plus size={14} /> Add Feature
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Features Section Title</label>
                <input 
                  type="text"
                  value={formData.featuresTitle}
                  onChange={(e) => setFormData({ ...formData, featuresTitle: e.target.value })}
                  className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Features Section Subtitle</label>
                <input 
                  type="text"
                  value={formData.featuresSubtitle}
                  onChange={(e) => setFormData({ ...formData, featuresSubtitle: e.target.value })}
                  className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>
            </div>

            <div className="space-y-4">
              {formData.features?.map((feature) => (
                <div key={feature.id} className="p-3 md:p-4 bg-muted border border-border rounded-xl space-y-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <input 
                        type="text"
                        value={feature.title}
                        onChange={(e) => updateFeature(feature.id, 'title', e.target.value)}
                        placeholder="Feature Title"
                        className="w-full bg-background border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      />
                      <input 
                        type="text"
                        value={feature.iconName}
                        onChange={(e) => updateFeature(feature.id, 'iconName', e.target.value)}
                        placeholder="Lucide Icon Name (e.g., Code2)"
                        className="w-full bg-background border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      />
                    </div>
                    <button 
                      onClick={() => removeFeature(feature.id)}
                      className="p-2 text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <textarea 
                    value={feature.description}
                    onChange={(e) => updateFeature(feature.id, 'description', e.target.value)}
                    placeholder="Feature Description"
                    rows={2}
                    className="w-full bg-background border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none"
                  />
                  <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
                    <input 
                      type="checkbox"
                      checked={feature.isPremium}
                      onChange={(e) => updateFeature(feature.id, 'isPremium', e.target.checked)}
                      className="rounded border-border bg-background text-indigo-500 focus:ring-indigo-500/50"
                    />
                    Premium Feature (Shows Crown Icon)
                  </label>
                </div>
              ))}
            </div>
          </section>

          {/* Header & Footer */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400">
                <Layout size={20} />
              </div>
              <h2 className="text-xl font-bold">Header & Footer</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-muted-foreground ml-1">Header Links</label>
                <button 
                  onClick={addHeaderLink}
                  className="text-xs bg-muted hover:bg-muted/80 px-3 py-1.5 rounded-lg transition-all flex items-center gap-1"
                >
                  <Plus size={14} /> Add Link
                </button>
              </div>
              
              <div className="space-y-3">
                {formData.headerLinks.map((link, index) => (
                  <div key={index} className="flex gap-3 items-center">
                    <input 
                      type="text"
                      value={link.label}
                      onChange={(e) => updateHeaderLink(index, 'label', e.target.value)}
                      placeholder="Label"
                      className="flex-1 bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                    />
                    <div className="relative flex-[2]">
                      <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={14} />
                      <input 
                        type="text"
                        value={link.href}
                        onChange={(e) => updateHeaderLink(index, 'href', e.target.value)}
                        placeholder="URL (e.g. /docs)"
                        className="w-full bg-muted border border-border rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      />
                    </div>
                    <button 
                      onClick={() => removeHeaderLink(index)}
                      className="p-2 text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-muted-foreground ml-1">Footer Links</label>
                <button 
                  onClick={addFooterLink}
                  className="text-xs bg-muted hover:bg-muted/80 px-3 py-1.5 rounded-lg transition-all flex items-center gap-1"
                >
                  <Plus size={14} /> Add Link
                </button>
              </div>
              
              <div className="space-y-3">
                {formData.footerLinks?.map((link, index) => (
                  <div key={index} className="flex gap-3 items-center">
                    <input 
                      type="text"
                      value={link.label}
                      onChange={(e) => updateFooterLink(index, 'label', e.target.value)}
                      placeholder="Label"
                      className="flex-1 bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                    />
                    <div className="relative flex-[2]">
                      <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={14} />
                      <input 
                        type="text"
                        value={link.href}
                        onChange={(e) => updateFooterLink(index, 'href', e.target.value)}
                        placeholder="URL (e.g. /privacy)"
                        className="w-full bg-muted border border-border rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      />
                    </div>
                    <button 
                      onClick={() => removeFooterLink(index)}
                      className="p-2 text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t border-border">
              <label className="text-sm font-medium text-muted-foreground ml-1">Footer Text</label>
              <input 
                type="text"
                value={formData.footerText}
                onChange={(e) => setFormData({ ...formData, footerText: e.target.value })}
                className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
              />
            </div>
          </section>

          {/* Pricing */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center text-pink-400">
                <CreditCard size={20} />
              </div>
              <h2 className="text-xl font-bold">Pricing Section</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Pricing Section Title</label>
                <input 
                  type="text"
                  value={formData.pricingTitle}
                  onChange={(e) => setFormData({ ...formData, pricingTitle: e.target.value })}
                  className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground ml-1">Pricing Section Subtitle</label>
                <input 
                  type="text"
                  value={formData.pricingSubtitle}
                  onChange={(e) => setFormData({ ...formData, pricingSubtitle: e.target.value })}
                  className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                />
              </div>
            </div>
            <p className="text-sm text-muted-foreground">Note: Pricing plans are managed from the Packages page.</p>
          </section>

          {/* Payment Information */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                <CreditCard size={20} />
              </div>
              <h2 className="text-xl font-bold">Payment Information</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {['bkash', 'nagad', 'rocket'].map((method) => (
                <div key={method} className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1 capitalize">{method} Number</label>
                  <input 
                    type="text"
                    value={formData.paymentNumbers[method as keyof typeof formData.paymentNumbers]}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      paymentNumbers: { ...formData.paymentNumbers, [method]: e.target.value } 
                    })}
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-border space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1">USD Exchange Rate (1 USD = ? BDT)</label>
                  <input 
                    type="number"
                    value={formData.usdExchangeRate}
                    onChange={(e) => setFormData({ ...formData, usdExchangeRate: Number(e.target.value) })}
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground ml-1">Binance Pay Link / ID</label>
                  <input 
                    type="text"
                    value={formData.binancePayLink}
                    onChange={(e) => setFormData({ ...formData, binancePayLink: e.target.value })}
                    placeholder="Binance Pay ID or Link"
                    className="w-full bg-muted border border-border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-muted-foreground ml-1">Binance Payment Instructions (Step by Step)</label>
                  <button 
                    onClick={() => setFormData(prev => ({ ...prev, binanceInstructions: [...prev.binanceInstructions, ''] }))}
                    className="text-xs bg-muted hover:bg-muted/80 px-3 py-1.5 rounded-lg transition-all flex items-center gap-1"
                  >
                    <Plus size={14} /> Add Step
                  </button>
                </div>
                <div className="space-y-3">
                  {formData.binanceInstructions.map((step, index) => (
                    <div key={index} className="flex gap-3 items-center">
                      <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 text-xs font-bold shrink-0">
                        {index + 1}
                      </div>
                      <input 
                        type="text"
                        value={step}
                        onChange={(e) => {
                          const newSteps = [...formData.binanceInstructions];
                          newSteps[index] = e.target.value;
                          setFormData({ ...formData, binanceInstructions: newSteps });
                        }}
                        placeholder={`Step ${index + 1}`}
                        className="flex-1 bg-muted border border-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      />
                      <button 
                        onClick={() => {
                          const newSteps = formData.binanceInstructions.filter((_, i) => i !== index);
                          setFormData({ ...formData, binanceInstructions: newSteps });
                        }}
                        className="p-2 text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Email Notifications */}
          <section className="glass p-4 md:p-8 rounded-3xl border border-border space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-400">
                <Mail size={20} />
              </div>
              <h2 className="text-xl font-bold">Email Notifications</h2>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 border border-border rounded-2xl">
                <div className="space-y-0.5">
                  <p className="font-bold">New Subscription Requests</p>
                  <p className="text-sm text-muted-foreground">Receive an email notification when a user submits a new subscription request.</p>
                </div>
                <button 
                  onClick={() => setFormData({ ...formData, enableEmailNotifications: !formData.enableEmailNotifications })}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${formData.enableEmailNotifications ? 'bg-indigo-600' : 'bg-muted'}`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${formData.enableEmailNotifications ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
              </div>

              {formData.enableEmailNotifications && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2"
                >
                  <label className="text-sm font-medium text-muted-foreground ml-1">Admin Notification Email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                    <input 
                      type="email"
                      value={formData.adminNotificationEmail}
                      onChange={(e) => setFormData({ ...formData, adminNotificationEmail: e.target.value })}
                      placeholder="admin@example.com"
                      className="w-full bg-muted border border-border rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground ml-1 italic">This email will receive alerts for all new pending subscription requests.</p>
                </motion.div>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CreditCard, 
  Check, 
  X, 
  Search, 
  Filter, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Smartphone,
  Hash,
  User,
  Mail,
  Calendar,
  ArrowUpRight,
  Loader2
} from 'lucide-react';
import Tooltip from '@/components/Tooltip';
import AppLayout from '@/components/AppLayout';
import AdminNav from '@/components/AdminNav';
import { useAppContext, PLANS, SubscriptionRequest } from '@/lib/AppContext';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy, doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';

export default function AdminSubscriptionsPage() {
  const { isAdmin, isLoadingAuth } = useAppContext();
  const [requests, setRequests] = useState<SubscriptionRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    request: SubscriptionRequest | null;
    action: 'approved' | 'rejected' | null;
  }>({ isOpen: false, request: null, action: null });

  useEffect(() => {
    if (!isAdmin || !db) {
      setIsLoading(false);
      return;
    }

    const q = query(collection(db, 'subscriptionRequests'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as SubscriptionRequest[];
      setRequests(data);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [isAdmin]);

  const handleAction = async (request: SubscriptionRequest, status: 'approved' | 'rejected') => {
    if (!db || !request.id) return;
    setProcessingId(request.id);

    try {
      // Update request status
      await updateDoc(doc(db, 'subscriptionRequests', request.id), { status });

      if (status === 'approved') {
        // Update user's subscription and limits
        const userRef = doc(db, 'users', request.userId);
        const plan = PLANS[request.planId as keyof typeof PLANS];
        
        await setDoc(userRef, {
          subscription: {
            plan: request.planId,
            status: 'active',
            expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
            limits: plan.limits
          }
        }, { merge: true });
      }

      alert(`Subscription request ${status} successfully.`);
    } catch (error) {
      console.error("Error updating subscription:", error);
      alert("Failed to update subscription. Please try again.");
    } finally {
      setProcessingId(null);
    }
  };

  const filteredRequests = requests.filter(req => {
    const matchesSearch = req.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         req.transactionId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || req.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  if (isLoadingAuth || isLoading) {
    return (
      <AppLayout title="Subscription Management">
        <div className="h-[60vh] flex items-center justify-center">
          <Loader2 className="animate-spin text-indigo-500" size={32} />
        </div>
      </AppLayout>
    );
  }

  if (!isAdmin) {
    return (
      <AppLayout title="Access Denied">
        <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
          <XCircle className="text-rose-500" size={64} />
          <h2 className="text-2xl font-bold">Unauthorized Access</h2>
          <p className="text-muted-foreground">You do not have permission to view this page.</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Subscription Management">
      <div className="max-w-7xl mx-auto space-y-8">
        <AdminNav />

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input 
              type="text"
              placeholder="Search email or transaction ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto">
            {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all whitespace-nowrap ${
                  filterStatus === status 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' 
                    : 'bg-white/5 text-muted-foreground hover:bg-white/10'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <div className="glass rounded-[2rem] depth-1 overflow-hidden border border-white/5">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-white/5 text-muted-foreground uppercase text-[10px] font-bold tracking-widest">
                  <th className="px-8 py-5">User / Plan</th>
                  <th className="px-8 py-5">Payment Details</th>
                  <th className="px-8 py-5">Amount</th>
                  <th className="px-8 py-5">Status</th>
                  <th className="px-8 py-5">Date</th>
                  <th className="px-8 py-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <AnimatePresence mode="popLayout">
                  {filteredRequests.map((req) => (
                    <motion.tr 
                      key={req.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="hover:bg-white/5 transition-colors group"
                    >
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                            <User size={18} />
                          </div>
                          <div>
                            <p className="font-bold text-white">{req.userEmail}</p>
                            <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">{req.planId} Plan</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs">
                            <Smartphone size={12} className="text-muted-foreground" />
                            <span className="capitalize">{req.method}</span>
                          </div>
                          <div className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
                            <Hash size={12} />
                            {req.transactionId}
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="font-bold text-white">৳{req.amount}</span>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className={`flex items-center justify-center w-8 h-8 rounded-full border ${
                            req.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                            req.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                            'bg-rose-500/10 text-rose-400 border-rose-500/20'
                          }`}>
                            {req.status === 'pending' && <Clock size={16} />}
                            {req.status === 'approved' && <CheckCircle2 size={16} />}
                            {req.status === 'rejected' && <XCircle size={16} />}
                          </div>
                          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                            req.status === 'pending' ? 'bg-amber-500 text-black' :
                            req.status === 'approved' ? 'bg-emerald-500 text-white' :
                            'bg-rose-500 text-white'
                          }`}>
                            {req.status}
                          </span>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Calendar size={12} />
                          {req.createdAt?.toDate ? req.createdAt.toDate().toLocaleDateString() : 'Just now'}
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right">
                        {req.status === 'pending' && (
                          <div className="flex items-center justify-end gap-2">
                            <Tooltip text="Reject">
                              <button 
                                onClick={() => setConfirmDialog({ isOpen: true, request: req, action: 'rejected' })}
                                disabled={processingId === req.id}
                                className="p-2 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500 hover:text-white transition-all disabled:opacity-50"
                              >
                                <X size={18} />
                              </button>
                            </Tooltip>
                            <Tooltip text="Approve">
                              <button 
                                onClick={() => setConfirmDialog({ isOpen: true, request: req, action: 'approved' })}
                                disabled={processingId === req.id}
                                className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-white transition-all disabled:opacity-50"
                              >
                                <Check size={18} />
                              </button>
                            </Tooltip>
                          </div>
                        )}
                        {req.status !== 'pending' && (
                          <div className="text-muted-foreground opacity-30">
                            <CheckCircle2 size={18} className="ml-auto" />
                          </div>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
                {filteredRequests.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-8 py-20 text-center">
                      <div className="flex flex-col items-center gap-3 text-muted-foreground">
                        <AlertCircle size={40} className="opacity-20" />
                        <p>No subscription requests found.</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      <AnimatePresence>
        {confirmDialog.isOpen && confirmDialog.request && confirmDialog.action && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-background border border-border rounded-3xl p-6 max-w-md w-full shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  confirmDialog.action === 'approved' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                }`}>
                  <AlertCircle size={20} />
                </div>
                <h3 className="text-xl font-bold">Confirm Action</h3>
              </div>
              <p className="text-muted-foreground mb-6">
                Are you sure you want to <span className={confirmDialog.action === 'approved' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{confirmDialog.action === 'approved' ? 'approve' : 'reject'}</span> the subscription request for <span className="text-foreground font-medium">{confirmDialog.request.userEmail}</span>?
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setConfirmDialog({ isOpen: false, request: null, action: null })}
                  className="px-4 py-2 rounded-xl text-sm font-bold text-muted-foreground hover:bg-white/5 transition-colors"
                  disabled={processingId === confirmDialog.request.id}
                >
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    await handleAction(confirmDialog.request!, confirmDialog.action!);
                    setConfirmDialog({ isOpen: false, request: null, action: null });
                  }}
                  disabled={processingId === confirmDialog.request.id}
                  className={`px-4 py-2 rounded-xl text-sm font-bold text-white transition-all flex items-center gap-2 ${
                    confirmDialog.action === 'approved' 
                      ? 'bg-emerald-500 hover:bg-emerald-600' 
                      : 'bg-rose-500 hover:bg-rose-600'
                  }`}
                >
                  {processingId === confirmDialog.request.id ? (
                    <>
                      <Loader2 className="animate-spin" size={16} />
                      Processing...
                    </>
                  ) : (
                    'Confirm'
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AppLayout>
  );
}

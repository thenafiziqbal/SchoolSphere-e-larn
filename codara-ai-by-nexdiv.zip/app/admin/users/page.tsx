'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Search, 
  Filter, 
  MoreVertical, 
  Shield, 
  UserPlus, 
  Calendar,
  CheckCircle2,
  XCircle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  ArrowUpDown,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import { useAppContext } from '@/lib/AppContext';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';

export default function AdminUsersPage() {
  const { isAdmin } = useAppContext();
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  
  const [sortField, setSortField] = useState<'name' | 'email' | 'plan' | 'status' | 'joined'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  useEffect(() => {
    if (!isAdmin || !db) return;

    const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
      const usersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(usersData);
    });

    return () => unsubscribe();
  }, [isAdmin]);

  const handleAddUser = async () => {
    if (!db || !newUserName.trim() || !newUserEmail.trim()) return;
    await addDoc(collection(db, 'users'), {
      name: newUserName,
      email: newUserEmail,
      plan: 'Free',
      status: 'Active',
      joined: new Date().toISOString().split('T')[0],
      usage: '0%'
    });
    setNewUserName('');
    setNewUserEmail('');
  };

  const toggleUserStatus = async (user: any) => {
    if (!db) return;
    const newStatus = user.status === 'Active' ? 'Inactive' : 'Active';
    await updateDoc(doc(db, 'users', user.id), { status: newStatus });
  };

  const handleSort = (field: 'name' | 'email' | 'plan' | 'status' | 'joined') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredUsers = users.filter(user => 
    user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedUsers = [...filteredUsers].sort((a, b) => {
    let aValue = a[sortField] || '';
    let bValue = b[sortField] || '';
    
    if (typeof aValue === 'string') aValue = aValue.toLowerCase();
    if (typeof bValue === 'string') bValue = bValue.toLowerCase();

    if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  return (
    <AppLayout title="User Management">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input 
              type="text" 
              placeholder="Search users..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            />
          </div>
          <div className="flex items-center gap-3">
            <input 
              placeholder="Name"
              value={newUserName}
              onChange={(e) => setNewUserName(e.target.value)}
              className="bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm"
            />
            <input 
              placeholder="Email"
              value={newUserEmail}
              onChange={(e) => setNewUserEmail(e.target.value)}
              className="bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-sm"
            />
            <button 
              onClick={handleAddUser}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-white text-sm font-bold hover:opacity-90 transition-all"
            >
              <UserPlus size={16} />
              Add User
            </button>
          </div>
        </div>

        <div className="glass rounded-3xl depth-1 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-white/5 text-muted-foreground uppercase text-[10px] font-bold tracking-widest">
                  <th className="px-8 py-4 cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('name')}>
                    <div className="flex items-center gap-2">
                      User
                      {sortField === 'name' ? (sortDirection === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />) : <ArrowUpDown size={12} className="opacity-50" />}
                    </div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('email')}>
                    <div className="flex items-center gap-2">
                      Email
                      {sortField === 'email' ? (sortDirection === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />) : <ArrowUpDown size={12} className="opacity-50" />}
                    </div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('plan')}>
                    <div className="flex items-center gap-2">
                      Plan
                      {sortField === 'plan' ? (sortDirection === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />) : <ArrowUpDown size={12} className="opacity-50" />}
                    </div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('status')}>
                    <div className="flex items-center gap-2">
                      Status
                      {sortField === 'status' ? (sortDirection === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />) : <ArrowUpDown size={12} className="opacity-50" />}
                    </div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:text-white transition-colors" onClick={() => handleSort('joined')}>
                    <div className="flex items-center gap-2">
                      Joined
                      {sortField === 'joined' ? (sortDirection === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />) : <ArrowUpDown size={12} className="opacity-50" />}
                    </div>
                  </th>
                  <th className="px-8 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {sortedUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-white/5 transition-colors group">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center text-indigo-400 font-bold">
                          {user.name?.charAt(0) || 'U'}
                        </div>
                        <p className="font-bold text-white">{user.name}</p>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-muted-foreground">
                      {user.email}
                    </td>
                    <td className="px-8 py-5">
                      <span className="bg-white/5 text-muted-foreground border border-white/10 px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider">
                        {user.plan}
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <button 
                        onClick={() => toggleUserStatus(user)}
                        className="flex items-center gap-2 hover:opacity-70 transition-opacity"
                      >
                        {user.status === 'Active' ? (
                          <CheckCircle2 size={14} className="text-emerald-400" />
                        ) : (
                          <XCircle size={14} className="text-rose-400" />
                        )}
                        <span className={user.status === 'Active' ? 'text-emerald-400' : 'text-rose-400'}>
                          {user.status}
                        </span>
                      </button>
                    </td>
                    <td className="px-8 py-5 text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar size={14} />
                        {user.joined}
                      </div>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button 
                        onClick={() => db && deleteDoc(doc(db, 'users', user.id))}
                        className="p-2 rounded-lg hover:bg-white/10 text-rose-400 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

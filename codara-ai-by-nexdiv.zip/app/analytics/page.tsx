'use client';

import { useAppContext } from '@/lib/AppContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import { Loader2 } from 'lucide-react';

export default function AnalyticsRedirect() {
  const { analysisResult } = useAppContext();
  const router = useRouter();

  useEffect(() => {
    if (analysisResult) {
      // In a real app, this would be a dedicated analytics page
      // For now, we'll redirect to the dashboard overview which has analytics
      router.push('/dashboard');
    }
  }, [analysisResult, router]);

  if (!analysisResult) {
    return (
      <AppLayout title="Analytics">
        <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-4">
          <p>No analysis data available. Please analyze a repository first.</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <div className="h-screen w-full flex items-center justify-center">
      <Loader2 className="animate-spin text-indigo-500" size={40} />
    </div>
  );
}

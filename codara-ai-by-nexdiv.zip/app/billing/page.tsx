'use client';

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSearchParams, useRouter } from 'next/navigation';
import { 
  CreditCard, 
  Check, 
  Zap, 
  ShieldCheck, 
  History, 
  Download, 
  ArrowRight,
  Star,
  Crown,
  Building2,
  AlertCircle,
  Smartphone,
  Hash,
  X,
  Loader2,
  CheckCircle2,
  Clock,
  XCircle,
  Calendar
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import { useAppContext, PLANS } from '@/lib/AppContext';

export default function BillingPage() {
  const { subscription, usage, siteConfig, userRequests } = useAppContext();
  const searchParams = useSearchParams();
  const router = useRouter();
  const [currency, setCurrency] = useState<'BDT' | 'USD'>('BDT');

  const plans = useMemo(() => {
    if (!siteConfig?.pricingPlans) return [];
    return siteConfig.pricingPlans.map(plan => ({
      ...plan,
      price: plan.price.toString(),
      period: '/month',
      desc: plan.description,
      features: plan.features.map(fId => siteConfig.features.find(f => f.id === fId)?.title || fId),
      icon: plan.id === 'free' ? <Star className="text-blue-400" /> : plan.id === 'pro' ? <Crown className="text-indigo-400" /> : <Building2 className="text-emerald-400" />,
      color: plan.id === 'free' ? 'border-blue-500/20' : plan.id === 'pro' ? 'border-indigo-500/50' : 'border-emerald-500/20',
      bg: plan.id === 'free' ? 'bg-blue-500/5' : plan.id === 'pro' ? 'bg-indigo-500/10' : 'bg-emerald-500/5',
      current: subscription.plan === plan.id,
      popular: plan.isPopular
    }));
  }, [siteConfig, subscription.plan]);

  useEffect(() => {
    const planId = searchParams.get('plan');
    if (planId && plans.length > 0) {
      const plan = plans.find(p => p.id === planId);
      if (plan && !plan.current) {
        router.push(`/payment?plan=${planId}`);
      }
    }
  }, [searchParams, plans, router]);

  const usagePercentage = subscription.limits.dailyAnalysis > 0 
    ? (usage.dailyCount / subscription.limits.dailyAnalysis) * 100 
    : 0;

  return (
    <AppLayout title="Billing & Subscription">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Current Plan Overview */}
        <div className="glass p-3 md:p-8 rounded-3xl depth-1 border border-indigo-500/20 bg-indigo-500/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-10 opacity-10 pointer-events-none">
            <Zap size={120} className="text-indigo-400" />
          </div>
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 bg-indigo-600 text-white text-[10px] font-bold rounded-full uppercase tracking-widest">Current Plan</span>
                <h2 className="text-3xl font-bold capitalize">{subscription.plan} Plan</h2>
              </div>
              <p className="text-muted-foreground">Your subscription is active and based on your selected package.</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <p className="text-sm font-bold text-indigo-400">Daily Usage</p>
              <div className="flex items-center gap-3">
                <div className="w-48 h-2.5 bg-white/10 rounded-full overflow-hidden border border-white/5">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(usagePercentage, 100)}%` }}
                    className={`h-full ${usagePercentage > 90 ? 'bg-red-500' : 'bg-indigo-500'} rounded-full`} 
                  />
                </div>
                <span className="text-sm font-bold">{usage.dailyCount} / {subscription.limits.dailyAnalysis}</span>
              </div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Analyses today</p>
            </div>
          </div>
        </div>

        {/* Pricing Grid */}
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row justify-between items-end gap-6">
            <div className="space-y-2 text-left">
              <h3 className="text-2xl font-bold">Upgrade Your Experience</h3>
              <p className="text-muted-foreground">Choose the plan that best fits your development workflow.</p>
            </div>
            
            {/* Currency Toggle */}
            <div className="bg-white/5 p-1 rounded-2xl flex items-center border border-white/10">
              <button 
                onClick={() => setCurrency('BDT')}
                className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${currency === 'BDT' ? 'bg-indigo-600 text-white shadow-lg' : 'text-muted-foreground hover:text-white'}`}
              >
                ৳ BDT
              </button>
              <button 
                onClick={() => setCurrency('USD')}
                className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${currency === 'USD' ? 'bg-indigo-600 text-white shadow-lg' : 'text-muted-foreground hover:text-white'}`}
              >
                $ USD
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, idx) => {
              const bdtPrice = parseInt(plan.price);
              const usdPrice = (bdtPrice / (siteConfig.usdExchangeRate || 115)).toFixed(2);
              
              return (
                <motion.div 
                  key={plan.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className={`glass p-3 md:p-8 rounded-3xl depth-1 border ${plan.color} ${plan.bg} flex flex-col space-y-6 md:space-y-8 relative group hover:depth-2 transition-all`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-indigo-600 text-white text-[10px] font-bold rounded-full uppercase tracking-widest shadow-lg shadow-indigo-600/20">
                      Most Popular
                    </div>
                  )}
                  <div className="space-y-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
                      {plan.icon}
                    </div>
                    <div>
                      <h4 className="text-xl font-bold">{plan.name}</h4>
                      <div className="flex items-baseline gap-1 mt-2">
                        <span className="text-3xl font-bold">
                          {currency === 'BDT' ? `৳${bdtPrice.toLocaleString()}` : `$${usdPrice}`}
                        </span>
                        <span className="text-sm text-muted-foreground">{plan.period}</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground font-medium mt-1">
                        {currency === 'BDT' ? `≈ $${usdPrice} USD` : `≈ ৳${bdtPrice.toLocaleString()} BDT`}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 flex-grow">
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">What&apos;s included</p>
                    <ul className="space-y-3">
                      {plan.features.map((feature: string) => (
                        <li key={feature} className="flex items-center gap-3 text-sm">
                          <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                            <Check size={12} />
                          </div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button 
                    onClick={() => router.push(`/payment?plan=${plan.id}`)}
                    disabled={plan.current}
                    className={`w-full py-3 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 ${
                      plan.current 
                        ? 'bg-white/5 text-muted-foreground cursor-default border border-white/10' 
                        : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-600/20'
                    }`}
                  >
                    {plan.current ? 'Current Plan' : 'Upgrade Now'}
                    {!plan.current && <ArrowRight size={16} />}
                  </button>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Subscription Requests History */}
        <div className="glass rounded-3xl depth-1 overflow-hidden">
          <div className="p-4 md:p-8 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <History size={20} className="text-muted-foreground" />
              <h3 className="text-lg font-bold">Subscription Requests</h3>
            </div>
            <p className="text-xs text-muted-foreground">{userRequests.length} Total Requests</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-white/5 text-muted-foreground uppercase text-[10px] font-bold tracking-widest">
                  <th className="px-4 md:px-8 py-4">Plan</th>
                  <th className="px-4 md:px-8 py-4">Date</th>
                  <th className="px-4 md:px-8 py-4">Amount</th>
                  <th className="px-4 md:px-8 py-4">Status</th>
                  <th className="px-4 md:px-8 py-4 text-right">Transaction ID</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {userRequests.length > 0 ? (
                  userRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-4 md:px-8 py-4">
                        <div className="flex items-center gap-2">
                          <span className="font-bold capitalize">{req.planId}</span>
                        </div>
                      </td>
                      <td className="px-4 md:px-8 py-4 text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Calendar size={12} />
                          {req.createdAt?.toDate ? req.createdAt.toDate().toLocaleDateString() : 'Just now'}
                        </div>
                      </td>
                      <td className="px-4 md:px-8 py-4 font-bold">৳{req.amount}</td>
                      <td className="px-4 md:px-8 py-4">
                        <div className="flex items-center gap-2">
                          <div className={`flex items-center justify-center w-6 h-6 rounded-full border ${
                            req.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                            req.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                            'bg-rose-500/10 text-rose-400 border-rose-500/20'
                          }`}>
                            {req.status === 'pending' && <Clock size={12} />}
                            {req.status === 'approved' && <CheckCircle2 size={12} />}
                            {req.status === 'rejected' && <XCircle size={12} />}
                          </div>
                          <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border ${
                            req.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                            req.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                            'bg-rose-500/10 text-rose-400 border-rose-500/20'
                          }`}>
                            {req.status}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 md:px-8 py-4 text-right font-mono text-[10px] text-muted-foreground">
                        {req.transactionId}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 md:px-8 py-12 text-center text-muted-foreground">
                      No subscription requests found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Payment Method */}
        <div className="glass p-8 rounded-3xl depth-1 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-6">
            <div className="w-16 h-10 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center">
              <CreditCard size={24} className="text-muted-foreground" />
            </div>
            <div>
              <h4 className="font-bold">Visa ending in 4242</h4>
              <p className="text-xs text-muted-foreground">Expires 12/2028</p>
            </div>
          </div>
          <button className="px-6 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-bold transition-all">
            Update Payment Method
          </button>
        </div>
      </div>
    </AppLayout>
  );
}

function InvoiceRow({ id, date, amount, status }: { id: string, date: string, amount: string, status: string }) {
  return (
    <tr className="hover:bg-white/5 transition-colors">
      <td className="px-8 py-4 font-mono text-xs">{id}</td>
      <td className="px-8 py-4 text-muted-foreground">{date}</td>
      <td className="px-8 py-4 font-bold">{amount}</td>
      <td className="px-8 py-4">
        <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-[10px] font-bold uppercase tracking-widest border border-emerald-500/20">
          {status}
        </span>
      </td>
      <td className="px-8 py-4 text-right">
        <button className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-muted-foreground hover:text-white transition-all">
          <Download size={14} />
        </button>
      </td>
    </tr>
  );
}

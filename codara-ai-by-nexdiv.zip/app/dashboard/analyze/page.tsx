'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Github, Upload, Loader2, AlertCircle, FileArchive, X, CheckSquare, Square, Zap, Sparkles } from 'lucide-react';
import { generateAIContent, generateAIImage, Type } from '@/lib/ai-service';
import JSZip from 'jszip';
import { db, isFirebaseConfigured } from '@/lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import AppLayout from '@/components/AppLayout';
import { useAppContext, AnalysisStep } from '@/lib/AppContext';
import { useRouter } from 'next/navigation';

const hashString = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
};

const safeSetStorage = (storage: Storage, key: string, value: string) => {
  try {
    storage.setItem(key, value);
  } catch (e) {
    console.warn('Storage quota exceeded. Attempting to clear old analysis cache...');
    
    // Try to clear only analysis related keys first to be less destructive
    try {
      const keysToRemove = [];
      for (let i = 0; i < storage.length; i++) {
        const k = storage.key(i);
        if (k && k.startsWith('analysis_')) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach(k => storage.removeItem(k));
      
      // Try setting again
      storage.setItem(key, value);
    } catch (e2) {
      // If it still fails, the item itself might be too large for the quota
      console.warn('Analysis result too large for browser storage. Skipping cache.', e2);
    }
  }
};

interface FileItem {
  path: string;
  content: string;
  selected: boolean;
}

export default function AnalyzePage() {
  const router = useRouter();
  const { setAnalysisResult, apiKeys, currentKeyIndex, setCurrentKeyIndex, analysisStep, setAnalysisStep, incrementUsage } = useAppContext();
  
  const [repoUrl, setRepoUrl] = useState('');
  const [codeSnippet, setCodeSnippet] = useState('');
  const [zipFile, setZipFile] = useState<File | null>(null);
  const [availableFiles, setAvailableFiles] = useState<FileItem[]>([]);
  const [showFileSelector, setShowFileSelector] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);

  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.type !== 'application/zip' && !file.name.endsWith('.zip')) {
      setError('Please upload a valid ZIP file.');
      return;
    }

    setZipFile(file);
    setRepoUrl('');
    setCodeSnippet('');
    setAvailableFiles([]);
    setError(null);
    setIsProcessingFile(true);

    try {
      const zip = new JSZip();
      const content = await zip.loadAsync(file);
      const newFiles: FileItem[] = [];

      const files = Object.keys(content.files);
      const maxFiles = 20;
      for (const filename of files) {
        if (newFiles.length >= maxFiles) break;
        
        const fileObj = content.files[filename];
        if (fileObj.dir) continue;

        if (
          filename.includes('node_modules/') || 
          filename.includes('.git/') ||
          /\.(jpg|jpeg|png|gif|ico|pdf|zip|tar|gz|exe|dll|so|dylib|bin|obj|o)$/i.test(filename)
        ) continue;

        const text = await fileObj.async('string');
        newFiles.push({ path: filename, content: text, selected: true });
      }

      setAvailableFiles(newFiles);
      setShowFileSelector(true);
    } catch (err) {
      console.error('Failed to process ZIP:', err);
      setError('Failed to process ZIP file. It might be corrupted or too large.');
    } finally {
      setIsProcessingFile(false);
    }
  };

  const fetchGitHubRepo = async (url: string) => {
    try {
      // Improved regex to handle various GitHub URL formats
      const match = url.match(/github\.com\/([^/]+)\/([^/?#]+)/);
      if (!match) throw new Error('Invalid GitHub URL. Please use format: https://github.com/owner/repo');
      const owner = match[1];
      const repo = match[2].replace(/\.git$/, '');
      
      setIsProcessingFile(true);
      setAnalysisStep('fetching');
      setError(null);
      setZipFile(null);
      setCodeSnippet('');
      setAvailableFiles([]);

      const repoCacheKey = `repo_${owner}_${repo}`;
      const cachedRepo = sessionStorage.getItem(repoCacheKey);
      if (cachedRepo) {
        setAvailableFiles(JSON.parse(cachedRepo));
        setShowFileSelector(true);
        setIsProcessingFile(false);
        setAnalysisStep('idle');
        return "SUCCESS";
      }

      const repoRes = await fetch(`https://api.github.com/repos/${owner}/${repo}`);
      if (!repoRes.ok) {
        if (repoRes.status === 404) throw new Error('Repository not found. Please check the URL and ensure it is public.');
        if (repoRes.status === 403) throw new Error('GitHub API rate limit exceeded. Please try again later.');
        throw new Error(`Failed to fetch repository info (Status: ${repoRes.status}).`);
      }
      const repoData = await repoRes.json();
      
      // Check repository size (in KB)
      if (repoData.size > 50000) { // 50MB limit
        throw new Error('Repository is too large to analyze. Please provide a smaller repository or upload a ZIP file of specific directories.');
      }

      const defaultBranch = repoData.default_branch;

      const treeRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/trees/${defaultBranch}?recursive=1`);
      if (!treeRes.ok) {
        if (treeRes.status === 403) throw new Error('GitHub API rate limit exceeded while fetching tree. Please try again later.');
        throw new Error('Failed to fetch repository tree. The repository might be too large, empty, or inaccessible.');
      }
      const treeData = await treeRes.json();
      
      if (treeData.truncated) {
        throw new Error('Repository tree is too large. Please provide a smaller repository or upload a ZIP file.');
      }

      const maxFiles = 15; // Reduced for faster processing
      const validItems = treeData.tree.filter((item: any) => {
        if (item.type !== 'blob') return false;
        const path = item.path;
        if (
          path.includes('node_modules/') || 
          path.includes('.git/') ||
          path.includes('dist/') ||
          path.includes('build/') ||
          /\.(jpg|jpeg|png|gif|ico|pdf|zip|tar|gz|exe|dll|so|dylib|bin|obj|o|lock|svg|woff|woff2|ttf|eot)$/i.test(path)
        ) return false;
        return true;
      }).slice(0, maxFiles);

      const fetchPromises = validItems.map(async (item: any) => {
        try {
          const fileRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${item.path}`);
          if (fileRes.ok) {
            const fileData = await fileRes.json();
            if (fileData.content) {
              const base64 = fileData.content.replace(/\n/g, '');
              const text = decodeURIComponent(Array.prototype.map.call(atob(base64), (c: any) => {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
              }).join(''));
              return { path: item.path, content: text, selected: true };
            }
          }
        } catch (e) {
          console.warn(`Failed to fetch ${item.path}`, e);
        }
        return null;
      });

      const newFiles = (await Promise.all(fetchPromises)).filter(Boolean) as FileItem[];

      safeSetStorage(sessionStorage, repoCacheKey, JSON.stringify(newFiles));

      setAvailableFiles(newFiles);
      setShowFileSelector(true);
      return "SUCCESS";
    } catch (err: any) {
      console.error('GitHub Fetch Error:', err);
      setError(err.message || 'Failed to fetch GitHub repository.');
      return null;
    } finally {
      setIsProcessingFile(false);
    }
  };

  const handleAnalyze = async (singleFile?: FileItem) => {
    let finalCodeContent = '';
    
    if (singleFile) {
      setAnalysisStep('analyzing');
      finalCodeContent = `\n--- FILE: ${singleFile.path} ---\n${singleFile.content}\n`;
    } else if (availableFiles.length > 0) {
      setAnalysisStep('analyzing');
      finalCodeContent = availableFiles
        .filter(f => f.selected)
        .map(f => `\n--- FILE: ${f.path} ---\n${f.content}\n`)
        .join('');
    } else if (codeSnippet) {
      setAnalysisStep('analyzing');
      finalCodeContent = codeSnippet;
    } else if (repoUrl) {
      try {
        const fetched = await fetchGitHubRepo(repoUrl);
        if (fetched === "SUCCESS") return;
      } catch (err: any) {
        setError(err.message || 'Failed to fetch GitHub repository.');
        setAnalysisStep('idle');
        return;
      }
    }

    if (!finalCodeContent && !repoUrl && !codeSnippet) return;
    if (availableFiles.length > 0 && !singleFile && !availableFiles.some(f => f.selected)) {
      setError('Please select at least one file to analyze.');
      return;
    }

    if (apiKeys.length === 0) {
      setError('No API keys configured. Please add an API key in the Admin Panel.');
      return;
    }

    const canProceed = await incrementUsage();
    if (!canProceed) {
      setError('You have reached your daily analysis limit. Please upgrade your plan.');
      return;
    }

    setAnalysisStep('analyzing');
    setError(null);
    
    const prompt = `
      Codebase Context:
      ${repoUrl ? `- Repository URL: ${repoUrl}` : ''}
      ${zipFile ? `- Uploaded Files from: ${zipFile.name}` : ''}
      ${codeSnippet ? '- Provided Code Snippet' : ''}
      
      ACTUAL CODE CONTENT TO ANALYZE:
      ${finalCodeContent || (repoUrl ? "No code provided, only the URL. Please provide a general overview if you recognize this repository, otherwise ask for more details." : "N/A")}

      Your Task:
      1. Deeply analyze the provided code logic, structure, and dependencies.
      2. Generate a professional, high-quality README.md that accurately reflects the ACTUAL implementation. The README MUST include these EXACT sections in this order:
         - **Project Title**: A catchy and descriptive title.
         - **Hero Image**: Use the placeholder [Hero Image] here.
         - **Project Description & Goals**: A clear, engaging explanation of what the project does, the specific problems it solves, and its primary objectives.
         - **Prerequisites & Installation**: Comprehensive, step-by-step instructions. Include:
             - **Prerequisites**: Required software (e.g., Node.js, Python, Docker) and versions.
             - **Environment Setup**: How to configure environment variables (e.g., .env.example).
             - **Installation**: Commands to install dependencies and build the project.
         - **Usage Guide**: Detailed, step-by-step examples of how to use the project. Include:
             - **Getting Started**: The first steps a user should take.
             - **Core Features**: Examples of primary functionality with command-line snippets, code examples, or API usage.
             - **Visuals**: Use the placeholder [Feature Screenshot] to represent a screenshot or GIF of a key feature in action.
         - **Contribution Guidelines**: Clear instructions on how others can contribute to the project (e.g., branching, PRs, code style).
         - **License**: The project's licensing information. Detect from the repository if possible. If not found, default to MIT and provide a placeholder (e.g., "[Confirm License: MIT]") for the user to confirm.
         - **Contact & Support**: Support links, social media, or email placeholders for users to get help.
      3. Identify the core tech stack (languages, frameworks, libraries) as an array of strings.
      4. Document the top 3-5 most important functions and classes with technical precision, including parameter types, return types, and a clear example usage snippet for each.
      5. Create a system architecture diagram (Mermaid graph TD) showing how components interact.
      6. Create a sequence diagram (Mermaid sequenceDiagram) for the primary user flow or data processing path.
      7. Provide a vivid prompt for a **Hero Image** (high-level visual).
      8. Provide a vivid prompt for a **Feature Screenshot** (detailed illustrative visual of the app in action).
      9. Analyze Code Health & Complexity: Provide an overall health score (0-100), health data categories (Security, Docs, Quality, Testing with scores 0-100), and complexity data by module/component (score 0-100). Additionally, provide detailed code health metrics including cyclomatic complexity, test coverage, maintainability index, code smells, potential bugs, coverage by module, and a list of the most complex files and specific bugs.
      10. Identify Security Issues: List up to 3 potential vulnerabilities, hardcoded secrets, or bad practices with their severity (Critical, Medium, Low), description, and file path.

      Constraint: Do not hallucinate features. If a section cannot be determined from the code, provide a sensible template for the user to fill in.
    `;

    const tryAnalyze = async (): Promise<any> => {
      const contentHash = hashString(finalCodeContent);
      const cacheKey = `analysis_${contentHash}`;
      const cachedAnalysis = localStorage.getItem(cacheKey);
      
      if (cachedAnalysis) {
        try {
          const result = JSON.parse(cachedAnalysis);
          setAnalysisStep('finalizing');
          setAnalysisResult(result);
          router.push('/dashboard');
          setAnalysisStep('idle');
          return;
        } catch (e) {
          console.warn('Failed to parse cached analysis', e);
        }
      }

      if (!apiKeys || apiKeys.length === 0) {
        throw new Error('API Key not set. Please add an API key in the Admin Panel.');
      }
      
      try {
        const systemInstruction = "You are Codara AI, a world-class software architect and technical writer. Your goal is to provide 100% accurate, non-hallucinated documentation based strictly on the code provided. You excel at understanding complex logic, identifying design patterns, and explaining technical concepts clearly. You must follow the requested README structure exactly, providing deep technical detail for installation and usage. If the code is missing or insufficient, you must state that clearly in the README description.";
        
        const responseSchema = {
          type: Type.OBJECT,
          properties: {
            readme: { type: Type.STRING },
            techStack: { type: Type.ARRAY, items: { type: Type.STRING } },
            functions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  params: { type: Type.ARRAY, items: { type: Type.STRING } },
                  returns: { type: Type.STRING },
                  exampleUsage: { type: Type.STRING },
                },
              },
            },
            architecture: { type: Type.STRING },
            flow: { type: Type.STRING },
            heroImagePrompt: { type: Type.STRING },
            featureImagePrompt: { type: Type.STRING },
            overallHealth: { type: Type.NUMBER },
            healthData: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  value: { type: Type.NUMBER }
                }
              }
            },
            complexityData: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  value: { type: Type.NUMBER }
                }
              }
            },
            codeHealth: {
              type: Type.OBJECT,
              properties: {
                metrics: {
                  type: Type.OBJECT,
                  properties: {
                    cyclomaticComplexity: { type: Type.NUMBER },
                    testCoverage: { type: Type.NUMBER },
                    maintainabilityIndex: { type: Type.NUMBER },
                    codeSmells: { type: Type.NUMBER },
                    potentialBugs: { type: Type.NUMBER }
                  }
                },
                coverageByModule: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      coverage: { type: Type.NUMBER }
                    }
                  }
                },
                complexFiles: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      file: { type: Type.STRING },
                      complexity: { type: Type.NUMBER },
                      lines: { type: Type.NUMBER }
                    }
                  }
                },
                bugs: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      desc: { type: Type.STRING },
                      file: { type: Type.STRING },
                      severity: { type: Type.STRING }
                    }
                  }
                }
              }
            },
            securityIssues: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  severity: { type: Type.STRING },
                  desc: { type: Type.STRING },
                  file: { type: Type.STRING }
                }
              }
            }
          },
          required: ['readme', 'techStack', 'functions', 'architecture', 'flow', 'heroImagePrompt', 'featureImagePrompt', 'overallHealth', 'healthData', 'complexityData', 'codeHealth', 'securityIssues'],
        };

        const result = await generateAIContent(prompt, apiKeys, systemInstruction, responseSchema);
        
        if (result && !result.error) {
          setAnalysisStep('finalizing');
          safeSetStorage(localStorage, cacheKey, JSON.stringify(result));
          
          // Show text results immediately
          setAnalysisResult(result);
          router.push('/dashboard');

          // Generate images in background
          try {
            setAnalysisStep('generating_images');
            Promise.all([
              generateAIImage(`A professional, high-tech, 3D illustrative visual for a software project: ${result.heroImagePrompt}. Clean, modern, suitable for a GitHub README.`, apiKeys),
              generateAIImage(`A professional, high-tech, 3D illustrative visual for a software project: ${result.featureImagePrompt}. Clean, modern, suitable for a GitHub README.`, apiKeys)
            ]).then(([heroImg, featureImg]) => {
              setAnalysisResult((prev: any) => {
                if (!prev) return prev;
                const newResult = { ...prev, heroImage: heroImg, featureImage: featureImg };
                if (heroImg) newResult.readme = newResult.readme.replace(/\[Hero Image\]/g, `![Hero Image](${heroImg})`);
                if (featureImg) newResult.readme = newResult.readme.replace(/\[Feature Screenshot\]/g, `![Feature Screenshot](${featureImg})`);
                
                safeSetStorage(localStorage, cacheKey, JSON.stringify(newResult));
                
                return newResult;
              });
              setAnalysisStep('idle');
            }).catch(() => {
              setAnalysisStep('idle');
            });
          } catch (imgErr) {
            console.error('Failed to generate images:', imgErr);
            setAnalysisStep('idle');
          }
          
          // Save to Firebase if configured (in background)
          try {
            if (isFirebaseConfigured && db) {
              const repoName = repoUrl ? repoUrl.split('/').pop() : zipFile ? zipFile.name : 'Code Snippet';
              addDoc(collection(db, 'analyses'), {
                repoName,
                tech: result.techStack?.[0] || 'Unknown',
                health: result.overallHealth || 0,
                repoUrl,
                techStack: result.techStack || [],
                createdAt: serverTimestamp(),
                readmeLength: result.readme.length
              }).catch(console.warn);
            }
          } catch (fbErr) {
            console.warn('Firebase save failed:', fbErr);
          }
        } else {
          setError(result?.error || 'Failed to analyze code.');
          setAnalysisStep('idle');
        }
      } catch (err: any) {
        throw err;
      }
    };

    try {
      await tryAnalyze();
    } catch (err: any) {
      console.error(err);
      let errorMessage = 'An unexpected error occurred during analysis.';
      if (err.message) {
        errorMessage = err.message;
      }
      setError(errorMessage);
      setAnalysisStep('idle');
    }
  };

  return (
    <AppLayout title="Analyze Repository">
      <AnimatePresence mode="wait">
        {analysisStep !== 'idle' ? (
          <motion.div 
            key="loading"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="h-full flex flex-col items-center justify-center space-y-8"
          >
            <div className="relative">
              <div className="w-32 h-32 rounded-3xl bg-indigo-500/10 flex items-center justify-center animate-pulse">
                <Zap size={48} className="text-indigo-500" />
              </div>
              <div className="absolute inset-0 border-4 border-indigo-500/20 rounded-3xl animate-[spin_4s_linear_infinite]" />
            </div>
            
            <div className="space-y-4 w-full max-w-md">
              <StepItem active={analysisStep === 'fetching'} done={['analyzing', 'generating_images', 'finalizing'].includes(analysisStep)} label="Fetching Repository Data" />
              <StepItem active={analysisStep === 'analyzing'} done={['generating_images', 'finalizing'].includes(analysisStep)} label="Analyzing Code Logic & Structure" />
              <StepItem active={analysisStep === 'generating_images'} done={['finalizing'].includes(analysisStep)} label="Generating 3D Visual Assets" />
              <StepItem active={analysisStep === 'finalizing'} done={false} label="Finalizing Documentation" />
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="import"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto mt-8 space-y-10"
          >
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-gradient">Intelligent Code Analysis</h2>
              <p className="text-muted-foreground text-base md:text-lg max-w-xl mx-auto">Codara AI deeply understands your codebase to generate professional-grade intelligence and documentation.</p>
            </div>

            <div className="glass p-3 md:p-8 space-y-6 md:space-y-8 depth-2 rounded-3xl">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div className="space-y-2 md:space-y-4">
                  <label className="text-xs md:text-sm font-semibold ml-1">GitHub Repository</label>
                  <div className="relative">
                    <Github className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
                    <input 
                      type="text" 
                      value={repoUrl}
                      onChange={(e) => {
                        setRepoUrl(e.target.value);
                        if (availableFiles.length > 0) setAvailableFiles([]);
                      }}
                      placeholder="https://github.com/..." 
                      className="w-full bg-muted border border-border rounded-xl md:rounded-2xl pl-10 md:pl-12 pr-4 py-2.5 md:py-3.5 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-2 md:space-y-4">
                  <label className="text-xs md:text-sm font-semibold ml-1">Upload ZIP</label>
                  <label className={`flex items-center gap-2 md:gap-3 bg-muted border border-border rounded-xl md:rounded-2xl px-3 md:px-4 py-2.5 md:py-3.5 transition-all group ${isProcessingFile ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer hover:bg-muted/80'}`}>
                    {isProcessingFile && zipFile ? (
                      <Loader2 size={18} className="text-primary animate-spin" />
                    ) : (
                      <FileArchive size={18} className="text-muted-foreground group-hover:text-primary transition-colors" />
                    )}
                    <span className="text-xs md:text-sm text-muted-foreground truncate flex-1">{zipFile ? zipFile.name : 'Choose ZIP file...'}</span>
                    <input type="file" accept=".zip" className="hidden" onChange={handleZipUpload} disabled={isProcessingFile} />
                    {zipFile && !isProcessingFile && <X size={14} className="text-destructive hover:scale-110 transition-transform" onClick={(e) => { e.preventDefault(); setZipFile(null); setAvailableFiles([]); }} />}
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-sm font-semibold ml-1">Paste Code Snippet</label>
                <textarea
                  value={codeSnippet}
                  onChange={(e) => {
                    setCodeSnippet(e.target.value);
                    if (availableFiles.length > 0) setAvailableFiles([]);
                  }}
                  placeholder="Paste your code here..."
                  className="w-full h-40 bg-muted border border-border rounded-2xl p-5 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
                />
              </div>

              <AnimatePresence>
              {error && (
                <motion.div 
                  initial={{ opacity: 0, y: -10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, height: 0, scale: 0.95, transition: { duration: 0.2 } }}
                  className="bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl p-4 flex items-start gap-3 text-sm relative overflow-hidden"
                >
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-red-500" />
                  <AlertCircle size={18} className="mt-0.5 shrink-0" />
                  <div className="flex-1">
                    <p className="font-semibold">Error</p>
                    <p className="text-red-400/80">{error}</p>
                  </div>
                  <button onClick={() => setError(null)} className="text-red-400/60 hover:text-red-400 transition-colors">
                    <X size={16} />
                  </button>
                </motion.div>
              )}
              </AnimatePresence>

              {availableFiles.length > 0 && (
                <div className="space-y-4 border-t border-border pt-6">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold">Select Files ({availableFiles.filter(f => f.selected).length})</label>
                    <button 
                      onClick={() => setAvailableFiles(prev => prev.map(f => ({ ...f, selected: !prev.every(x => x.selected) })))}
                      className="text-xs text-primary font-medium hover:underline"
                    >
                      {availableFiles.every(f => f.selected) ? 'Deselect All' : 'Select All'}
                    </button>
                  </div>
                  <div className="max-h-52 overflow-y-auto border border-border rounded-2xl bg-muted divide-y divide-white/5">
                    <AnimatePresence>
                    {availableFiles.map((file, idx) => (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: Math.min(idx * 0.02, 0.5) }}
                        key={file.path} 
                        className="flex items-center gap-3 p-3.5 hover:bg-muted transition-colors cursor-pointer"
                        onClick={() => {
                          const newFiles = [...availableFiles];
                          newFiles[idx].selected = !newFiles[idx].selected;
                          setAvailableFiles(newFiles);
                        }}
                      >
                        <div className="relative w-[18px] h-[18px]">
                          <AnimatePresence initial={false} mode="wait">
                            {file.selected ? (
                              <motion.div
                                key="selected"
                                initial={{ scale: 0.5, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                exit={{ scale: 0.5, opacity: 0 }}
                                transition={{ type: "spring", stiffness: 500, damping: 30 }}
                              >
                                <CheckSquare size={18} className="text-primary" />
                              </motion.div>
                            ) : (
                              <motion.div
                                key="unselected"
                                initial={{ scale: 0.5, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                exit={{ scale: 0.5, opacity: 0 }}
                                transition={{ type: "spring", stiffness: 500, damping: 30 }}
                              >
                                <Square size={18} className="text-muted-foreground" />
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                        <span className="text-xs font-mono truncate text-muted-foreground">{file.path}</span>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAnalyze(file);
                          }}
                          className="text-xs text-primary font-medium hover:underline ml-auto"
                        >
                          Analyze
                        </button>
                      </motion.div>
                    ))}
                    </AnimatePresence>
                  </div>
                </div>
              )}

              <button 
                onClick={() => handleAnalyze()}
                disabled={(!repoUrl && !codeSnippet && availableFiles.length === 0) || analysisStep !== 'idle' || isProcessingFile}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-foreground px-6 py-3 md:py-4 rounded-2xl font-bold hover:opacity-90 transition-all depth-1 hover:depth-2 disabled:opacity-50 flex items-center justify-center gap-3 text-base md:text-lg"
              >
                {isProcessingFile ? (
                  <>
                    <Loader2 size={22} className="animate-spin" />
                    Processing Files...
                  </>
                ) : (
                  <>
                    <Sparkles size={22} />
                    Generate Documentation
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </AppLayout>
  );
}

function StepItem({ active, done, label }: { active: boolean, done: boolean, label: string }) {
  return (
    <motion.div 
      initial={false}
      animate={{ 
        scale: active ? 1.02 : 1,
        backgroundColor: active ? 'rgba(99, 102, 241, 0.1)' : done ? 'rgba(16, 185, 129, 0.05)' : 'rgba(255, 255, 255, 0.05)',
        borderColor: active ? 'rgba(99, 102, 241, 0.3)' : done ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255, 255, 255, 0.05)'
      }}
      className="flex items-center gap-4 p-4 rounded-2xl border transition-all"
    >
      <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors duration-500 ${active ? 'bg-indigo-500 text-foreground' : done ? 'bg-emerald-500 text-foreground' : 'bg-muted/80'}`}>
        <AnimatePresence mode="wait">
          {done ? (
            <motion.div
              key="done"
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <CheckSquare size={14} />
            </motion.div>
          ) : active ? (
            <motion.div
              key="active"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <Loader2 size={14} className="animate-spin" />
            </motion.div>
          ) : (
            <motion.div
              key="idle"
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
              className="w-2 h-2 rounded-full bg-white/20"
            />
          )}
        </AnimatePresence>
      </div>
      <span className={`text-sm font-medium transition-colors duration-500 ${active ? 'text-indigo-400' : done ? 'text-emerald-400' : 'text-muted-foreground'}`}>{label}</span>
    </motion.div>
  );
}

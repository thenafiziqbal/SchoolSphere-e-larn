'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  Github, 
  Upload, 
  Loader2, 
  AlertCircle, 
  FileArchive, 
  X, 
  CheckSquare, 
  Square, 
  Sparkles,
  Download,
  Copy,
  Check
} from 'lucide-react';
import { generateAIContent, Type } from '@/lib/ai-service';
import JSZip from 'jszip';
import AppLayout from '@/components/AppLayout';
import { useAppContext } from '@/lib/AppContext';
import Markdown from 'react-markdown';

interface FileItem {
  path: string;
  content: string;
  selected: boolean;
}

interface GeneratedDoc {
  filename: string;
  content: string;
}

export default function DocsGeneratorPage() {
  const { apiKeys, currentKeyIndex, setCurrentKeyIndex, incrementUsage } = useAppContext();
  
  const [repoUrl, setRepoUrl] = useState('');
  const [codeSnippet, setCodeSnippet] = useState('');
  const [zipFile, setZipFile] = useState<File | null>(null);
  const [availableFiles, setAvailableFiles] = useState<FileItem[]>([]);
  const [showFileSelector, setShowFileSelector] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDocs, setGeneratedDocs] = useState<GeneratedDoc[]>([]);
  const [activeDoc, setActiveDoc] = useState<string | null>(null);
  const [isCopying, setIsCopying] = useState(false);

  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.type !== 'application/zip' && !file.name.endsWith('.zip')) {
      setError('Please upload a valid ZIP file.');
      return;
    }

    setZipFile(file);
    setRepoUrl('');
    setCodeSnippet('');
    setAvailableFiles([]);
    setError(null);
    setIsProcessingFile(true);

    try {
      const zip = new JSZip();
      const content = await zip.loadAsync(file);
      const newFiles: FileItem[] = [];

      const files = Object.keys(content.files);
      const maxFiles = 20;
      for (const filename of files) {
        if (newFiles.length >= maxFiles) break;
        
        const fileObj = content.files[filename];
        if (fileObj.dir) continue;

        if (
          filename.includes('node_modules/') || 
          filename.includes('.git/') ||
          /\.(jpg|jpeg|png|gif|ico|pdf|zip|tar|gz|exe|dll|so|dylib|bin|obj|o)$/i.test(filename)
        ) continue;

        const text = await fileObj.async('string');
        newFiles.push({ path: filename, content: text, selected: true });
      }

      setAvailableFiles(newFiles);
      setShowFileSelector(true);
    } catch (err) {
      console.error('Failed to process ZIP:', err);
      setError('Failed to process ZIP file. It might be corrupted or too large.');
    } finally {
      setIsProcessingFile(false);
    }
  };

  const fetchGitHubRepo = async (url: string) => {
    try {
      const match = url.match(/github\.com\/([^/]+)\/([^/?#]+)/);
      if (!match) throw new Error('Invalid GitHub URL. Please use format: https://github.com/owner/repo');
      const owner = match[1];
      const repo = match[2].replace(/\.git$/, '');
      
      setIsProcessingFile(true);
      setError(null);
      setZipFile(null);
      setCodeSnippet('');
      setAvailableFiles([]);

      const repoRes = await fetch(`https://api.github.com/repos/${owner}/${repo}`);
      if (!repoRes.ok) {
        if (repoRes.status === 404) throw new Error('Repository not found. Please check the URL and ensure it is public.');
        if (repoRes.status === 403) throw new Error('GitHub API rate limit exceeded. Please try again later.');
        throw new Error(`Failed to fetch repository info (Status: ${repoRes.status}).`);
      }
      const repoData = await repoRes.json();
      
      if (repoData.size > 50000) {
        throw new Error('Repository is too large to analyze. Please provide a smaller repository or upload a ZIP file of specific directories.');
      }

      const defaultBranch = repoData.default_branch;

      const treeRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/trees/${defaultBranch}?recursive=1`);
      if (!treeRes.ok) {
        if (treeRes.status === 403) throw new Error('GitHub API rate limit exceeded while fetching tree. Please try again later.');
        throw new Error('Failed to fetch repository tree. The repository might be too large, empty, or inaccessible.');
      }
      const treeData = await treeRes.json();
      
      if (treeData.truncated) {
        throw new Error('Repository tree is too large. Please provide a smaller repository or upload a ZIP file.');
      }

      const maxFiles = 15;
      const validItems = treeData.tree.filter((item: any) => {
        if (item.type !== 'blob') return false;
        const path = item.path;
        if (
          path.includes('node_modules/') || 
          path.includes('.git/') ||
          path.includes('dist/') ||
          path.includes('build/') ||
          /\.(jpg|jpeg|png|gif|ico|pdf|zip|tar|gz|exe|dll|so|dylib|bin|obj|o|lock|svg|woff|woff2|ttf|eot)$/i.test(path)
        ) return false;
        return true;
      }).slice(0, maxFiles);

      const fetchPromises = validItems.map(async (item: any) => {
        try {
          const fileRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${item.path}`);
          if (fileRes.ok) {
            const fileData = await fileRes.json();
            if (fileData.content) {
              const base64 = fileData.content.replace(/\n/g, '');
              const text = decodeURIComponent(Array.prototype.map.call(atob(base64), (c: any) => {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
              }).join(''));
              return { path: item.path, content: text, selected: true };
            }
          }
        } catch (e) {
          console.warn(`Failed to fetch ${item.path}`, e);
        }
        return null;
      });

      const newFiles = (await Promise.all(fetchPromises)).filter(Boolean) as FileItem[];

      setAvailableFiles(newFiles);
      setShowFileSelector(true);
      return "SUCCESS";
    } catch (err: any) {
      console.error('GitHub Fetch Error:', err);
      setError(err.message || 'Failed to fetch GitHub repository.');
      return null;
    } finally {
      setIsProcessingFile(false);
    }
  };

  const handleGenerateDocs = async (singleFile?: FileItem) => {
    let finalCodeContent = '';
    
    if (singleFile) {
      finalCodeContent = `\n--- FILE: ${singleFile.path} ---\n${singleFile.content}\n`;
    } else if (availableFiles.length > 0) {
      finalCodeContent = availableFiles
        .filter(f => f.selected)
        .map(f => `\n--- FILE: ${f.path} ---\n${f.content}\n`)
        .join('');
    } else if (codeSnippet) {
      finalCodeContent = codeSnippet;
    } else if (repoUrl) {
      try {
        const fetched = await fetchGitHubRepo(repoUrl);
        if (fetched === "SUCCESS") return;
      } catch (err: any) {
        setError(err.message || 'Failed to fetch GitHub repository.');
        return;
      }
    }

    if (!finalCodeContent && !repoUrl && !codeSnippet) return;
    if (availableFiles.length > 0 && !singleFile && !availableFiles.some(f => f.selected)) {
      setError('Please select at least one file to analyze.');
      return;
    }

    if (apiKeys.length === 0) {
      setError('No API keys configured. Please add an API key in the Admin Panel.');
      return;
    }

    const canProceed = await incrementUsage();
    if (!canProceed) {
      setError('You have reached your daily limit. Please upgrade your plan.');
      return;
    }

    setIsGenerating(true);
    setError(null);
    setGeneratedDocs([]);
    
    const prompt = `
      You are an expert technical writer and software architect.
      Analyze the following codebase and generate a complete, professional documentation suite.
      
      Codebase Context:
      ${repoUrl ? `- Repository URL: ${repoUrl}` : ''}
      ${zipFile ? `- Uploaded Files from: ${zipFile.name}` : ''}
      ${codeSnippet ? '- Provided Code Snippet' : ''}
      
      ACTUAL CODE CONTENT TO ANALYZE:
      ${finalCodeContent || "No code provided, only the URL. Please provide a general overview if you recognize this repository."}

      Your Task:
      Generate 4 distinct markdown files based on the codebase:
      1. README.md: A comprehensive overview, installation instructions, usage, and features.
      2. CONTRIBUTING.md: Guidelines for contributing, setting up the dev environment, and PR process.
      3. ARCHITECTURE.md: Deep dive into the system architecture, component interactions, and design patterns used.
      4. API.md: Documentation of the core functions, classes, or API endpoints found in the code.

      Return the result as a JSON array of objects, where each object has a 'filename' and 'content' (the markdown string).
    `;

    const tryGenerate = async (): Promise<any> => {
      if (!apiKeys || apiKeys.length === 0) {
        throw new Error('API Key not set. Please add an API key in the Admin Panel.');
      }
      
      try {
        const systemInstruction = "You are an expert technical writer. You must return a JSON array of objects with 'filename' and 'content' properties.";
        const responseSchema = {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              filename: { type: Type.STRING },
              content: { type: Type.STRING }
            },
            required: ['filename', 'content']
          }
        };

        const result = await generateAIContent(prompt, apiKeys, systemInstruction, responseSchema);
        
        if (result && Array.isArray(result) && result.length > 0) {
          setGeneratedDocs(result);
          setActiveDoc(result[0].filename);
        } else {
          setError('Failed to generate documentation. The AI returned an empty response.');
        }
      } catch (err: any) {
        throw err;
      }
    };

    try {
      await tryGenerate();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An unexpected error occurred during generation.');
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadAllDocs = async () => {
    if (generatedDocs.length === 0) return;
    
    const zip = new JSZip();
    const docsFolder = zip.folder("docs");
    
    if (docsFolder) {
      generatedDocs.forEach(doc => {
        docsFolder.file(doc.filename, doc.content);
      });
      
      const content = await zip.generateAsync({ type: "blob" });
      
      // Create a download link
      const url = window.URL.createObjectURL(content);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'generated-docs.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    }
  };

  const activeContent = generatedDocs.find(d => d.filename === activeDoc)?.content || '';

  return (
    <AppLayout title="Docs Generator">
      <div className="max-w-5xl mx-auto mt-8 space-y-10">
        <div className="text-center space-y-4">
          <h2 className="text-5xl font-bold tracking-tight text-gradient">AI Docs Generator</h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">Automatically generate comprehensive markdown documentation (README, API, Architecture, etc.) for your codebase.</p>
        </div>

        {!generatedDocs.length ? (
          <div className="glass p-8 space-y-8 depth-2 rounded-3xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <label className="text-sm font-semibold ml-1">GitHub Repository</label>
                <div className="relative">
                  <Github className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <input 
                    type="text" 
                    value={repoUrl}
                    onChange={(e) => {
                      setRepoUrl(e.target.value);
                      if (availableFiles.length > 0) setAvailableFiles([]);
                    }}
                    placeholder="https://github.com/..." 
                    className="w-full bg-muted border border-border rounded-2xl pl-12 pr-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-sm font-semibold ml-1">Upload ZIP</label>
                <label className={`flex items-center gap-3 bg-muted border border-border rounded-2xl px-4 py-3.5 transition-all group ${isProcessingFile ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer hover:bg-muted/80'}`}>
                  {isProcessingFile && zipFile ? (
                    <Loader2 size={20} className="text-primary animate-spin" />
                  ) : (
                    <FileArchive size={20} className="text-muted-foreground group-hover:text-primary transition-colors" />
                  )}
                  <span className="text-sm text-muted-foreground truncate flex-1">{zipFile ? zipFile.name : 'Choose ZIP file...'}</span>
                  <input type="file" accept=".zip" className="hidden" onChange={handleZipUpload} disabled={isProcessingFile} />
                  {zipFile && !isProcessingFile && <X size={16} className="text-destructive hover:scale-110 transition-transform" onClick={(e) => { e.preventDefault(); setZipFile(null); setAvailableFiles([]); }} />}
                </label>
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-sm font-semibold ml-1">Paste Code Snippet</label>
              <textarea
                value={codeSnippet}
                onChange={(e) => {
                  setCodeSnippet(e.target.value);
                  if (availableFiles.length > 0) setAvailableFiles([]);
                }}
                placeholder="Paste your code here..."
                className="w-full h-40 bg-muted border border-border rounded-2xl p-5 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
              />
            </div>

            <AnimatePresence>
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, height: 0, scale: 0.95, transition: { duration: 0.2 } }}
                className="bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl p-4 flex items-start gap-3 text-sm relative overflow-hidden"
              >
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-red-500" />
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <div className="flex-1">
                  <p className="font-semibold">Error</p>
                  <p className="text-red-400/80">{error}</p>
                </div>
                <button onClick={() => setError(null)} className="text-red-400/60 hover:text-red-400 transition-colors">
                  <X size={16} />
                </button>
              </motion.div>
            )}
            </AnimatePresence>

            {availableFiles.length > 0 && (
              <div className="space-y-4 border-t border-border pt-6">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-semibold">Select Files ({availableFiles.filter(f => f.selected).length})</label>
                  <button 
                    onClick={() => setAvailableFiles(prev => prev.map(f => ({ ...f, selected: !prev.every(x => x.selected) })))}
                    className="text-xs text-primary font-medium hover:underline"
                  >
                    {availableFiles.every(f => f.selected) ? 'Deselect All' : 'Select All'}
                  </button>
                </div>
                <div className="max-h-52 overflow-y-auto border border-border rounded-2xl bg-muted divide-y divide-white/5">
                  <AnimatePresence>
                  {availableFiles.map((file, idx) => (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: Math.min(idx * 0.02, 0.5) }}
                      key={file.path} 
                      className="flex items-center gap-3 p-3.5 hover:bg-muted transition-colors cursor-pointer"
                      onClick={() => {
                        const newFiles = [...availableFiles];
                        newFiles[idx].selected = !newFiles[idx].selected;
                        setAvailableFiles(newFiles);
                      }}
                    >
                      <div className="relative w-[18px] h-[18px]">
                        <AnimatePresence initial={false} mode="wait">
                          {file.selected ? (
                            <motion.div
                              key="selected"
                              initial={{ scale: 0.5, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0.5, opacity: 0 }}
                              transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            >
                              <CheckSquare size={18} className="text-primary" />
                            </motion.div>
                          ) : (
                            <motion.div
                              key="unselected"
                              initial={{ scale: 0.5, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0.5, opacity: 0 }}
                              transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            >
                              <Square size={18} className="text-muted-foreground" />
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                      <span className="text-xs font-mono truncate text-muted-foreground">{file.path}</span>
                    </motion.div>
                  ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            <button 
              onClick={() => handleGenerateDocs()}
              disabled={(!repoUrl && !codeSnippet && availableFiles.length === 0) || isGenerating || isProcessingFile}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-foreground px-6 py-4 rounded-2xl font-bold hover:opacity-90 transition-all depth-1 hover:depth-2 disabled:opacity-50 flex items-center justify-center gap-3 text-lg"
            >
              {isGenerating ? (
                <>
                  <Loader2 size={22} className="animate-spin" />
                  Generating Documentation...
                </>
              ) : (
                <>
                  <Sparkles size={22} />
                  Generate Markdown Docs
                </>
              )}
            </button>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-2">
                {generatedDocs.map((doc) => (
                  <button
                    key={doc.filename}
                    onClick={() => setActiveDoc(doc.filename)}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap border ${
                      activeDoc === doc.filename 
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/20' 
                        : 'text-muted-foreground hover:bg-muted hover:text-foreground border-transparent'
                    }`}
                  >
                    <FileText size={16} />
                    {doc.filename}
                  </button>
                ))}
              </div>
              
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => {
                    setGeneratedDocs([]);
                    setActiveDoc(null);
                  }}
                  className="px-4 py-2 bg-muted hover:bg-muted/80 rounded-xl text-sm font-medium transition-all"
                >
                  Generate New
                </button>
                <button 
                  onClick={downloadAllDocs}
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-foreground px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-emerald-600/20"
                >
                  <Download size={16} />
                  Download All (ZIP)
                </button>
              </div>
            </div>

            <div className="glass p-10 rounded-3xl depth-2">
              <div className="flex justify-between items-center mb-8 border-b border-border pb-6">
                <h2 className="text-2xl font-bold font-mono text-indigo-400">{activeDoc}</h2>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(activeContent);
                    setIsCopying(true);
                    setTimeout(() => setIsCopying(false), 2000);
                  }}
                  className="flex items-center gap-2 bg-muted hover:bg-muted/80 px-4 py-2 rounded-xl transition-all border border-border"
                >
                  {isCopying ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                  <span className="text-sm font-medium">{isCopying ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
              <div className="prose prose-invert prose-indigo max-w-none markdown-body">
                <Markdown>{activeContent}</Markdown>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
}

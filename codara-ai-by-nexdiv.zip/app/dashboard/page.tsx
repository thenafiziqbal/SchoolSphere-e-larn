'use client';

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  Code2, 
  GitBranch, 
  Trash2,
  Check, 
  Copy, 
  Loader2, 
  LayoutDashboard, 
  Zap, 
  ShieldAlert, 
  BarChart3, 
  Activity, 
  ShieldCheck, 
  AlertTriangle,
  Cpu,
  Database,
  Globe,
  Lock,
  Bug,
  TestTube,
  BrainCircuit,
  FileWarning,
  Gauge,
  Award,
  Download,
  X
} from 'lucide-react';
import Markdown from 'react-markdown';
import MermaidViewer from '@/components/MermaidViewer';
import AppLayout from '@/components/AppLayout';
import GoogleAd from '@/components/GoogleAd';
import { useAppContext } from '@/lib/AppContext';
import { useRouter } from 'next/navigation';
import html2canvas from 'html2canvas';
import Certificate from '@/components/Certificate';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db, isFirebaseConfigured } from '@/lib/firebase';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';

export default function DashboardPage() {
  const { user, subscription, analysisResult, analysisStep, analyses, removeAnalysis } = useAppContext();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('overview');
  const [isCopying, setIsCopying] = useState(false);
  const [showCertificate, setShowCertificate] = useState(false);
  const [isGeneratingCert, setIsGeneratingCert] = useState(false);
  const certificateRef = useRef<HTMLDivElement>(null);

  const handleDownloadCertificate = async () => {
    if (!certificateRef.current || !analysisResult || !user || !auth.currentUser) return;
    
    setIsGeneratingCert(true);
    try {
      // Save to Firestore first to ensure it's verifiable
      const certId = analysisResult.id || Math.random().toString(36).substring(7);
      if (isFirebaseConfigured && db) {
        await setDoc(doc(db, 'certificates', certId), {
          userId: auth.currentUser.uid,
          projectName: analysisResult.repoName || 'Project Analysis',
          healthScore: analysisResult.overallHealth || 92,
          date: new Date().toLocaleDateString(),
          analysisId: analysisResult.id || certId
        }, { merge: true });
      }

      // Generate image
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: null
      });
      
      const image = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = image;
      link.download = `${analysisResult.repoName || 'project'}-health-certificate.png`;
      link.click();
    } catch (error) {
      console.error('Failed to generate certificate:', error);
    } finally {
      setIsGeneratingCert(false);
    }
  };

  if (!analysisResult) {
    return (
      <AppLayout title="Dashboard">
        <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-6">
          <div className="w-20 h-20 rounded-3xl bg-muted flex items-center justify-center text-muted-foreground/50">
            <Activity size={40} />
          </div>
          <div className="text-center space-y-2">
            <p className="text-xl font-bold text-foreground">No active analysis</p>
            <p className="text-sm max-w-xs mx-auto">Start by analyzing a repository to see your developer intelligence dashboard.</p>
          </div>
          <button 
            onClick={() => router.push('/dashboard/analyze')}
            className="bg-indigo-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20"
          >
            Analyze Repository
          </button>
        </div>
        {/* Recent Analyses Section */}
        <div className="mt-12 glass p-8 rounded-3xl depth-1">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <Activity size={20} className="text-indigo-400" />
            Recent Analyses
          </h3>
          <div className="space-y-4">
            <AnimatePresence initial={false}>
              {analyses.map((analysis: any) => (
                <motion.div 
                  key={analysis.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20, height: 0, marginBottom: 0, padding: 0 }}
                  className="flex items-center justify-between p-4 bg-muted rounded-2xl border border-border hover:bg-muted/80 transition-all overflow-hidden"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                      <GitBranch size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-foreground">{analysis.repoName}</p>
                      <p className="text-xs text-muted-foreground">{analysis.tech} • {analysis.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Health</p>
                      <p className="font-bold text-emerald-400">{analysis.health}%</p>
                    </div>
                    <button 
                      onClick={() => removeAnalysis(analysis.id)}
                      className="p-2 rounded-lg hover:bg-rose-500/10 text-rose-400 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </AppLayout>
    );
  }

  const getStepLabel = (step: string) => {
    switch (step) {
      case 'fetching': return 'Fetching data...';
      case 'analyzing': return 'Analyzing code...';
      case 'generating_images': return 'Generating 3D visuals...';
      case 'finalizing': return 'Finalizing...';
      default: return '';
    }
  };

  const complexityData = analysisResult.complexityData || [
    { name: 'Core', value: 85 },
    { name: 'Utils', value: 45 },
    { name: 'UI', value: 65 },
    { name: 'API', value: 30 },
    { name: 'Tests', value: 20 },
  ];

  const healthData = analysisResult.healthData || [
    { name: 'Security', value: 92 },
    { name: 'Docs', value: 88 },
    { name: 'Quality', value: 75 },
    { name: 'Testing', value: 60 },
  ];

  const codeHealthData = analysisResult.codeHealth || {
    metrics: {
      cyclomaticComplexity: 12.4,
      testCoverage: 78,
      maintainabilityIndex: 85,
      codeSmells: 24,
      potentialBugs: 7
    },
    coverageByModule: [
      { name: 'Core', coverage: 92 },
      { name: 'UI Components', coverage: 85 },
      { name: 'API Routes', coverage: 65 },
      { name: 'Utils', coverage: 98 },
      { name: 'Config', coverage: 40 },
    ],
    complexFiles: [
      { file: 'src/lib/analyzer.ts', complexity: 45, lines: 850 },
      { file: 'src/components/Dashboard.tsx', complexity: 32, lines: 520 },
      { file: 'src/api/process/route.ts', complexity: 28, lines: 340 },
    ],
    bugs: [
      { title: 'Potential Memory Leak', desc: 'Event listener added in useEffect without cleanup function.', file: 'src/components/LiveChart.tsx', severity: 'High' },
      { title: 'Unhandled Promise Rejection', desc: 'Async function call missing try/catch block or .catch() handler.', file: 'src/api/sync/route.ts', severity: 'Medium' },
      { title: 'Type Coercion Issue', desc: 'Using == instead of === may lead to unexpected type coercion.', file: 'src/utils/formatters.ts', severity: 'Low' },
    ]
  };

  const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#f43f5e', '#f97316'];

  return (
    <AppLayout title={
      activeTab === 'overview' ? 'Project Intelligence' :
      activeTab === 'health' ? 'Code Health' :
      activeTab === 'readme' ? 'Documentation' :
      activeTab === 'functions' ? 'Technical Reference' :
      activeTab === 'security' ? 'Security Audit' :
      'Architecture'
    }>
      <AnimatePresence>
        {analysisStep !== 'idle' && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-8 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <Loader2 size={16} className="text-indigo-400 animate-spin" />
              </div>
              <div>
                <p className="text-sm font-bold text-indigo-400">Analysis in progress</p>
                <p className="text-xs text-indigo-400/70">{getStepLabel(analysisStep)}</p>
              </div>
            </div>
            <div className="flex gap-1.5">
              {['fetching', 'analyzing', 'generating_images', 'finalizing'].map((step) => (
                <div 
                  key={step} 
                  className={`w-10 h-1.5 rounded-full transition-all duration-500 ${
                    analysisStep === step ? 'bg-indigo-500 animate-pulse' : 
                    ['fetching', 'analyzing', 'generating_images', 'finalizing'].indexOf(analysisStep) > ['fetching', 'analyzing', 'generating_images', 'finalizing'].indexOf(step) ? 'bg-emerald-500' : 'bg-muted/80'
                  }`} 
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
          <TabButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} icon={<LayoutDashboard size={16} />} label="Overview" />
          <TabButton active={activeTab === 'health'} onClick={() => setActiveTab('health')} icon={<Activity size={16} />} label="Code Health" />
          <TabButton active={activeTab === 'readme'} onClick={() => setActiveTab('readme')} icon={<FileText size={16} />} label="README" />
          <TabButton active={activeTab === 'functions'} onClick={() => setActiveTab('functions')} icon={<Code2 size={16} />} label="Functions" />
          <TabButton active={activeTab === 'architecture'} onClick={() => setActiveTab('architecture')} icon={<GitBranch size={16} />} label="Architecture" />
          <TabButton active={activeTab === 'security'} onClick={() => setActiveTab('security')} icon={<ShieldAlert size={16} />} label="Security" />
        </div>
        
        {subscription?.plan !== 'free' && (
          <button 
            onClick={() => setShowCertificate(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20 whitespace-nowrap shrink-0"
          >
            <Award size={16} />
            Get Certificate
          </button>
        )}
      </div>

      {/* Certificate Modal */}
      <AnimatePresence>
        {showCertificate && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border rounded-3xl shadow-2xl overflow-hidden max-w-[90vw] max-h-[90vh] flex flex-col"
            >
              <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
                <div className="flex items-center gap-2 text-indigo-400">
                  <Award size={20} />
                  <h3 className="font-bold text-foreground">Project Health Certificate</h3>
                </div>
                <button 
                  onClick={() => setShowCertificate(false)}
                  className="p-2 hover:bg-muted rounded-xl transition-colors text-muted-foreground"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-6 overflow-auto custom-scrollbar flex justify-center bg-muted/10">
                <div className="scale-[0.6] sm:scale-[0.8] md:scale-100 origin-top">
                  <Certificate 
                    ref={certificateRef}
                    id={analysisResult.id || 'CERT-123456'}
                    projectName={analysisResult.repoName || 'Project Analysis'}
                    healthScore={analysisResult.overallHealth || 92}
                    date={new Date().toLocaleDateString()}
                    userName={user?.name || 'Developer'}
                    verificationUrl={`${typeof window !== 'undefined' ? window.location.origin : ''}/verify/${analysisResult.id || 'CERT-123456'}`}
                  />
                </div>
              </div>

              <div className="p-4 border-t border-border bg-muted/30 flex justify-end gap-3">
                <button 
                  onClick={() => setShowCertificate(false)}
                  className="px-6 py-2 rounded-xl font-bold text-muted-foreground hover:bg-muted transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleDownloadCertificate}
                  disabled={isGeneratingCert}
                  className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20 disabled:opacity-50"
                >
                  {isGeneratingCert ? <Loader2 size={18} className="animate-spin" /> : <Download size={18} />}
                  Download PNG
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {activeTab === 'overview' ? (
          <motion.div 
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StatCard icon={<Cpu size={20} />} label="Complexity" value={analysisResult.complexityData ? Math.round(analysisResult.complexityData.reduce((acc: number, curr: any) => acc + curr.value, 0) / analysisResult.complexityData.length) + "%" : "Medium"} sub="Avg Complexity" color="text-indigo-400" />
              <StatCard icon={<Database size={20} />} label="Functions" value={analysisResult.functions?.length || 0} sub="Documented" color="text-purple-400" />
              <StatCard icon={<ShieldCheck size={20} />} label="Security" value={analysisResult.overallHealth ? `${analysisResult.overallHealth}%` : "92%"} sub="Health Score" color="text-emerald-400" />
              <StatCard icon={<Lock size={20} />} label="Vulnerabilities" value={analysisResult.securityIssues?.filter((i: any) => i.severity === 'Critical')?.length || 0} sub="Critical Issues" color="text-rose-400" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Complexity Chart */}
              <div className="glass p-8 rounded-3xl depth-1">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    <BarChart3 size={20} className="text-indigo-400" />
                    Module Complexity
                  </h3>
                  <span className="text-xs text-muted-foreground">Lines of Code vs Logic</span>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={complexityData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#888888', fontSize: 12 }} />
                      <YAxis hide />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0a0a0a', border: '1px solid #ffffff10', borderRadius: '12px' }}
                        itemStyle={{ color: '#6366f1' }}
                      />
                      <Bar dataKey="value" fill="#6366f1" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Health Radar/Pie */}
              <div className="glass p-8 rounded-3xl depth-1">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    <Activity size={20} className="text-purple-400" />
                    Project Health
                  </h3>
                  <span className="text-xs text-muted-foreground">Overall Quality Score</span>
                </div>
                <div className="h-64 w-full flex items-center justify-center relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={healthData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {healthData.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0a0a0a', border: '1px solid #ffffff10', borderRadius: '12px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-3xl font-bold">{analysisResult.overallHealth || 82}%</span>
                    <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Total</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Tech Stack */}
            <div className="glass p-8 rounded-3xl depth-1">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                <Globe size={20} className="text-emerald-400" />
                Detected Tech Stack
              </h3>
              <div className="flex flex-wrap gap-3">
                {(analysisResult.techStack || ['Next.js', 'React', 'TypeScript', 'Tailwind CSS', 'Lucide Icons', 'Framer Motion', 'Gemini AI']).map((tech: string) => (
                  <div key={tech} className="px-4 py-2 bg-muted border border-border rounded-xl text-sm font-medium hover:bg-muted/80 transition-all cursor-default">
                    {tech}
                  </div>
                ))}
              </div>
            </div>
            <GoogleAd />
          </motion.div>
        ) : activeTab === 'health' ? (
          <motion.div 
            key="health"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-5xl mx-auto space-y-8"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                <Activity size={24} />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Code Health Analytics</h2>
                <p className="text-sm text-muted-foreground">Metrics on complexity, test coverage, and code quality</p>
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StatCard icon={<BrainCircuit size={20} />} label="Avg Complexity" value={codeHealthData.metrics.cyclomaticComplexity} sub="Cyclomatic" color="text-indigo-400" />
              <StatCard icon={<TestTube size={20} />} label="Test Coverage" value={`${codeHealthData.metrics.testCoverage}%`} sub="Overall" color="text-emerald-400" />
              <StatCard icon={<Gauge size={20} />} label="Maintainability" value={codeHealthData.metrics.maintainabilityIndex} sub="Index (0-100)" color="text-blue-400" />
              <StatCard icon={<Bug size={20} />} label="Potential Bugs" value={codeHealthData.metrics.potentialBugs} sub="Static Analysis" color="text-rose-400" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Test Coverage Chart */}
              <div className="glass p-8 rounded-3xl depth-1">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    <TestTube size={20} className="text-emerald-400" />
                    Coverage by Module
                  </h3>
                  <span className="text-xs text-muted-foreground">% of Lines Covered</span>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={codeHealthData.coverageByModule} layout="vertical" margin={{ top: 0, right: 0, left: 30, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" horizontal={false} />
                      <XAxis type="number" domain={[0, 100]} hide />
                      <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: '#888888', fontSize: 12 }} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0a0a0a', border: '1px solid #ffffff10', borderRadius: '12px' }}
                        itemStyle={{ color: '#10b981' }}
                        cursor={{ fill: '#ffffff05' }}
                      />
                      <Bar dataKey="coverage" fill="#10b981" radius={[0, 6, 6, 0]} barSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Complex Files List */}
              <div className="glass p-8 rounded-3xl depth-1">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    <BrainCircuit size={20} className="text-indigo-400" />
                    Most Complex Files
                  </h3>
                  <span className="text-xs text-muted-foreground">Needs Refactoring</span>
                </div>
                <div className="space-y-4">
                  {codeHealthData.complexFiles.map((file: any, idx: number) => (
                    <div key={idx} className="flex items-center justify-between p-4 bg-muted border border-border rounded-2xl">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <FileWarning size={16} className="text-amber-400 flex-shrink-0" />
                        <span className="text-sm font-mono truncate">{file.file}</span>
                      </div>
                      <div className="flex items-center gap-4 flex-shrink-0">
                        <div className="text-right">
                          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Complexity</p>
                          <p className="text-sm font-bold text-amber-400">{file.complexity}</p>
                        </div>
                        <div className="text-right hidden sm:block">
                          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Lines</p>
                          <p className="text-sm font-bold">{file.lines}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Potential Bugs List */}
            <div className="glass p-8 rounded-3xl depth-1 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <Bug size={20} className="text-rose-400" />
                  Potential Bugs & Code Smells
                </h3>
                <span className="px-3 py-1 bg-rose-500/10 text-rose-400 text-xs font-bold rounded-lg border border-rose-500/20">
                  {codeHealthData.metrics.potentialBugs} Issues Found
                </span>
              </div>
              <div className="space-y-4">
                {codeHealthData.bugs.length > 0 ? (
                  codeHealthData.bugs.map((bug: any, idx: number) => (
                    <SecurityIssue 
                      key={idx}
                      title={bug.title} 
                      severity={bug.severity} 
                      desc={bug.desc} 
                      file={bug.file}
                    />
                  ))
                ) : (
                  <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-3">
                    <Check size={20} className="text-emerald-400" />
                    <p className="text-sm font-medium text-emerald-400">No potential bugs or code smells detected.</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ) : activeTab === 'readme' ? (
          <motion.div 
            key="readme"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-4xl mx-auto glass p-10 rounded-3xl depth-2"
          >
            <div className="flex justify-between items-center mb-10 border-b border-border pb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <FileText size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">README.md</h2>
                  <p className="text-sm text-muted-foreground">Comprehensive project overview</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(analysisResult.readme);
                  setIsCopying(true);
                  setTimeout(() => setIsCopying(false), 2000);
                }}
                className="flex items-center gap-2 bg-muted hover:bg-muted/80 px-5 py-2.5 rounded-xl transition-all border border-border"
              >
                {isCopying ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                <span className="text-sm font-medium">{isCopying ? 'Copied!' : 'Copy Markdown'}</span>
              </button>
            </div>
            <div className="prose prose-invert prose-indigo max-w-none markdown-body">
              <Markdown>{analysisResult.readme}</Markdown>
            </div>
          </motion.div>
        ) : activeTab === 'functions' ? (
          <motion.div 
            key="functions"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-5xl mx-auto space-y-8"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                <Code2 size={24} />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Technical Reference</h2>
                <p className="text-sm text-muted-foreground">Deep dive into functions and classes</p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6">
              {analysisResult.functions?.map((fn: any, i: number) => (
                <div key={i} className="glass p-8 rounded-3xl depth-1 hover:depth-2 transition-all space-y-6">
                  <div className="flex justify-between items-start">
                    <h3 className="text-xl font-bold text-indigo-400 font-mono">{fn.name}</h3>
                    <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 text-xs font-bold rounded-lg border border-indigo-500/20">FUNCTION</span>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{fn.description}</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-border">
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Parameters</h4>
                      <div className="flex flex-wrap gap-2">
                        {fn.params?.map((p: string, j: number) => (
                          <code key={j} className="bg-muted px-2.5 py-1 rounded-lg text-xs border border-border">{p}</code>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Returns</h4>
                      <code className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-lg text-xs border border-emerald-500/20 inline-block">{fn.returns}</code>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Example Usage</h4>
                    <pre className="bg-card p-5 rounded-2xl border border-border overflow-x-auto text-sm font-mono leading-relaxed">
                      <code>{fn.exampleUsage}</code>
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        ) : activeTab === 'security' ? (
          <motion.div 
            key="security"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-5xl mx-auto space-y-8"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 flex items-center justify-center text-rose-400">
                <ShieldAlert size={24} />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Security Audit</h2>
                <p className="text-sm text-muted-foreground">Vulnerability scanning and risk assessment</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <SecurityMetric label="Critical Issues" value={analysisResult.securityIssues?.filter((i: any) => i.severity === 'Critical')?.length || 0} color="text-rose-400" icon={<AlertTriangle size={18} />} />
              <SecurityMetric label="Medium Risk" value={analysisResult.securityIssues?.filter((i: any) => i.severity === 'Medium')?.length || 0} color="text-amber-400" icon={<ShieldAlert size={18} />} />
              <SecurityMetric label="Low Risk" value={analysisResult.securityIssues?.filter((i: any) => i.severity === 'Low')?.length || 0} color="text-blue-400" icon={<Activity size={18} />} />
            </div>

            <div className="glass p-8 rounded-3xl depth-1 space-y-6">
              <h3 className="text-lg font-bold">Vulnerability Log</h3>
              <div className="space-y-4">
                {analysisResult.securityIssues && analysisResult.securityIssues.length > 0 ? (
                  analysisResult.securityIssues.map((issue: any, idx: number) => (
                    <SecurityIssue 
                      key={idx}
                      title={issue.title} 
                      severity={issue.severity} 
                      desc={issue.desc} 
                      file={issue.file}
                    />
                  ))
                ) : (
                  <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-3">
                    <ShieldCheck size={20} className="text-emerald-400" />
                    <p className="text-sm font-medium text-emerald-400">No security vulnerabilities detected in the analyzed code.</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="architecture"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-5xl mx-auto space-y-10"
          >
            <div className="glass p-10 rounded-3xl depth-2 space-y-8">
              <div className="flex items-center gap-4 border-b border-border pb-6">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-400">
                  <GitBranch size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">System Architecture</h2>
                  <p className="text-sm text-muted-foreground">Visualizing component relationships</p>
                </div>
              </div>
              <div className="bg-muted p-8 rounded-2xl border border-border flex justify-center overflow-x-auto">
                <MermaidViewer chart={analysisResult.architecture} />
              </div>
            </div>

            <div className="glass p-10 rounded-3xl depth-2 space-y-8">
              <div className="flex items-center gap-4 border-b border-border pb-6">
                <div className="w-12 h-12 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-400">
                  <Zap size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">Primary User Flow</h2>
                  <p className="text-sm text-muted-foreground">Sequence of operations</p>
                </div>
              </div>
              <div className="bg-muted p-8 rounded-2xl border border-border flex justify-center overflow-x-auto">
                <MermaidViewer chart={analysisResult.flow} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-12 glass p-8 rounded-3xl depth-1">
        <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
          <Activity size={20} className="text-indigo-400" />
          Recent Analyses
        </h3>
        <div className="space-y-4">
          <AnimatePresence initial={false}>
            {analyses.map((analysis: any) => (
              <motion.div 
                key={analysis.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20, height: 0, marginBottom: 0, padding: 0 }}
                className="flex items-center justify-between p-4 bg-muted rounded-2xl border border-border hover:bg-muted/80 transition-all overflow-hidden"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <GitBranch size={18} />
                  </div>
                  <div>
                    <p className="font-bold text-foreground">{analysis.repoName}</p>
                    <p className="text-xs text-muted-foreground">{analysis.tech} • {analysis.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Health</p>
                    <p className="font-bold text-emerald-400">{analysis.health}%</p>
                  </div>
                  <button 
                    onClick={() => removeAnalysis(analysis.id)}
                    className="p-2 rounded-lg hover:bg-rose-500/10 text-rose-400 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </AppLayout>
  );
}

function TabButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-3 py-2 md:px-5 md:py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap border ${
        active 
          ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/20' 
          : 'text-muted-foreground hover:bg-muted hover:text-foreground border-transparent'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function StatCard({ icon, label, value, sub, color }: { icon: React.ReactNode, label: string, value: string | number, sub: string, color: string }) {
  return (
    <div className="glass p-3 md:p-6 rounded-3xl depth-1 border border-border space-y-2 md:space-y-4">
      <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl bg-muted flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] md:text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className="text-xl md:text-2xl font-bold mt-0.5 md:mt-1">{value}</p>
        <p className="text-[9px] md:text-[10px] text-muted-foreground mt-0.5 md:mt-1">{sub}</p>
      </div>
    </div>
  );
}

function SecurityMetric({ label, value, color, icon }: { label: string, value: string | number, color: string, icon: React.ReactNode }) {
  return (
    <div className="bg-muted border border-border rounded-2xl p-3 md:p-6 flex items-center justify-between">
      <div className="space-y-0.5 md:space-y-1">
        <p className="text-[10px] md:text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className={`text-2xl md:text-3xl font-bold ${color}`}>{value}</p>
      </div>
      <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl bg-muted flex items-center justify-center ${color}`}>
        {icon}
      </div>
    </div>
  );
}

function SecurityIssue({ title, severity, desc, file }: { title: string, severity: 'Critical' | 'Medium' | 'Low', desc: string, file: string }) {
  const color = severity === 'Critical' ? 'text-rose-400 bg-rose-400/10 border-rose-400/20' : 
                severity === 'Medium' ? 'text-amber-400 bg-amber-400/10 border-amber-400/20' : 
                'text-blue-400 bg-blue-400/10 border-blue-400/20';
  
  return (
    <div className="p-3 md:p-4 rounded-2xl bg-muted border border-border space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="font-bold text-foreground">{title}</h4>
        <span className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border ${color}`}>
          {severity}
        </span>
      </div>
      <p className="text-sm text-muted-foreground">{desc}</p>
      <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground bg-muted px-3 py-1.5 rounded-lg w-fit">
        <FileText size={12} />
        {file}
      </div>
    </div>
  );
}

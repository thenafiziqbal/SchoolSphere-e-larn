'use client';

import PublicLayout from '@/components/PublicLayout';

export default function DocsPage() {
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto px-6 py-20">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-8 text-gradient">Documentation</h1>
        <div className="prose prose-invert max-w-none">
          <p className="text-lg text-muted-foreground mb-8">
            Welcome to the Codara AI documentation. Here you&apos;ll find everything you need to know about integrating and using our platform.
          </p>
          
          <div className="space-y-12">
            <section>
              <h2 className="text-2xl font-bold mb-4">Getting Started</h2>
              <p className="text-muted-foreground mb-4">
                To get started, create an account and connect your GitHub repository. Our AI will automatically begin analyzing your codebase.
              </p>
              <div className="bg-muted/50 p-6 rounded-2xl border border-border">
                <h3 className="font-bold mb-2">Quick Steps:</h3>
                <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                  <li>Sign up for a free account</li>
                  <li>Navigate to the Dashboard</li>
                  <li>Click &quot;Analyze Repo&quot; and enter your repository URL</li>
                  <li>Wait for the analysis to complete</li>
                </ol>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass p-6 rounded-2xl border border-border">
                  <h3 className="font-bold mb-2">Automated Documentation</h3>
                  <p className="text-sm text-muted-foreground">Generate comprehensive READMEs and API references automatically from your source code.</p>
                </div>
                <div className="glass p-6 rounded-2xl border border-border">
                  <h3 className="font-bold mb-2">Architecture Mapping</h3>
                  <p className="text-sm text-muted-foreground">Visualize your system structure with automatically generated architecture diagrams.</p>
                </div>
                <div className="glass p-6 rounded-2xl border border-border">
                  <h3 className="font-bold mb-2">Security Analysis</h3>
                  <p className="text-sm text-muted-foreground">Identify vulnerabilities and logical bugs before they reach production.</p>
                </div>
                <div className="glass p-6 rounded-2xl border border-border">
                  <h3 className="font-bold mb-2">Code Health</h3>
                  <p className="text-sm text-muted-foreground">Get instant insights into your project&apos;s quality and documentation completeness.</p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}

'use client';

import { motion } from 'framer-motion';
import { History, Search, Filter, ExternalLink, Calendar, Code2, ShieldCheck, ChevronRight, Trash2 } from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import { useAppContext } from '@/lib/AppContext';
import Link from 'next/link';

export default function HistoryPage() {
  const { analyses, removeAnalysis } = useAppContext();

  return (
    <AppLayout title="Analysis History">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header Actions */}
        <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-white/5 p-6 rounded-3xl border border-white/10">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input 
              type="text" 
              placeholder="Search repositories..." 
              className="w-full bg-black/20 border border-white/10 rounded-xl pl-12 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-sm"
            />
          </div>
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2.5 rounded-xl text-sm font-medium transition-all">
              <Filter size={16} />
              Filter
            </button>
            <Link href="/dashboard/analyze" className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20">
              New Analysis
            </Link>
          </div>
        </div>

        {/* History List */}
        <div className="grid grid-cols-1 gap-4">
          {analyses.map((analysis, idx) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={analysis.id}
              className="glass p-6 rounded-3xl depth-1 hover:depth-2 transition-all border border-white/5 hover:border-indigo-500/30 group cursor-pointer"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-5">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                    <Code2 size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold group-hover:text-indigo-400 transition-colors">{analysis.repoName}</h3>
                    <div className="flex items-center gap-4 mt-1">
                      <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Calendar size={12} />
                        {analysis.date}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Code2 size={12} />
                        {analysis.tech}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-8">
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1">Health Score</p>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${analysis.health > 90 ? 'bg-emerald-500' : analysis.health > 80 ? 'bg-indigo-500' : 'bg-amber-500'}`} 
                          style={{ width: `${analysis.health}%` }} 
                        />
                      </div>
                      <span className={`text-sm font-bold ${analysis.health > 90 ? 'text-emerald-400' : analysis.health > 80 ? 'text-indigo-400' : 'text-amber-400'}`}>
                        {analysis.health}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-muted-foreground hover:text-white transition-all">
                      <ExternalLink size={18} />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        removeAnalysis(analysis.id);
                      }}
                      className="p-2.5 rounded-xl bg-white/5 hover:bg-red-500/20 border border-white/10 text-muted-foreground hover:text-red-400 transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                    <button className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-muted-foreground hover:text-white transition-all">
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {analyses.length === 0 && (
          <div className="py-20 text-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto text-muted-foreground/30">
              <History size={40} />
            </div>
            <p className="text-muted-foreground">No analysis history found.</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

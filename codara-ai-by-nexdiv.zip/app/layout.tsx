import type {Metadata} from 'next';
import { Inter } from 'next/font/google';
import './globals.css'; // Global styles
import { AppProvider } from '@/lib/AppContext';
import RouteGuard from '@/components/RouteGuard';
import GoogleAdScript from '@/components/GoogleAdScript';
import FaviconHandler from '@/components/FaviconHandler';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

export const metadata: Metadata = {
  title: 'Chronicler AI',
  description: 'AI-powered developer tool that automatically generates documentation for code repositories.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`dark ${inter.variable}`} suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var descriptor = Object.getOwnPropertyDescriptor(window, 'fetch');
                  if (descriptor && !descriptor.set && descriptor.configurable) {
                    var originalFetch = window.fetch;
                    Object.defineProperty(window, 'fetch', {
                      configurable: true,
                      enumerable: true,
                      get: function() { return originalFetch; },
                      set: function() { console.warn('Prevented overwrite of window.fetch'); }
                    });
                  }
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>
      <body className="font-sans antialiased bg-background text-foreground" suppressHydrationWarning>
        <AppProvider>
          <FaviconHandler />
          {/* <GoogleAdScript /> */}
          <RouteGuard>
            {children}
          </RouteGuard>
        </AppProvider>
      </body>
    </html>
  );
}

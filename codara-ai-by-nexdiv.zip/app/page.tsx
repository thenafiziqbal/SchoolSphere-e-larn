'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sparkles, Zap, Shield, BarChart3, Github, ArrowRight, Code2, GitBranch, Terminal, CheckCircle2, Sun, Moon, Star, ShieldAlert, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useAppContext } from '@/lib/AppContext';
import * as LucideIcons from 'lucide-react';

export default function LandingPage() {
  const { siteConfig, theme, setTheme } = useAppContext();
  const [currency, setCurrency] = useState<'BDT' | 'USD'>('BDT');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const renderIcon = (iconName: string, className?: string) => {
    const Icon = (LucideIcons as any)[iconName] || Sparkles;
    return <Icon className={className} size={24} />;
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-indigo-500/30 overflow-x-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            {siteConfig.logoUrl || '/logo.svg' ? (
              <Image 
                src={siteConfig.logoUrl || '/logo.svg'} 
                alt={siteConfig.name} 
                width={40} 
                height={40} 
                className="w-10 h-10 object-contain" 
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Sparkles size={20} className="text-white" />
              </div>
            )}
            <div className="flex flex-col">
              <span className="font-bold text-lg md:text-xl tracking-tight text-foreground">{siteConfig.name}</span>
              <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest -mt-1">by NexDiv</span>
            </div>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            {siteConfig.headerLinks.map((link, i) => (
              <NavLink key={i} href={link.href}>{link.label}</NavLink>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2.5 rounded-xl bg-muted/50 hover:bg-muted transition-colors text-foreground border border-border"
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <div className="hidden md:flex items-center gap-4">
              <Link href="/auth/login" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors px-4 py-2">Sign In</Link>
              <Link href="/auth/register" className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-primary/90 transition-all shadow-md shadow-primary/20">
                Get Started
              </Link>
            </div>
            
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2.5 rounded-xl bg-muted/50 hover:bg-muted transition-colors text-foreground border border-border"
            >
              {isMenuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl overflow-hidden"
            >
              <div className="flex flex-col p-6 gap-4">
                {siteConfig.headerLinks.map((link, i) => (
                  <Link 
                    key={i} 
                    href={link.href}
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium text-foreground hover:text-indigo-500 transition-colors"
                  >
                    {link.label}
                  </Link>
                ))}
                <hr className="border-border" />
                <div className="flex flex-col gap-4 pt-2">
                  <Link 
                    href="/auth/login" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Sign In
                  </Link>
                  <Link 
                    href="/auth/register" 
                    onClick={() => setIsMenuOpen(false)}
                    className="bg-primary text-primary-foreground px-6 py-3 rounded-xl text-center font-bold hover:bg-primary/90 transition-all"
                  >
                    Get Started
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-40 pb-20 px-6 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-indigo-500/10 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-purple-500/10 blur-[120px] rounded-full" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center space-y-8 max-w-4xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-muted border border-border text-indigo-500 text-xs font-bold uppercase tracking-widest"
            >
              <Zap size={14} />
              Next-Gen Developer Intelligence
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-6xl md:text-8xl font-bold tracking-tight leading-[0.9] text-foreground"
            >
              <span>{siteConfig.heroTitlePrefix} </span>
              <span className="text-gradient">{siteConfig.heroTitleGradient}</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
            >
              {siteConfig.description}
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
            >
              <Link href={siteConfig.heroCtaPrimaryHref} className="w-full sm:w-auto bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-500 transition-all flex items-center justify-center gap-3 shadow-xl shadow-indigo-600/20">
                {siteConfig.heroCtaPrimaryText}
                <ArrowRight size={20} />
              </Link>
              <Link href={siteConfig.heroCtaSecondaryHref} className="w-full sm:w-auto bg-muted border border-border text-foreground px-8 py-4 rounded-2xl font-bold text-lg hover:bg-muted/80 transition-all flex items-center justify-center gap-3">
                <Github size={20} />
                {siteConfig.heroCtaSecondaryText}
              </Link>
            </motion.div>
          </div>

          {/* 3D Hero Image */}
          {siteConfig.hero3dImageUrl && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="mt-16 flex justify-center perspective-1000"
            >
              <motion.div
                whileHover={{ rotateY: 15, rotateX: -10, scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="relative w-full max-w-2xl aspect-video rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10 group"
              >
                <Image 
                  src={siteConfig.hero3dImageUrl} 
                  alt="Hero 3D" 
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-8">
                  <div className="text-white">
                    <h3 className="text-2xl font-bold mb-2">Next-Gen Intelligence</h3>
                    <p className="text-white/80 text-sm">Experience the future of repository automation with 3D visualization.</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}

          {/* Dashboard Preview */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="mt-20 relative group"
          >
            <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-[2.5rem] blur opacity-20 group-hover:opacity-30 transition duration-1000 group-hover:duration-200" />
            <div className="relative bg-card rounded-[2.5rem] border border-border overflow-hidden shadow-2xl">
              <div className="h-12 border-b border-border bg-muted/50 flex items-center px-6 gap-2">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/50" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                  <div className="w-3 h-3 rounded-full bg-green-500/50" />
                </div>
                <div className="flex-1 flex justify-center">
                  <div className="bg-background/80 rounded-lg px-4 py-1 text-[10px] text-muted-foreground font-mono">{siteConfig.previewUrl}</div>
                </div>
              </div>
              <div className="aspect-video bg-background p-8 overflow-hidden">
                <div className="grid grid-cols-12 gap-6 h-full">
                  <div className="col-span-3 space-y-4">
                    <div className="h-8 w-full bg-muted rounded-lg flex items-center px-3 text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                      {siteConfig.previewSidebarText}
                    </div>
                    <div className="h-32 w-full bg-muted/50 rounded-xl border border-border p-4 space-y-2">
                      <div className="h-2 w-3/4 bg-indigo-500/20 rounded" />
                      <div className="h-2 w-1/2 bg-indigo-500/20 rounded" />
                      <div className="h-2 w-2/3 bg-indigo-500/20 rounded" />
                    </div>
                    <div className="h-32 w-full bg-muted/50 rounded-xl border border-border p-4 space-y-2">
                      <div className="h-2 w-2/3 bg-purple-500/20 rounded" />
                      <div className="h-2 w-3/4 bg-purple-500/20 rounded" />
                      <div className="h-2 w-1/2 bg-purple-500/20 rounded" />
                    </div>
                  </div>
                  <div className="col-span-9 space-y-6">
                    <div className="h-12 w-full flex items-center px-4 bg-muted/30 rounded-xl border border-border">
                      <span className="text-sm font-bold text-foreground">{siteConfig.previewMainTitle}</span>
                    </div>
                    <div className="relative h-full w-full bg-muted rounded-2xl border border-border overflow-hidden">
                      <Image 
                        src={siteConfig.previewMainImage}
                        alt="Preview"
                        fill
                        className="object-cover opacity-80"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Gallery Section */}
          {siteConfig.galleryImages && siteConfig.galleryImages.some(img => img.isVisible) && (
            <div className="mt-40 space-y-12">
              <div className="text-center space-y-4">
                <h2 className="text-4xl font-bold tracking-tight">Project Gallery</h2>
                <p className="text-muted-foreground max-w-2xl mx-auto italic serif">Explore some of the amazing projects analyzed and documented with our AI.</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {siteConfig.galleryImages.filter(img => img.isVisible).map((image, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="group relative aspect-[4/3] rounded-3xl overflow-hidden border border-border shadow-lg hover:shadow-2xl transition-all duration-500"
                  >
                    <Image 
                      src={image.url} 
                      alt={`Gallery ${index}`} 
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-6">
                      <div className="text-white">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">Featured Project</span>
                        <h4 className="text-lg font-bold">Analysis View {index + 1}</h4>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Features Grid */}
      {siteConfig.features && siteConfig.features.length > 0 && (
        <section id="features" className="py-32 px-6 bg-muted/30">
          <div className="max-w-7xl mx-auto">
            <div className="text-center space-y-4 mb-20">
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-foreground">{siteConfig.featuresTitle || 'Engineered for Modern Teams'}</h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">{siteConfig.featuresSubtitle || 'Everything you need to understand, document, and scale your software projects.'}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {siteConfig.features?.map(feature => (
                <FeatureCard 
                  key={feature.id}
                  icon={renderIcon(feature.iconName)}
                  title={feature.title}
                  desc={feature.description}
                  isPremium={feature.isPremium}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Pricing Section */}
      {siteConfig.pricingPlans && siteConfig.pricingPlans.length > 0 && (
        <section id="pricing" className="py-32 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center space-y-4 mb-12">
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-foreground">{siteConfig.pricingTitle || 'Simple, Transparent Pricing'}</h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">{siteConfig.pricingSubtitle || 'Choose the plan that fits your development workflow.'}</p>
            </div>

            {/* Currency Toggle */}
            <div className="flex justify-center mb-16">
              <div className="bg-muted p-1 rounded-2xl flex items-center border border-border">
                <button 
                  onClick={() => setCurrency('BDT')}
                  className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${currency === 'BDT' ? 'bg-indigo-600 text-white shadow-lg' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  ৳ Taka
                </button>
                <button 
                  onClick={() => setCurrency('USD')}
                  className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${currency === 'USD' ? 'bg-indigo-600 text-white shadow-lg' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  $ Dollar
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {siteConfig.pricingPlans?.map(plan => {
                const planFeatures = plan.features.map(fId => {
                  const feature = siteConfig.features?.find(f => f.id === fId);
                  if (feature) {
                    return { title: feature.title, isPremium: feature.isPremium };
                  }
                  return { title: fId, isPremium: false };
                });

                return (
                  <PricingCard 
                    key={plan.id}
                    planId={plan.id}
                    plan={plan.name}
                    price={plan.price}
                    desc={plan.description}
                    features={planFeatures}
                    featured={plan.isPopular}
                    currency={currency}
                    exchangeRate={siteConfig.usdExchangeRate}
                  />
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-border bg-background">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            {siteConfig.logoUrl || '/logo.svg' ? (
              <Image 
                src={siteConfig.logoUrl || '/logo.svg'} 
                alt={siteConfig.name} 
                width={40} 
                height={40} 
                className="w-10 h-10 object-contain" 
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <Sparkles size={20} className="text-primary-foreground" />
              </div>
            )}
            <span className="font-bold text-xl tracking-tight text-foreground">{siteConfig.name}</span>
          </div>
          <div className="flex gap-8 text-sm text-muted-foreground">
            {siteConfig.footerLinks?.map((link, i) => (
              <Link key={i} href={link.href} className="hover:text-foreground transition-colors">{link.label}</Link>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">{siteConfig.footerText}</p>
        </div>
      </footer>
    </div>
  );
}

function NavLink({ href, children }: { href: string, children: React.ReactNode }) {
  return (
    <Link href={href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
      {children}
    </Link>
  );
}

function FeatureCard({ icon, title, desc, isPremium }: { icon: React.ReactNode, title: string, desc: string, isPremium?: boolean }) {
  return (
    <div className="bg-card p-8 rounded-3xl shadow-sm hover:shadow-md transition-all border border-border hover:border-indigo-500/30 group relative overflow-hidden">
      {isPremium && (
        <div className="absolute top-4 right-4 bg-amber-500/10 text-amber-500 px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1">
          <Star size={12} className="fill-amber-500" /> Premium
        </div>
      )}
      <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center text-indigo-500 mb-6 group-hover:bg-indigo-600 group-hover:text-white transition-all">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3 text-foreground">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}

function PricingCard({ 
  planId, 
  plan, 
  price, 
  desc, 
  features, 
  featured,
  currency,
  exchangeRate
}: { 
  planId: string, 
  plan: string, 
  price: number, 
  desc: string, 
  features: { title: string, isPremium: boolean }[], 
  featured?: boolean,
  currency: 'BDT' | 'USD',
  exchangeRate: number
}) {
  const usdPrice = (price / exchangeRate).toFixed(2);
  const bdtPrice = price.toLocaleString();

  return (
    <div className={`bg-card p-10 rounded-[2.5rem] shadow-sm flex flex-col border ${featured ? 'border-indigo-500 ring-1 ring-indigo-500 shadow-indigo-500/10' : 'border-border'}`}>
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xl font-bold text-foreground">{plan}</h3>
          {featured && <span className="bg-indigo-500/10 text-indigo-500 text-xs font-bold px-3 py-1 rounded-full">Most Popular</span>}
        </div>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </div>
      <div className="mb-8 space-y-1">
        <div className="flex items-baseline gap-1">
          {currency === 'BDT' ? (
            <>
              <span className="text-5xl font-bold text-foreground">৳{bdtPrice}</span>
              <span className="text-muted-foreground">/mo</span>
            </>
          ) : (
            <>
              <span className="text-5xl font-bold text-foreground">${usdPrice}</span>
              <span className="text-muted-foreground">/mo</span>
            </>
          )}
        </div>
        <div className="text-xs text-muted-foreground font-medium italic">
          {currency === 'BDT' ? `≈ $${usdPrice} USD` : `≈ ৳${bdtPrice} BDT`}
        </div>
      </div>
      <div className="flex-1 space-y-4 mb-10">
        {features.map((f, i) => (
          <div key={i} className="flex items-center gap-3 text-sm text-muted-foreground">
            {f.isPremium ? (
              <Star size={16} className="text-amber-500 fill-amber-500" />
            ) : (
              <CheckCircle2 size={16} className="text-indigo-500" />
            )}
            <span className={f.isPremium ? "font-medium text-foreground" : ""}>{f.title}</span>
          </div>
        ))}
      </div>
      <Link 
        href={`/billing?plan=${planId}`} 
        className={`w-full py-4 rounded-2xl font-bold text-center transition-all ${featured ? 'bg-indigo-600 text-white hover:bg-indigo-500' : 'bg-muted text-foreground hover:bg-muted/80'}`}
      >
        Get Started
      </Link>
    </div>
  );
}

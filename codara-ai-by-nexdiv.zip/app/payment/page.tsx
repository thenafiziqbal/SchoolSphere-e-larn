'use client';

import { useState, useEffect, Suspense } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSearchParams, useRouter } from 'next/navigation';
import { 
  Smartphone, 
  Hash, 
  CheckCircle2, 
  Loader2, 
  ArrowLeft,
  CreditCard,
  Zap,
  Info,
  ShieldCheck,
  Clock
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import { useAppContext } from '@/lib/AppContext';

function PaymentContent() {
  const { siteConfig, submitSubscriptionRequest, userRequests } = useAppContext();
  const searchParams = useSearchParams();
  const router = useRouter();
  
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'nagad' | 'rocket' | 'binance' | null>(null);
  const [transactionId, setTransactionId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const planId = searchParams.get('plan');
    if (planId && siteConfig?.pricingPlans) {
      const plan = siteConfig.pricingPlans.find(p => p.id === planId);
      if (plan) {
        setSelectedPlan(plan);
      }
    }
  }, [searchParams, siteConfig]);

  const handleSubmit = async () => {
    if (!transactionId || !paymentMethod || !selectedPlan) return;
    setIsSubmitting(true);
    try {
      await submitSubscriptionRequest({
        planId: selectedPlan.id,
        method: paymentMethod,
        transactionId,
        amount: parseInt(selectedPlan.price)
      });
      setSuccess(true);
      setTimeout(() => {
        router.push('/billing');
      }, 3000);
    } catch (error) {
      alert("Failed to submit request. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!selectedPlan) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <Loader2 className="animate-spin text-indigo-500" size={40} />
        <p className="text-muted-foreground">Loading plan details...</p>
      </div>
    );
  }

  const usdPrice = (parseInt(selectedPlan.price) / (siteConfig.usdExchangeRate || 115)).toFixed(2);

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={() => router.back()}
          className="p-2 hover:bg-white/5 rounded-xl transition-colors border border-white/10"
        >
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Complete Your Upgrade</h1>
          <p className="text-sm text-muted-foreground">Secure payment for {selectedPlan.name} Plan</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Payment Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass p-6 md:p-8 rounded-3xl border border-white/10 space-y-8">
            {success ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12 space-y-6"
              >
                <div className="w-24 h-24 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 size={48} />
                </div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold">Payment Submitted!</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    We&apos;ve received your transaction details. Our team will verify it shortly. You&apos;ll be redirected back to billing in a few seconds.
                  </p>
                </div>
                <div className="flex items-center justify-center gap-2 text-sm text-emerald-400 font-medium">
                  <Clock size={16} className="animate-pulse" />
                  Verifying Transaction...
                </div>
              </motion.div>
            ) : (
              <>
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CreditCard size={18} className="text-indigo-400" />
                    <h3 className="font-bold uppercase tracking-widest text-xs text-muted-foreground">Select Payment Method</h3>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { id: 'bkash', label: 'bKash', color: 'pink' },
                      { id: 'nagad', label: 'Nagad', color: 'orange' },
                      { id: 'rocket', label: 'Rocket', color: 'purple' },
                      { id: 'binance', label: 'Binance', color: 'yellow' }
                    ].map((method) => (
                      <button 
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 group ${
                          paymentMethod === method.id 
                            ? `bg-${method.color}-500/10 border-${method.color}-500 text-${method.color}-500 shadow-lg shadow-${method.color}-500/10` 
                            : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {method.id === 'binance' ? <Zap size={24} /> : <Smartphone size={24} />}
                        <span className="text-[10px] font-bold uppercase tracking-widest">{method.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  {paymentMethod && (
                    <motion.div 
                      key={paymentMethod}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-6"
                    >
                      {paymentMethod === 'binance' ? (
                        <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-6">
                          <div className="flex items-center gap-2 text-yellow-500">
                            <Zap size={18} />
                            <span className="text-sm font-bold uppercase tracking-widest">Binance Pay Instructions</span>
                          </div>
                          
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest ml-1">Pay ID / Link</p>
                              <div className="flex items-center justify-between bg-black/40 p-4 rounded-xl border border-white/5 group">
                                <span className="text-sm font-mono truncate mr-4">{siteConfig.binancePayLink || 'Not Configured'}</span>
                                <button 
                                  onClick={() => navigator.clipboard.writeText(siteConfig.binancePayLink || '')}
                                  className="p-2 hover:bg-yellow-500/20 rounded-lg transition-colors text-yellow-500 flex-shrink-0"
                                >
                                  <Hash size={16} />
                                </button>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest ml-1">Steps to Follow</p>
                              <div className="space-y-3">
                                {siteConfig.binanceInstructions?.map((step, idx) => (
                                  <div key={idx} className="flex gap-4 text-sm bg-white/5 p-3 rounded-xl border border-white/5">
                                    <div className="w-6 h-6 rounded-full bg-yellow-500/20 text-yellow-500 flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                                      {idx + 1}
                                    </div>
                                    <p className="text-muted-foreground leading-relaxed">{step}</p>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="flex items-center justify-between p-4 bg-yellow-500/10 rounded-xl border border-yellow-500/20">
                              <span className="text-sm font-medium text-yellow-500/80">Total Amount:</span>
                              <span className="text-xl font-bold text-yellow-500">${usdPrice} USD</span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-6">
                          <div className="flex items-center gap-2 text-indigo-400">
                            <Smartphone size={18} />
                            <span className="text-sm font-bold uppercase tracking-widest">{paymentMethod.toUpperCase()} Transfer</span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest ml-1">Send Money To</p>
                              <div className="flex items-center justify-between bg-black/40 p-4 rounded-xl border border-white/5">
                                <span className="text-lg font-bold tracking-wider">
                                  {siteConfig?.paymentNumbers?.[paymentMethod as keyof typeof siteConfig.paymentNumbers] || 'N/A'}
                                </span>
                                <button 
                                  onClick={() => navigator.clipboard.writeText(siteConfig?.paymentNumbers?.[paymentMethod as keyof typeof siteConfig.paymentNumbers] || '')}
                                  className="p-2 hover:bg-white/10 rounded-lg transition-colors text-indigo-400"
                                >
                                  <Hash size={16} />
                                </button>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest ml-1">Exact Amount</p>
                              <div className="bg-black/40 p-4 rounded-xl border border-white/5 flex items-center justify-between">
                                <span className="text-lg font-bold text-emerald-400">৳{parseInt(selectedPlan.price).toLocaleString()}</span>
                                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">BDT</span>
                              </div>
                            </div>
                          </div>

                          <div className="p-4 bg-indigo-500/10 rounded-xl border border-indigo-500/20 flex items-start gap-3">
                            <Info size={18} className="text-indigo-400 mt-0.5" />
                            <p className="text-xs text-indigo-300/80 leading-relaxed">
                              Please use your account email as a reference if your payment app supports it. This helps us verify your payment faster.
                            </p>
                          </div>
                        </div>
                      )}

                      <div className="space-y-3">
                        <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest ml-1">Transaction ID (TxID)</label>
                        <div className="relative">
                          <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
                          <input 
                            type="text"
                            placeholder="Enter the TxID from your payment confirmation..."
                            value={transactionId}
                            onChange={(e) => setTransactionId(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 py-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-lg"
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground italic ml-1">You can find this in the SMS or transaction history of your payment app.</p>
                      </div>

                      <button 
                        onClick={handleSubmit}
                        disabled={!transactionId || isSubmitting}
                        className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl font-bold shadow-xl shadow-indigo-600/20 transition-all flex items-center justify-center gap-3 text-lg"
                      >
                        {isSubmitting ? <Loader2 className="animate-spin" size={24} /> : <ShieldCheck size={24} />}
                        {isSubmitting ? 'Verifying...' : 'Confirm Payment'}
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            )}
          </div>
        </div>

        {/* Right Column: Order Summary */}
        <div className="space-y-6">
          <div className="glass p-6 rounded-3xl border border-white/10 space-y-6 sticky top-24">
            <h3 className="font-bold uppercase tracking-widest text-xs text-muted-foreground">Order Summary</h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-lg">{selectedPlan.name} Plan</p>
                  <p className="text-xs text-muted-foreground">Monthly Subscription</p>
                </div>
                <div className="text-right">
                  <p className="font-bold">৳{parseInt(selectedPlan.price).toLocaleString()}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-widest">≈ ${usdPrice} USD</p>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>৳{parseInt(selectedPlan.price).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Processing Fee</span>
                  <span className="text-emerald-400">FREE</span>
                </div>
                <div className="flex justify-between pt-4 border-t border-white/5">
                  <span className="font-bold">Total</span>
                  <div className="text-right">
                    <p className="font-bold text-xl text-indigo-400">৳{parseInt(selectedPlan.price).toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Payable Amount</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-3">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Plan Benefits</p>
              <ul className="space-y-2">
                {selectedPlan.features.slice(0, 4).map((f: string, i: number) => (
                  <li key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                    <CheckCircle2 size={12} className="text-indigo-500" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PaymentPage() {
  return (
    <AppLayout title="Secure Payment">
      <Suspense fallback={
        <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
          <Loader2 className="animate-spin text-indigo-500" size={40} />
          <p className="text-muted-foreground">Initializing payment gateway...</p>
        </div>
      }>
        <PaymentContent />
      </Suspense>
    </AppLayout>
  );
}

'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Mail, 
  Building2, 
  Globe, 
  Calendar, 
  Shield, 
  Zap, 
  BarChart3, 
  History,
  Edit3,
  Github,
  Twitter,
  Linkedin,
  ExternalLink,
  Facebook,
  Instagram,
  Video,
  Save,
  X
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import { useAppContext } from '@/lib/AppContext';
import Link from 'next/link';
import Image from 'next/image';

export default function ProfilePage() {
  const { user, setUser, subscription } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    company: user?.company || '',
    website: user?.website || '',
    about: user?.about || 'Software Engineer and Technical Architect focused on building scalable cloud solutions. Passionate about code quality, automated testing, and developer experience. Currently exploring AI-driven development workflows with Codara AI.',
    avatar: user?.avatar || ''
  });
  const [socialLinks, setSocialLinks] = useState({
    facebook: user?.socialLinks?.facebook || '',
    instagram: user?.socialLinks?.instagram || '',
    tiktok: user?.socialLinks?.tiktok || '',
    linkedin: user?.socialLinks?.linkedin || '',
  });

  const handleSave = () => {
    setUser({
      ...(user as any),
      name: profileData.name,
      company: profileData.company,
      website: profileData.website,
      about: profileData.about,
      avatar: profileData.avatar,
      socialLinks
    });
    setIsEditing(false);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileData({ ...profileData, avatar: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const stats = [
    { label: 'Total Analyses', value: '24', icon: <Zap size={18} />, color: 'text-amber-400' },
    { label: 'Avg. Complexity', value: 'Medium', icon: <BarChart3 size={18} />, color: 'text-indigo-400' },
    { label: 'Security Score', value: '98/100', icon: <Shield size={18} />, color: 'text-emerald-400' },
    { label: 'Member Since', value: 'Jan 2026', icon: <Calendar size={18} />, color: 'text-purple-400' },
  ];

  const recentActivity = [
    { type: 'Analysis', project: 'codara-core', time: '2 hours ago', status: 'Completed' },
    { type: 'Security', project: 'nexdiv-api', time: '1 day ago', status: 'Fixed' },
    { type: 'Documentation', project: 'frontend-v2', time: '3 days ago', status: 'Updated' },
  ];

  return (
    <AppLayout title="User Profile">
      <div className="max-w-5xl mx-auto space-y-10 pb-20">
        {/* Profile Header */}
        <div className="relative">
          <div className="h-48 w-full rounded-[2.5rem] bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-indigo-600/20 border border-white/5 overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/abstract/1200/400')] opacity-10 bg-cover bg-center" />
          </div>
          
          <div className="px-4 md:px-10 -mt-12 md:-mt-16 flex flex-col md:flex-row items-center md:items-end gap-4 md:gap-6 text-center md:text-left">
            <div className="relative group">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-3xl bg-indigo-600 border-4 border-[#050505] flex items-center justify-center text-3xl md:text-4xl font-bold text-white shadow-2xl overflow-hidden">
                {(profileData.avatar || user?.avatar) && (profileData.avatar !== "" || user?.avatar !== "") ? (
                  <Image 
                    src={profileData.avatar || user?.avatar || ''} 
                    alt="Avatar" 
                    width={128} 
                    height={128} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  user?.name?.[0] || 'U'
                )}
              </div>
              {isEditing && (
                <label className="absolute bottom-2 right-2 p-2 rounded-xl bg-white text-black shadow-lg cursor-pointer hover:scale-110 transition-all">
                  <Edit3 size={16} />
                  <input type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
                </label>
              )}
            </div>
            
            <div className="flex-1 pb-2 space-y-1 w-full">
              <div className="flex flex-col md:flex-row items-center md:items-center gap-2 md:gap-3">
                {isEditing ? (
                  <input 
                    type="text" 
                    value={profileData.name} 
                    onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                    className="text-2xl md:text-3xl font-bold bg-white/5 border border-white/10 rounded-xl px-3 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 w-full md:w-auto text-center md:text-left"
                  />
                ) : (
                  <h2 className="text-2xl md:text-3xl font-bold">{user?.name || 'User'}</h2>
                )}
                <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                  {subscription.plan} Plan
                </span>
              </div>
              <p className="text-muted-foreground flex items-center justify-center md:justify-start gap-2 text-sm">
                <Mail size={14} />
                {user?.email || 'No email provided'}
              </p>
            </div>

            <div className="pb-2 w-full md:w-auto">
              <button 
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center justify-center gap-2 w-full md:w-auto px-6 py-2.5 md:py-3 rounded-2xl bg-white/5 border border-white/10 text-sm font-bold hover:bg-white/10 transition-all"
              >
                {isEditing ? <X size={16} /> : <Edit3 size={16} />}
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
          {stats.map((stat, i) => (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={stat.label} 
              className="glass p-3 md:p-6 rounded-2xl md:rounded-3xl depth-1 border border-white/5 space-y-2 md:space-y-3"
            >
              <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl bg-white/5 flex items-center justify-center ${stat.color}`}>
                {stat.icon}
              </div>
              <div>
                <p className="text-[10px] md:text-xs font-bold text-muted-foreground uppercase tracking-widest">{stat.label}</p>
                <p className="text-lg md:text-2xl font-bold mt-0.5 md:mt-1">{stat.value}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* About & Info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="glass p-8 rounded-[2.5rem] depth-1 border border-white/5 space-y-6">
              <h3 className="text-xl font-bold">About</h3>
              {isEditing ? (
                <textarea 
                  value={profileData.about}
                  onChange={(e) => setProfileData({...profileData, about: e.target.value})}
                  className="w-full h-32 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none custom-scrollbar"
                  placeholder="Tell us about yourself..."
                />
              ) : (
                <p className="text-muted-foreground leading-relaxed">
                  {user?.about || 'Software Engineer and Technical Architect focused on building scalable cloud solutions. Passionate about code quality, automated testing, and developer experience. Currently exploring AI-driven development workflows with Codara AI.'}
                </p>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                {isEditing ? (
                  <>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2"><Building2 size={14} /> Company</label>
                      <input 
                        type="text" 
                        value={profileData.company} 
                        onChange={(e) => setProfileData({...profileData, company: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                        placeholder="Company Name"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2"><Globe size={14} /> Website</label>
                      <input 
                        type="text" 
                        value={profileData.website} 
                        onChange={(e) => setProfileData({...profileData, website: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                        placeholder="https://..."
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <InfoItem icon={<Building2 size={18} />} label="Company" value={user?.company || 'NexDiv Tech'} />
                    <InfoItem icon={<Globe size={18} />} label="Website" value={user?.website || 'nexdiv.com'} />
                  </>
                )}
              </div>
            </div>

            <div className="glass p-8 rounded-[2.5rem] depth-1 border border-white/5 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">Recent Activity</h3>
                <Link href="/history" className="text-xs font-bold text-indigo-400 hover:underline flex items-center gap-1">
                  View All <ExternalLink size={12} />
                </Link>
              </div>
              
              <div className="space-y-4">
                {recentActivity.map((activity, i) => (
                  <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                        {activity.type === 'Analysis' ? <Zap size={18} /> : activity.type === 'Security' ? <Shield size={18} /> : <History size={18} />}
                      </div>
                      <div>
                        <p className="font-bold text-sm group-hover:text-indigo-400 transition-colors">{activity.project}</p>
                        <p className="text-xs text-muted-foreground">{activity.type} • {activity.time}</p>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                      {activity.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar Info */}
          <div className="space-y-8">
            <div className="glass p-8 rounded-[2.5rem] depth-1 border border-white/5 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">Social Profiles</h3>
                {isEditing && (
                  <button onClick={handleSave} className="text-xs font-bold text-emerald-400 flex items-center gap-1 hover:underline">
                    <Save size={14} /> Save
                  </button>
                )}
              </div>
              
              {isEditing ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground">Facebook URL</label>
                    <input 
                      type="text" 
                      value={socialLinks.facebook} 
                      onChange={(e) => setSocialLinks({...socialLinks, facebook: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      placeholder="https://facebook.com/..."
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground">Instagram URL</label>
                    <input 
                      type="text" 
                      value={socialLinks.instagram} 
                      onChange={(e) => setSocialLinks({...socialLinks, instagram: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      placeholder="https://instagram.com/..."
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground">TikTok URL</label>
                    <input 
                      type="text" 
                      value={socialLinks.tiktok} 
                      onChange={(e) => setSocialLinks({...socialLinks, tiktok: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      placeholder="https://tiktok.com/@..."
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground">LinkedIn URL</label>
                    <input 
                      type="text" 
                      value={socialLinks.linkedin} 
                      onChange={(e) => setSocialLinks({...socialLinks, linkedin: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      placeholder="https://linkedin.com/in/..."
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {user?.socialLinks?.facebook && <SocialLink icon={<Facebook size={18} />} label="Facebook" url={user.socialLinks.facebook} />}
                  {user?.socialLinks?.instagram && <SocialLink icon={<Instagram size={18} />} label="Instagram" url={user.socialLinks.instagram} />}
                  {user?.socialLinks?.tiktok && <SocialLink icon={<Video size={18} />} label="TikTok" url={user.socialLinks.tiktok} />}
                  {user?.socialLinks?.linkedin && <SocialLink icon={<Linkedin size={18} />} label="LinkedIn" url={user.socialLinks.linkedin} />}
                  
                  {(!user?.socialLinks || Object.values(user.socialLinks).every(v => !v)) && (
                    <p className="text-sm text-muted-foreground italic">No social links added yet.</p>
                  )}
                </div>
              )}
            </div>

            <div className="glass p-8 rounded-[2.5rem] depth-1 border border-white/5 space-y-6">
              <h3 className="text-xl font-bold">Current Usage</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-muted-foreground">Analysis Quota</span>
                    <span>18 / 50</span>
                  </div>
                  <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 w-[36%]" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-muted-foreground">Storage</span>
                    <span>1.2 GB / 5 GB</span>
                  </div>
                  <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 w-[24%]" />
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground text-center pt-2">
                  Resets in 12 days. <Link href="/billing" className="text-indigo-400 hover:underline">Upgrade for more.</Link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) {
  return (
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-muted-foreground">
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className="text-sm font-bold text-white">{value}</p>
      </div>
    </div>
  );
}

function SocialLink({ icon, label, url }: { icon: React.ReactNode, label: string, url: string }) {
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
      <div className="flex items-center gap-3">
        <div className="text-muted-foreground group-hover:text-indigo-400 transition-colors">
          {icon}
        </div>
        <div>
          <p className="text-xs font-bold">{label}</p>
          <p className="text-[10px] text-muted-foreground truncate max-w-[150px]">{url}</p>
        </div>
      </div>
      <ExternalLink size={14} className="text-muted-foreground opacity-0 group-hover:opacity-100 transition-all" />
    </a>
  );
}

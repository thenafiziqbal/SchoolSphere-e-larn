'use client';

import { useAppContext } from '@/lib/AppContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import AppLayout from '@/components/AppLayout';
import { Loader2 } from 'lucide-react';

export default function SecurityRedirect() {
  const { analysisResult } = useAppContext();
  const router = useRouter();

  useEffect(() => {
    if (analysisResult) {
      // In a real app, this would be a dedicated security page
      // For now, we'll redirect to the dashboard and we could pass a tab param
      router.push('/dashboard');
    }
  }, [analysisResult, router]);

  if (!analysisResult) {
    return (
      <AppLayout title="Security Scan">
        <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-4">
          <p>No security data available. Please analyze a repository first.</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <div className="h-screen w-full flex items-center justify-center">
      <Loader2 className="animate-spin text-indigo-500" size={40} />
    </div>
  );
}

'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Key, 
  Bell, 
  Shield, 
  Globe, 
  Moon, 
  Sun, 
  Save, 
  Plus, 
  Trash2, 
  Check, 
  AlertCircle,
  Mail,
  Building2,
  Link as LinkIcon,
  Github,
  Twitter,
  Linkedin,
  ExternalLink
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import { useAppContext } from '@/lib/AppContext';
import Link from 'next/link';

export default function SettingsPage() {
  const { user, setUser, theme, setTheme, apiKeys, setApiKeys, isAdmin, siteConfig, updateSiteConfig } = useAppContext();
  const [activeSection, setActiveSection] = useState('profile');
  const [isSaving, setIsSaving] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [newKeyProvider, setNewKeyProvider] = useState('Google Gemini');
  const [adClient, setAdClient] = useState(siteConfig.googleAdClient || '');
  const [adSlot, setAdSlot] = useState(siteConfig.googleAdSlot || '');

  const handleSave = async () => {
    setIsSaving(true);
    if (activeSection === 'ads' && isAdmin) {
      await updateSiteConfig({ googleAdClient: adClient, googleAdSlot: adSlot });
    }
    setTimeout(() => setIsSaving(false), 1500);
  };

  const addKey = () => {
    if (newKey.trim()) {
      setApiKeys([...apiKeys, {
        id: Math.random().toString(36).substring(7),
        provider: newKeyProvider,
        key: newKey.trim(),
        status: 'Active'
      }]);
      setNewKey('');
    }
  };

  const removeKey = (index: number) => {
    setApiKeys(apiKeys.filter((_, i) => i !== index));
  };

  return (
    <AppLayout title="Account Settings">
      <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-10">
        {/* Sidebar Navigation */}
        <div className="w-full lg:w-64 space-y-2">
          <NavButton active={activeSection === 'profile'} onClick={() => setActiveSection('profile')} icon={<User size={18} />} label="Profile" />
          <NavButton active={activeSection === 'api'} onClick={() => setActiveSection('api')} icon={<Key size={18} />} label="API Keys" />
          <NavButton active={activeSection === 'notifications'} onClick={() => setActiveSection('notifications')} icon={<Bell size={18} />} label="Notifications" />
          <NavButton active={activeSection === 'security'} onClick={() => setActiveSection('security')} icon={<Shield size={18} />} label="Security" />
          <NavButton active={activeSection === 'appearance'} onClick={() => setActiveSection('appearance')} icon={theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />} label="Appearance" />
          {isAdmin && (
            <NavButton active={activeSection === 'ads'} onClick={() => setActiveSection('ads')} icon={<Globe size={18} />} label="Google Ads" />
          )}
        </div>

        {/* Content Area */}
        <div className="flex-grow glass p-10 rounded-3xl depth-1 border border-white/5 min-h-[600px]">
          <AnimatePresence mode="wait">
            {activeSection === 'profile' ? (
              <motion.div 
                key="profile"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex items-center gap-6 pb-8 border-b border-white/5">
                  <div className="w-24 h-24 rounded-3xl bg-indigo-600 flex items-center justify-center text-3xl font-bold text-white shadow-xl shadow-indigo-600/20">
                    {user?.name?.[0]}
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-2xl font-bold">Public Profile</h3>
                      <Link 
                        href="/profile" 
                        className="text-xs font-bold text-indigo-400 hover:underline flex items-center gap-1"
                      >
                        View Public Profile <ExternalLink size={12} />
                      </Link>
                    </div>
                    <p className="text-sm text-muted-foreground">Manage your personal information and how others see you.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <InputGroup label="Full Name" value={user?.name || ''} icon={<User size={16} />} />
                  <InputGroup label="Email Address" value={user?.email || ''} icon={<Mail size={16} />} />
                  <InputGroup label="Company" value={user?.company || ''} icon={<Building2 size={16} />} />
                  <InputGroup label="Website" value={user?.website || ''} icon={<LinkIcon size={16} />} />
                </div>

                <div className="space-y-4 pt-4">
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Social Accounts</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <SocialButton icon={<Twitter size={18} />} label="Twitter" />
                    <SocialButton icon={<Linkedin size={18} />} label="LinkedIn" />
                  </div>
                </div>

                <div className="pt-8 flex justify-end">
                  <button 
                    onClick={handleSave}
                    className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-2xl font-bold transition-all shadow-lg shadow-indigo-600/20"
                  >
                    {isSaving ? <Loader size={18} className="animate-spin" /> : <Save size={18} />}
                    {isSaving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </motion.div>
            ) : activeSection === 'api' ? (
              <motion.div 
                key="api"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="space-y-2 pb-8 border-b border-white/5">
                  <h3 className="text-2xl font-bold">API Management</h3>
                  <p className="text-sm text-muted-foreground">Manage your Gemini API keys for repository analysis. We rotate these automatically.</p>
                </div>

                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <select
                      value={newKeyProvider}
                      onChange={(e) => setNewKeyProvider(e.target.value)}
                      className="bg-black/20 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all sm:w-48"
                    >
                      <option value="Google Gemini">Google Gemini</option>
                      <option value="Groq">Groq</option>
                      <option value="OpenRouter">OpenRouter</option>
                      <option value="OpenAI">OpenAI</option>
                    </select>
                    <input 
                      type="password" 
                      placeholder="Enter new API key..." 
                      value={newKey}
                      onChange={(e) => setNewKey(e.target.value)}
                      className="flex-grow bg-black/20 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                    />
                    <button 
                      onClick={addKey}
                      className="bg-white/5 hover:bg-white/10 border border-white/10 px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2 whitespace-nowrap"
                    >
                      <Plus size={18} />
                      Add Key
                    </button>
                  </div>
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 flex gap-3 text-amber-400">
                    <AlertCircle size={20} className="flex-shrink-0" />
                    <p className="text-xs leading-relaxed">Your keys are encrypted and stored securely. We never share your keys with third parties.</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Active Keys</h4>
                  <div className="space-y-3">
                    {apiKeys.map((keyObj, i) => (
                      <div key={i} className="flex items-center justify-between bg-white/5 border border-white/10 p-4 rounded-2xl group">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                            <Check size={14} />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">{keyObj.provider}</p>
                            <code className="text-[10px] font-mono text-muted-foreground">••••••••••••{keyObj.key.slice(-4)}</code>
                          </div>
                        </div>
                        <button 
                          onClick={() => removeKey(i)}
                          className="p-2 rounded-lg hover:bg-rose-500/10 text-muted-foreground hover:text-rose-400 transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    ))}
                    {apiKeys.length === 0 && (
                      <p className="text-sm text-center py-8 text-muted-foreground italic">No API keys added yet.</p>
                    )}
                  </div>
                </div>
              </motion.div>
            ) : activeSection === 'appearance' ? (
              <motion.div 
                key="appearance"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="space-y-2 pb-8 border-b border-white/5">
                  <h3 className="text-2xl font-bold">Appearance</h3>
                  <p className="text-sm text-muted-foreground">Customize how Codara AI looks on your device.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ThemeOption 
                    active={theme === 'dark'} 
                    onClick={() => setTheme('dark')} 
                    icon={<Moon size={24} />} 
                    label="Dark Mode" 
                    desc="Easy on the eyes in low light."
                  />
                  <ThemeOption 
                    active={theme === 'light'} 
                    onClick={() => setTheme('light')} 
                    icon={<Sun size={24} />} 
                    label="Light Mode" 
                    desc="Clean and bright for daylight."
                  />
                </div>
              </motion.div>
            ) : activeSection === 'ads' && isAdmin ? (
              <motion.div 
                key="ads"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="space-y-2 pb-8 border-b border-white/5">
                  <h3 className="text-2xl font-bold">Google Ads Configuration</h3>
                  <p className="text-sm text-muted-foreground">Manage your Google AdSense configuration. Only visible to admins.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest ml-1">Ad Client ID</label>
                    <input 
                      type="text" 
                      value={adClient}
                      onChange={(e) => setAdClient(e.target.value)}
                      placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                      className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest ml-1">Ad Slot ID</label>
                    <input 
                      type="text" 
                      value={adSlot}
                      onChange={(e) => setAdSlot(e.target.value)}
                      placeholder="1234567890"
                      className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-sm"
                    />
                  </div>
                </div>

                <div className="pt-8 flex justify-end">
                  <button 
                    onClick={handleSave}
                    className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-2xl font-bold transition-all shadow-lg shadow-indigo-600/20"
                  >
                    {isSaving ? <Loader size={18} className="animate-spin" /> : <Save size={18} />}
                    {isSaving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="other"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-4"
              >
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                  <Shield size={32} />
                </div>
                <p className="text-sm font-bold">This section is coming soon.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </AppLayout>
  );
}

import { Loader } from 'lucide-react';

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-5 py-3 rounded-2xl text-sm font-bold transition-all border ${
        active 
          ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/20' 
          : 'text-muted-foreground hover:bg-white/5 hover:text-foreground border-transparent'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function InputGroup({ label, value, icon }: { label: string, value: string, icon: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest ml-1">{label}</label>
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
          {icon}
        </div>
        <input 
          type="text" 
          defaultValue={value} 
          className="w-full bg-black/20 border border-white/10 rounded-xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-sm"
        />
      </div>
    </div>
  );
}

function SocialButton({ icon, label, connected }: { icon: React.ReactNode, label: string, connected?: boolean }) {
  return (
    <button className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${
      connected ? 'bg-indigo-500/10 border-indigo-500/30 text-white' : 'bg-white/5 border-white/10 text-muted-foreground hover:text-white hover:bg-white/10'
    }`}>
      <div className="flex items-center gap-3">
        {icon}
        <span className="text-sm font-bold">{label}</span>
      </div>
      {connected && <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">Connected</span>}
    </button>
  );
}

function ThemeOption({ active, onClick, icon, label, desc }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string, desc: string }) {
  return (
    <button 
      onClick={onClick}
      className={`p-6 rounded-3xl border text-left transition-all space-y-4 ${
        active ? 'bg-indigo-600 border-indigo-500 text-white shadow-xl shadow-indigo-600/20' : 'bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10'
      }`}
    >
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${active ? 'bg-white/20' : 'bg-white/5'}`}>
        {icon}
      </div>
      <div>
        <h4 className="font-bold">{label}</h4>
        <p className={`text-xs mt-1 ${active ? 'text-indigo-100' : 'text-muted-foreground'}`}>{desc}</p>
      </div>
    </button>
  );
}

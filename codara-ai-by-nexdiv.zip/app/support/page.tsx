'use client';

import PublicLayout from '@/components/PublicLayout';
import { Mail, MessageSquare, BookOpen, HelpCircle } from 'lucide-react';
import Link from 'next/link';

export default function SupportPage() {
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-gradient">How can we help?</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our support team is here to help you get the most out of Codara AI. Choose an option below to get started.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          <div className="glass p-8 rounded-3xl border border-border hover:border-indigo-500/50 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <BookOpen size={24} />
            </div>
            <h3 className="text-xl font-bold mb-3">Documentation</h3>
            <p className="text-muted-foreground mb-6">
              Browse our comprehensive guides and tutorials to learn how to use Codara AI effectively.
            </p>
            <Link href="/docs" className="text-indigo-400 font-bold hover:text-indigo-300 transition-colors flex items-center gap-2">
              Read the Docs <span aria-hidden="true">&rarr;</span>
            </Link>
          </div>

          <div className="glass p-8 rounded-3xl border border-border hover:border-purple-500/50 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Mail size={24} />
            </div>
            <h3 className="text-xl font-bold mb-3">Email Support</h3>
            <p className="text-muted-foreground mb-6">
              Get in touch with our support team directly. We aim to respond to all inquiries within 24 hours.
            </p>
            <a href="mailto:support@codara.ai" className="text-purple-400 font-bold hover:text-purple-300 transition-colors flex items-center gap-2">
              Contact Us <span aria-hidden="true">&rarr;</span>
            </a>
          </div>

          <div className="glass p-8 rounded-3xl border border-border hover:border-emerald-500/50 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <MessageSquare size={24} />
            </div>
            <h3 className="text-xl font-bold mb-3">Community Forum</h3>
            <p className="text-muted-foreground mb-6">
              Join our community of developers to ask questions, share tips, and discuss best practices.
            </p>
            <Link href="#" className="text-emerald-400 font-bold hover:text-emerald-300 transition-colors flex items-center gap-2">
              Join the Discussion <span aria-hidden="true">&rarr;</span>
            </Link>
          </div>

          <div className="glass p-8 rounded-3xl border border-border hover:border-amber-500/50 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <HelpCircle size={24} />
            </div>
            <h3 className="text-xl font-bold mb-3">FAQ</h3>
            <p className="text-muted-foreground mb-6">
              Find quick answers to the most commonly asked questions about our platform.
            </p>
            <Link href="#" className="text-amber-400 font-bold hover:text-amber-300 transition-colors flex items-center gap-2">
              View FAQ <span aria-hidden="true">&rarr;</span>
            </Link>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}

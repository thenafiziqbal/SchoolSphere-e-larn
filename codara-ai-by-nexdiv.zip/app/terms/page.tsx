'use client';

import PublicLayout from '@/components/PublicLayout';

export default function TermsPage() {
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto px-6 py-20">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-8 text-gradient">Terms of Service</h1>
        <div className="prose prose-invert max-w-none text-muted-foreground space-y-6">
          <p className="text-lg">Last updated: {new Date().toLocaleDateString()}</p>
          
          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">1. Agreement to Terms</h2>
          <p>
            By accessing or using Codara AI, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>

          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">2. Use License</h2>
          <p>
            Permission is granted to temporarily download one copy of the materials (information or software) on Codara AI&apos;s website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>modify or copy the materials;</li>
            <li>use the materials for any commercial purpose, or for any public display (commercial or non-commercial);</li>
            <li>attempt to decompile or reverse engineer any software contained on Codara AI&apos;s website;</li>
            <li>remove any copyright or other proprietary notations from the materials; or</li>
            <li>transfer the materials to another person or &quot;mirror&quot; the materials on any other server.</li>
          </ul>

          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">3. Disclaimer</h2>
          <p>
            The materials on Codara AI&apos;s website are provided on an &apos;as is&apos; basis. Codara AI makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
          </p>

          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">4. Limitations</h2>
          <p>
            In no event shall Codara AI or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Codara AI&apos;s website, even if Codara AI or a Codara AI authorized representative has been notified orally or in writing of the possibility of such damage.
          </p>

          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">5. Accuracy of Materials</h2>
          <p>
            The materials appearing on Codara AI&apos;s website could include technical, typographical, or photographic errors. Codara AI does not warrant that any of the materials on its website are accurate, complete or current. Codara AI may make changes to the materials contained on its website at any time without notice.
          </p>

          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">6. Links</h2>
          <p>
            Codara AI has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by Codara AI of the site. Use of any such linked website is at the user&apos;s own risk.
          </p>

          <h2 className="text-2xl font-bold text-foreground mt-12 mb-4">7. Modifications</h2>
          <p>
            Codara AI may revise these terms of service for its website at any time without notice. By using this website you are agreeing to be bound by the then current version of these terms of service.
          </p>
        </div>
      </div>
    </PublicLayout>
  );
}

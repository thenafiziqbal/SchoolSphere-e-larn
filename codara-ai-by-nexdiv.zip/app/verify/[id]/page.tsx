'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { doc, getDoc } from 'firebase/firestore';
import { db, isFirebaseConfigured } from '@/lib/firebase';
import { ShieldCheck, Loader2, XCircle, Calendar, Hash, User, FileCode2, CheckCircle2 } from 'lucide-react';
import PublicLayout from '@/components/PublicLayout';
import { motion } from 'framer-motion';

export default function VerifyCertificatePage() {
  const params = useParams();
  const id = params.id as string;
  
  const [loading, setLoading] = useState(true);
  const [certificate, setCertificate] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCertificate = async () => {
      if (!isFirebaseConfigured || !db) {
        setError('Database not configured.');
        setLoading(false);
        return;
      }

      try {
        const docRef = doc(db, 'certificates', id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          setCertificate({ id: docSnap.id, ...docSnap.data() });
        } else {
          setError('Certificate not found. It may be invalid or has been removed.');
        }
      } catch (err) {
        console.error('Error fetching certificate:', err);
        setError('Failed to verify certificate. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchCertificate();
    }
  }, [id]);

  return (
    <PublicLayout>
      <div className="min-h-[70vh] flex items-center justify-center py-20 px-6">
        <div className="max-w-2xl w-full">
          {loading ? (
            <div className="flex flex-col items-center justify-center space-y-4">
              <Loader2 size={48} className="text-indigo-500 animate-spin" />
              <p className="text-lg text-muted-foreground animate-pulse">Verifying Certificate...</p>
            </div>
          ) : error || !certificate ? (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-500/10 border border-red-500/20 rounded-3xl p-12 text-center space-y-6"
            >
              <div className="w-24 h-24 bg-red-500/20 rounded-full flex items-center justify-center mx-auto text-red-500">
                <XCircle size={48} />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-foreground mb-2">Verification Failed</h2>
                <p className="text-muted-foreground text-lg">{error}</p>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border rounded-3xl overflow-hidden shadow-2xl"
            >
              <div className="bg-emerald-500/10 border-b border-emerald-500/20 p-8 text-center flex flex-col items-center justify-center">
                <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-emerald-500/30">
                  <CheckCircle2 size={40} className="text-white" />
                </div>
                <h2 className="text-3xl font-bold text-emerald-500 mb-2">Certificate Verified</h2>
                <p className="text-muted-foreground">This is a valid and authentic Project Health Certificate.</p>
              </div>

              <div className="p-8 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Hash size={16} />
                      <span className="text-sm font-medium uppercase tracking-wider">Certificate ID</span>
                    </div>
                    <p className="font-mono text-lg font-bold text-foreground">{certificate.id}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar size={16} />
                      <span className="text-sm font-medium uppercase tracking-wider">Issue Date</span>
                    </div>
                    <p className="text-lg font-bold text-foreground">{certificate.date}</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <FileCode2 size={16} />
                      <span className="text-sm font-medium uppercase tracking-wider">Project Name</span>
                    </div>
                    <p className="text-lg font-bold text-foreground">{certificate.projectName}</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <User size={16} />
                      <span className="text-sm font-medium uppercase tracking-wider">Issued To (User ID)</span>
                    </div>
                    <p className="font-mono text-sm font-bold text-foreground truncate">{certificate.userId}</p>
                  </div>
                </div>

                <div className="bg-muted rounded-2xl p-6 flex items-center justify-between border border-border">
                  <div>
                    <h3 className="text-lg font-bold text-foreground mb-1">Health Score</h3>
                    <p className="text-sm text-muted-foreground">Overall project health at the time of analysis.</p>
                  </div>
                  <div className="flex items-end gap-1">
                    <span className="text-5xl font-black text-indigo-500">{certificate.healthScore}</span>
                    <span className="text-xl font-bold text-muted-foreground mb-1">/100</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}

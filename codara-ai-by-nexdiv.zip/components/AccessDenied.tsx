import { Shield } from 'lucide-react';
import AppLayout from '@/components/AppLayout';

export default function AccessDenied() {
  return (
    <AppLayout title="Access Denied">
      <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-4">
        <Shield size={48} className="text-rose-500" />
        <p className="text-xl font-bold text-foreground">Access Denied</p>
        <p>You do not have permission to view this page.</p>
      </div>
    </AppLayout>
  );
}

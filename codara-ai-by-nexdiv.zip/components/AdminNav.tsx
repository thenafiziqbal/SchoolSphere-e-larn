'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { LayoutDashboard, Users, Key, Package, Settings, CreditCard } from 'lucide-react';

export default function AdminNav() {
  const pathname = usePathname();

  const links = [
    { href: '/admin', label: 'Overview', icon: <LayoutDashboard size={16} /> },
    { href: '/admin/users', label: 'User Management', icon: <Users size={16} /> },
    { href: '/admin/keys', label: 'API Management', icon: <Key size={16} /> },
    { href: '/admin/packages', label: 'Packages', icon: <Package size={16} /> },
    { href: '/admin/subscriptions', label: 'Subscriptions', icon: <CreditCard size={16} /> },
    { href: '/admin/settings', label: 'Site Settings', icon: <Settings size={16} /> },
  ];

  return (
    <div className="fixed top-24 left-1/2 -translate-x-1/2 z-40 flex items-center gap-1 bg-card/80 backdrop-blur-xl p-1.5 rounded-2xl border border-border w-fit shadow-2xl">
      {links.map((link) => {
        const isActive = pathname === link.href;
        return (
          <Link
            key={link.href}
            href={link.href}
            className={`relative flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
              isActive 
                ? 'text-white' 
                : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
            }`}
          >
            {isActive && (
              <motion.div 
                layoutId="admin-nav-active"
                className="absolute inset-0 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
            <span className="relative z-10 flex items-center gap-2">
              {link.icon}
              {link.label}
            </span>
          </Link>
        );
      })}
    </div>
  );
}

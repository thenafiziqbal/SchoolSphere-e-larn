'use client';

import Sidebar from './Sidebar';
import { Search, Bell, User, LogOut, ChevronDown, Settings, CreditCard, Moon, Sun, LayoutDashboard } from 'lucide-react';
import { useAppContext } from '@/lib/AppContext';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { auth, isFirebaseConfigured } from '@/lib/firebase';
import { signOut } from 'firebase/auth';

export default function AppLayout({ children, title }: { children: React.ReactNode, title: string }) {
  const { user, setUser, subscription, notifications, markAsRead, theme, setTheme, isLoadingAuth, siteConfig } = useAppContext();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const router = useRouter();

  const handleSignOut = async () => {
    if (isFirebaseConfigured && auth) {
      await signOut(auth);
    }
    setUser(null);
    router.push('/auth/login');
  };

  useEffect(() => {
    if (!isLoadingAuth && !user && isFirebaseConfigured) {
      router.push('/auth/login');
    }
  }, [user, isLoadingAuth, router]);

  if (isLoadingAuth) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-foreground">Loading...</div>;
  }

  const unreadCount = notifications.filter(n => !n.read).length;

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden relative">
      {/* Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-500/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-30 md:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      <motion.div
        className={`fixed md:relative z-40 h-full ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300`}
      >
        <Sidebar />
      </motion.div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden z-10">
        {/* Header */}
        <header className="h-16 border-b border-border bg-background/20 backdrop-blur-md flex items-center justify-between px-4 md:px-8 shrink-0">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="md:hidden p-2 rounded-xl bg-muted hover:bg-muted/80 transition-colors"
            >
              <LayoutDashboard size={18} />
            </button>
            <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative group hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" size={16} />
              <input 
                type="text" 
                placeholder="Search analysis history..." 
                className="bg-muted border border-border text-sm rounded-xl pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/30 w-64 transition-all"
              />
            </div>

            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center border border-border hover:bg-muted/80 transition-colors cursor-pointer"
            >
              {theme === 'dark' ? <Sun size={18} className="text-muted-foreground" /> : <Moon size={18} className="text-muted-foreground" />}
            </button>

            {/* Notifications */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center border border-border hover:bg-muted/80 transition-colors cursor-pointer relative"
              >
                <Bell size={18} className="text-muted-foreground" />
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border border-background" />
                )}
              </button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-80 glass p-4 rounded-2xl depth-3 z-50 border border-border"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-bold uppercase tracking-widest">Notifications</h3>
                      <span className="text-[10px] text-primary cursor-pointer hover:underline">Mark all as read</span>
                    </div>
                    <div className="space-y-3 max-h-64 overflow-y-auto custom-scrollbar">
                      {notifications.length > 0 ? (
                        notifications.map(n => (
                          <div key={n.id} className={`p-3 rounded-xl border ${n.read ? 'bg-muted border-transparent' : 'bg-primary/5 border-primary/20'}`}>
                            <p className="text-xs font-bold">{n.title}</p>
                            <p className="text-[10px] text-muted-foreground mt-1">{n.message}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-center py-4 text-xs text-muted-foreground">No new notifications</p>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* User Menu */}
            <div className="relative">
              <button 
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-3 bg-muted border border-border rounded-xl px-3 py-1.5 hover:bg-muted/80 transition-all"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold overflow-hidden">
                  {user?.avatar && user.avatar !== "" ? (
                    <Image 
                      src={user.avatar} 
                      alt="Avatar" 
                      width={28} 
                      height={28} 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    user?.name?.charAt(0) || 'U'
                  )}
                </div>
                <div className="hidden lg:block text-left">
                  <p className="text-xs font-bold truncate max-w-[100px]">{user?.name}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-tighter">{subscription.plan} Plan</p>
                </div>
                <ChevronDown size={14} className={`text-muted-foreground transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {showUserMenu && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-48 glass p-2 rounded-2xl depth-3 z-50 border border-border"
                  >
                    <UserMenuItem icon={<User size={14} />} label="Profile" href="/profile" />
                    <UserMenuItem icon={<Settings size={14} />} label="Settings" href="/settings" />
                    <UserMenuItem icon={<CreditCard size={14} />} label="Billing" href="/billing" />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto pt-4 px-4 md:px-8 pb-8 custom-scrollbar">
          {children}
        </div>
      </main>
    </div>
  );
}

function UserMenuItem({ icon, label, href }: { icon: React.ReactNode, label: string, href: string }) {
  return (
    <Link href={href} className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-all">
      {icon}
      {label}
    </Link>
  );
}

import { CreditCard as CreditCardIcon } from 'lucide-react';

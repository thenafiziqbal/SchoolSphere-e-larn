import React, { forwardRef } from 'react';
import QRCode from 'react-qr-code';
import { ShieldCheck, Star, Award, Calendar, Hash } from 'lucide-react';

interface CertificateProps {
  id: string;
  projectName: string;
  healthScore: number;
  date: string;
  userName: string;
  verificationUrl: string;
}

const Certificate = forwardRef<HTMLDivElement, CertificateProps>(({ id, projectName, healthScore, date, userName, verificationUrl }, ref) => {
  return (
    <div 
      ref={ref}
      className="relative w-[800px] h-[600px] bg-white text-slate-900 p-12 overflow-hidden flex flex-col items-center justify-center font-sans"
      style={{
        backgroundImage: 'radial-gradient(circle at center, #ffffff 0%, #f8fafc 100%)',
        boxShadow: 'inset 0 0 0 20px #4f46e5, inset 0 0 0 24px #ffffff, inset 0 0 0 26px #e2e8f0'
      }}
    >
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full border-[40px] border-indigo-500"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full border-[40px] border-indigo-500"></div>
      </div>

      {/* Header */}
      <div className="flex flex-col items-center mb-8 z-10">
        <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/30">
          <ShieldCheck size={40} className="text-white" />
        </div>
        <h1 className="text-4xl font-serif font-bold text-indigo-950 tracking-widest uppercase text-center">
          Project Health Certificate
        </h1>
        <div className="h-1 w-32 bg-indigo-500 mt-4 rounded-full"></div>
      </div>

      {/* Body */}
      <div className="text-center z-10 space-y-6 max-w-2xl">
        <p className="text-lg text-slate-600 italic">This is to certify that the project</p>
        <h2 className="text-3xl font-bold text-slate-800">{projectName}</h2>
        <p className="text-lg text-slate-600 italic">analyzed by <span className="font-semibold not-italic text-slate-800">{userName}</span></p>
        
        <div className="flex items-center justify-center gap-4 my-6">
          <div className="flex flex-col items-center p-4 bg-indigo-50 rounded-2xl border border-indigo-100 min-w-[160px]">
            <span className="text-sm font-semibold text-indigo-600 uppercase tracking-wider mb-1">Health Score</span>
            <div className="flex items-end gap-1">
              <span className="text-5xl font-black text-indigo-700">{healthScore}</span>
              <span className="text-xl font-bold text-indigo-400 mb-1">/100</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer & Verification */}
      <div className="absolute bottom-12 left-12 right-12 flex justify-between items-end z-10">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-slate-600">
            <Calendar size={16} className="text-indigo-500" />
            <span className="text-sm font-medium">Date: {date}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-600">
            <Hash size={16} className="text-indigo-500" />
            <span className="text-sm font-medium">ID: {id}</span>
          </div>
        </div>

        <div className="flex flex-col items-center gap-2">
          <div className="p-2 bg-white rounded-xl shadow-sm border border-slate-200">
            <QRCode value={verificationUrl} size={80} level="H" />
          </div>
          <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">Scan to Verify</span>
        </div>
      </div>

      {/* Watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03] pointer-events-none transform -rotate-12">
        <Award size={400} />
      </div>
    </div>
  );
});

Certificate.displayName = 'Certificate';

export default Certificate;

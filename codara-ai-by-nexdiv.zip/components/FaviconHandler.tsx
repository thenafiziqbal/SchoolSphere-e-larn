'use client';

import { useEffect } from 'react';
import { useAppContext } from '@/lib/AppContext';

export default function FaviconHandler() {
  const { siteConfig } = useAppContext();

  useEffect(() => {
    const faviconToUse = siteConfig.faviconUrl || '/logo.svg';
    if (faviconToUse) {
      const link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
      if (link) {
        link.href = faviconToUse;
      } else {
        const newLink = document.createElement('link');
        newLink.rel = 'icon';
        newLink.href = faviconToUse;
        document.head.appendChild(newLink);
      }
    }
  }, [siteConfig.faviconUrl]);

  return null;
}

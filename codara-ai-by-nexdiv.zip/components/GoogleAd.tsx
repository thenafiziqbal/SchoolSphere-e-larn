'use client';

import { useEffect } from 'react';
import { useAppContext } from '@/lib/AppContext';

export default function GoogleAd() {
  const { siteConfig } = useAppContext();

  useEffect(() => {
    if (siteConfig.googleAdClient && siteConfig.googleAdSlot) {
      try {
        // @ts-ignore
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (err) {
        console.error('Google Ads error:', err);
      }
    }
  }, [siteConfig.googleAdClient, siteConfig.googleAdSlot]);

  if (!siteConfig.googleAdClient || !siteConfig.googleAdSlot) {
    return null;
  }

  return (
    <div className="w-full overflow-hidden rounded-2xl border border-border bg-muted/30 flex items-center justify-center p-4 my-6">
      <ins
        className="adsbygoogle"
        style={{ display: 'block', width: '100%' }}
        data-ad-client={siteConfig.googleAdClient}
        data-ad-slot={siteConfig.googleAdSlot}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}

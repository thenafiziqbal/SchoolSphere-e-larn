'use client';

import { useEffect } from 'react';
import { useAppContext } from '@/lib/AppContext';

export default function GoogleAdScript() {
  const { siteConfig } = useAppContext();

  useEffect(() => {
    console.log('GoogleAdScript: siteConfig.googleAdClient =', siteConfig.googleAdClient);
    if (siteConfig.googleAdClient && !document.querySelector('script[src*="pagead2.googlesyndication.com"]')) {
      console.log('GoogleAdScript: Adding script');
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${siteConfig.googleAdClient}`;
      script.async = true;
      script.crossOrigin = 'anonymous';
      document.head.appendChild(script);
    }
  }, [siteConfig.googleAdClient]);

  return null;
}

'use client';

import { useState } from 'react';
import { Copy, Check } from 'lucide-react';

export default function MermaidViewer({ chart }: { chart: string }) {
  const [copied, setCopied] = useState(false);
  let imageUrl: string | null = null;
  let error = false;

  if (chart) {
    try {
      const state = { code: chart, mermaid: { theme: 'dark' } };
      // Base64 encode the state safely for unicode
      const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(state))));
      imageUrl = `https://mermaid.ink/img/${encoded}`;
    } catch (e) {
      console.error('Failed to encode mermaid chart:', e);
      error = true;
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(chart).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (error) {
    return <div className="text-red-500 p-4 text-center">Failed to render diagram.</div>;
  }

  if (!imageUrl) {
    return <div className="p-4 text-center text-muted-foreground">Loading diagram...</div>;
  }

  return (
    <div className="relative group">
      <button
        onClick={copyToClipboard}
        className="absolute top-2 right-2 p-2 rounded-lg bg-muted/80 hover:bg-white/20 text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
        title="Copy Mermaid code"
      >
        {copied ? <Check size={16} /> : <Copy size={16} />}
      </button>
      <div className="flex justify-center overflow-x-auto p-4">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {imageUrl && <img src={imageUrl} alt="Mermaid Diagram" className="max-w-full h-auto rounded-lg" />}
      </div>
    </div>
  );
}

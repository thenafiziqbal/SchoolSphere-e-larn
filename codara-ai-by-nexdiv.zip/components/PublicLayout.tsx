'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sparkles, Sun, Moon } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useAppContext } from '@/lib/AppContext';

function NavLink({ href, children }: { href: string, children: React.ReactNode }) {
  return (
    <Link href={href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
      {children}
    </Link>
  );
}

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  const { siteConfig, theme, setTheme } = useAppContext();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-indigo-500/30 overflow-x-hidden flex flex-col">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            {siteConfig.logoUrl || '/logo.svg' ? (
              <Image 
                src={siteConfig.logoUrl || '/logo.svg'} 
                alt={siteConfig.name} 
                width={40} 
                height={40} 
                className="w-10 h-10 object-contain" 
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Sparkles size={20} className="text-white" />
              </div>
            )}
            <div className="flex flex-col">
              <span className="font-bold text-lg md:text-xl tracking-tight text-foreground">{siteConfig.name}</span>
              <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest -mt-1">by NexDiv</span>
            </div>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            {siteConfig.headerLinks.map((link, i) => (
              <NavLink key={i} href={link.href}>{link.label}</NavLink>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2.5 rounded-xl bg-muted/50 hover:bg-muted transition-colors text-foreground border border-border"
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <div className="hidden md:flex items-center gap-4">
              <Link href="/auth/login" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors px-4 py-2">Sign In</Link>
              <Link href="/auth/register" className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-primary/90 transition-all shadow-md shadow-primary/20">
                Get Started
              </Link>
            </div>
            
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2.5 rounded-xl bg-muted/50 hover:bg-muted transition-colors text-foreground border border-border"
            >
              {isMenuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl overflow-hidden"
            >
              <div className="flex flex-col p-6 gap-4">
                {siteConfig.headerLinks.map((link, i) => (
                  <Link 
                    key={i} 
                    href={link.href}
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium text-foreground hover:text-indigo-500 transition-colors"
                  >
                    {link.label}
                  </Link>
                ))}
                <hr className="border-border" />
                <div className="flex flex-col gap-4 pt-2">
                  <Link 
                    href="/auth/login" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Sign In
                  </Link>
                  <Link 
                    href="/auth/register" 
                    onClick={() => setIsMenuOpen(false)}
                    className="bg-primary text-primary-foreground px-6 py-3 rounded-xl text-center font-bold hover:bg-primary/90 transition-all"
                  >
                    Get Started
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="flex-1 pt-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-border bg-background mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            {siteConfig.logoUrl || '/logo.svg' ? (
              <Image 
                src={siteConfig.logoUrl || '/logo.svg'} 
                alt={siteConfig.name} 
                width={40} 
                height={40} 
                className="w-10 h-10 object-contain" 
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <Sparkles size={20} className="text-primary-foreground" />
              </div>
            )}
            <span className="font-bold text-xl tracking-tight text-foreground">{siteConfig.name}</span>
          </div>
          <div className="flex gap-8 text-sm text-muted-foreground">
            {siteConfig.footerLinks?.map((link, i) => (
              <Link key={i} href={link.href} className="hover:text-foreground transition-colors">{link.label}</Link>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">{siteConfig.footerText}</p>
        </div>
      </footer>
    </div>
  );
}

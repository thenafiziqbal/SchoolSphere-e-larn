'use client';

import { useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useAppContext } from '@/lib/AppContext';
import AccessDenied from '@/components/AccessDenied';

export default function RouteGuard({ children }: { children: React.ReactNode }) {
  const { isAdmin, isLoadingAuth } = useAppContext();
  const pathname = usePathname();

  if (isLoadingAuth) return null;

  if (pathname.startsWith('/admin') && !isAdmin) {
    return <AccessDenied />;
  }

  return <>{children}</>;
}

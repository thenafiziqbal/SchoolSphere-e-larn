'use client';

import Image from 'next/image';
import { 
  Upload, 
  LayoutDashboard, 
  History, 
  ShieldCheck, 
  Settings, 
  Sparkles, 
  BarChart3, 
  ShieldAlert, 
  Key, 
  Users, 
  User,
  CreditCard,
  Search,
  Bell,
  FileText
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { useAppContext } from '@/lib/AppContext';

export default function Sidebar() {
  const pathname = usePathname();
  const { analysisResult, isAdmin, subscription, siteConfig, usage } = useAppContext();

  const usagePercentage = subscription.limits.dailyAnalysis > 0 
    ? (usage.dailyCount / subscription.limits.dailyAnalysis) * 100 
    : 0;

  return (
    <aside className="flex w-64 glass-dark z-20 flex-col h-screen shrink-0 border-r border-border">
      <div className="p-6 flex items-center gap-3 border-b border-border">
        {siteConfig.logoUrl || '/logo.svg' ? (
          <Image 
            src={siteConfig.logoUrl || '/logo.svg'} 
            alt={siteConfig.name} 
            width={40} 
            height={40} 
            className="w-10 h-10 object-contain" 
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/20">
            <Sparkles size={20} />
          </div>
        )}
        <div className="flex flex-col">
          <span className="font-bold text-xl tracking-tight text-gradient">{siteConfig.name}</span>
          <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest -mt-1">by NexDiv</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
        <div className="space-y-1">
          <h3 className="px-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">Main</h3>
          <SidebarItem href="/dashboard/analyze" icon={<Upload size={18} />} label="Analyze Repo" active={pathname === '/dashboard/analyze'} />
          <SidebarItem href="/dashboard" icon={<LayoutDashboard size={18} />} label="Dashboard" active={pathname === '/dashboard'} disabled={!analysisResult} />
          <SidebarItem href="/dashboard/docs-generator" icon={<FileText size={18} />} label="Docs Generator" active={pathname === '/dashboard/docs-generator'} />
          <SidebarItem href="/history" icon={<History size={18} />} label="History" active={pathname === '/history'} />
        </div>

        <div className="space-y-1">
          <h3 className="px-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">Insights</h3>
          <SidebarItem href="/analytics" icon={<BarChart3 size={18} />} label="Analytics" active={pathname === '/analytics'} disabled={!analysisResult} />
          <SidebarItem href="/security" icon={<ShieldAlert size={18} />} label="Security Scan" active={pathname === '/security'} disabled={!analysisResult} />
          <SidebarItem href="/dashboard/ai-check" icon={<Sparkles size={18} />} label="AI Code Checker" active={pathname === '/dashboard/ai-check'} />
        </div>

        <div className="space-y-1">
          <h3 className="px-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">Account</h3>
          <SidebarItem href="/profile" icon={<User size={18} />} label="Profile" active={pathname === '/profile'} />
          <SidebarItem href="/billing" icon={<CreditCard size={18} />} label="Billing" active={pathname === '/billing'} />
          <SidebarItem href="/settings" icon={<Settings size={18} />} label="Settings" active={pathname === '/settings'} />
        </div>
      </div>

      <div className="p-4 border-t border-border">
        <div className="bg-gradient-to-br from-indigo-500/10 to-purple-600/10 rounded-2xl p-4 border border-indigo-500/20 space-y-3 shadow-inner">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Current Plan</span>
              <span className="text-xs font-bold text-foreground capitalize">{subscription.plan}</span>
            </div>
            <Link href="/billing" className="px-2 py-1 bg-primary/10 text-[10px] font-bold text-primary rounded-lg uppercase tracking-widest hover:bg-primary hover:text-white transition-all">
              Upgrade
            </Link>
          </div>
          
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
              <span className="text-muted-foreground">Usage</span>
              <span className={usagePercentage > 90 ? 'text-rose-500' : 'text-primary'}>
                {Math.round(usagePercentage)}%
              </span>
            </div>
            <div className="w-full h-2 bg-black/20 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(usagePercentage, 100)}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className={`h-full rounded-full ${
                  usagePercentage > 90 
                    ? 'bg-gradient-to-r from-rose-500 to-red-600' 
                    : 'bg-gradient-to-r from-indigo-500 to-primary'
                }`} 
              />
            </div>
          </div>

          <p className="text-[10px] text-muted-foreground leading-tight">
            <span className="text-foreground font-bold">{usage.dailyCount}</span> of <span className="text-foreground font-bold">{subscription.limits.dailyAnalysis}</span> daily analyses used
          </p>
        </div>
      </div>
    </aside>
  );
}

function SidebarItem({ href, icon, label, active, disabled, className }: { href: string, icon: React.ReactNode, label: string, active?: boolean, disabled?: boolean, className?: string }) {
  if (disabled) {
    return (
      <div className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm font-medium text-muted-foreground opacity-30 cursor-not-allowed ${className}`}>
        {icon}
        {label}
      </div>
    );
  }

  return (
    <Link 
      href={href}
      className={`relative w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 text-sm font-medium group ${
        active 
          ? 'text-primary-foreground' 
          : 'text-muted-foreground hover:text-foreground'
      } ${className}`}
    >
      {active && (
        <motion.div 
          layoutId="sidebar-active"
          className="absolute inset-0 bg-primary shadow-lg shadow-primary/20"
          style={{ borderRadius: '0.75rem' }}
          transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
        />
      )}
      {!active && (
        <div className="absolute inset-0 bg-muted opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl" />
      )}
      <span className="relative z-10 flex items-center gap-3">
        <span className={`${active ? 'text-primary-foreground' : 'text-muted-foreground group-hover:text-primary transition-colors'}`}>
          {icon}
        </span>
        {label}
      </span>
    </Link>
  );
}

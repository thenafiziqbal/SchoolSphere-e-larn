const fs = require('fs');
const path = require('path');

function replaceColors(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  let original = content;

  content = content.replace(/bg-white\/5/g, 'bg-muted');
  content = content.replace(/bg-white\/10/g, 'bg-muted/80');
  content = content.replace(/border-white\/5/g, 'border-border');
  content = content.replace(/border-white\/10/g, 'border-border');
  content = content.replace(/bg-black\/40/g, 'bg-card');
  content = content.replace(/bg-black\/20/g, 'bg-muted');
  content = content.replace(/text-white/g, 'text-foreground');
  
  // Revert specific text-white that should stay white
  content = content.replace(/bg-indigo-600 text-foreground/g, 'bg-indigo-600 text-white');
  content = content.replace(/bg-primary text-foreground/g, 'bg-primary text-primary-foreground');

  if (content !== original) {
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Updated ${filePath}`);
  }
}

function walkDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walkDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      replaceColors(fullPath);
    }
  }
}

walkDir('./app/dashboard');
walkDir('./components');

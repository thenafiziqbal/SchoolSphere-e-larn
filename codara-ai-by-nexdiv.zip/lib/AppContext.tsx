'use client';

import { useState, createContext, useContext, ReactNode, useEffect } from 'react';
import { auth, isFirebaseConfigured, db } from '@/lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, onSnapshot, query, where, deleteDoc, doc, setDoc, getDoc, orderBy } from 'firebase/firestore';

export type AnalysisStep = 'idle' | 'fetching' | 'analyzing' | 'generating_images' | 'finalizing';

interface UserProfile {
  name: string;
  email: string;
  contactNumber?: string;
  website?: string;
  company?: string;
  about?: string;
  avatar?: string;
  socialLinks?: {
    facebook?: string;
    instagram?: string;
    tiktok?: string;
    linkedin?: string;
  };
}

interface Subscription {
  plan: 'free' | 'pro' | 'enterprise';
  status: 'active' | 'expired' | 'canceled';
  expiresAt?: string;
  limits: {
    dailyAnalysis: number;
    monthlyRequests: number;
  };
}

export interface Plan {
  id: 'free' | 'pro' | 'enterprise';
  name: string;
  price: number;
  limits: {
    dailyAnalysis: number;
    monthlyRequests: number;
  };
}

export const PLANS: Record<string, Plan> = {
  free: {
    id: 'free',
    name: 'Free',
    price: 0,
    limits: { dailyAnalysis: 3, monthlyRequests: 100 }
  },
  pro: {
    id: 'pro',
    name: 'Pro',
    price: 2900,
    limits: { dailyAnalysis: 50, monthlyRequests: 5000 }
  },
  enterprise: {
    id: 'enterprise',
    name: 'Enterprise',
    price: 9900,
    limits: { dailyAnalysis: 500, monthlyRequests: 50000 }
  }
};

export interface SubscriptionRequest {
  id?: string;
  userId: string;
  userEmail: string;
  planId: string;
  method: 'bkash' | 'nagad' | 'rocket' | 'binance';
  transactionId: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: any;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
}

export interface Feature {
  id: string;
  title: string;
  description: string;
  iconName: string;
  isPremium: boolean;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[]; // array of feature IDs
  limits: {
    dailyAnalysis: number;
    monthlyRequests: number;
  };
  isPopular?: boolean;
}

interface SiteConfig {
  name: string;
  title: string;
  description: string;
  logoUrl: string;
  footerText: string;
  headerLinks: { label: string; href: string }[];
  footerLinks: { label: string; href: string }[];
  featuresTitle: string;
  featuresSubtitle: string;
  pricingTitle: string;
  pricingSubtitle: string;
  features: Feature[];
  pricingPlans: PricingPlan[];
  heroTitlePrefix: string;
  heroTitleGradient: string;
  heroCtaPrimaryText: string;
  heroCtaPrimaryHref: string;
  heroCtaSecondaryText: string;
  heroCtaSecondaryHref: string;
  previewUrl: string;
  previewSidebarText: string;
  previewMainTitle: string;
  previewMainImage: string;
  faviconUrl: string;
  hero3dImageUrl: string;
  galleryImages: { url: string; isVisible: boolean }[];
  googleAdClient?: string;
  googleAdSlot?: string;
  paymentNumbers: {
    bkash: string;
    nagad: string;
    rocket: string;
    binance?: string;
  };
  usdExchangeRate: number;
  binancePayLink: string;
  binanceInstructions: string[];
  enableEmailNotifications: boolean;
  adminNotificationEmail: string;
}

export interface ApiKeyData {
  id: string;
  provider: string;
  key: string;
  status: string;
}

interface AppContextType {
  // Auth & Profile
  user: UserProfile | null;
  setUser: (user: UserProfile | null) => void;
  subscription: Subscription;
  setSubscription: (sub: Subscription) => void;
  
  // AI & Analysis
  apiKeys: ApiKeyData[];
  setApiKeys: (keys: ApiKeyData[]) => void;
  currentKeyIndex: number;
  setCurrentKeyIndex: (index: number) => void;
  analysisResult: any;
  setAnalysisResult: (result: any) => void;
  analysisStep: AnalysisStep;
  setAnalysisStep: (step: AnalysisStep) => void;
  
  // History & Data
  analyses: any[];
  setAnalyses: (analyses: any[]) => void;
  removeAnalysis: (id: string) => void;
  
  // UI & Settings
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  notifications: Notification[];
  addNotification: (notif: Omit<Notification, 'id' | 'createdAt' | 'read'>) => void;
  markAsRead: (id: string) => void;
  
  siteConfig: SiteConfig;
  updateSiteConfig: (config: Partial<SiteConfig>) => Promise<void>;
  
  usage: {
    dailyCount: number;
    monthlyCount: number;
  };
  incrementUsage: () => Promise<boolean>;
  checkFeatureAccess: (featureId: string) => boolean;
  submitSubscriptionRequest: (data: Omit<SubscriptionRequest, 'userId' | 'userEmail' | 'status' | 'createdAt'>) => Promise<void>;

  isAdmin: boolean;
  isLoadingAuth: boolean;
  userRequests: SubscriptionRequest[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(() => {
    if (!isFirebaseConfigured) {
      return {
        name: 'John Developer',
        email: 'john@example.com',
        company: 'NexDiv Tech',
        website: 'https://nexdiv.com'
      };
    }
    return null;
  });
  const [isLoadingAuth, setIsLoadingAuth] = useState(isFirebaseConfigured);
  
  useEffect(() => {
    if (isFirebaseConfigured && auth) {
      const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
        if (firebaseUser) {
          setUser({
            name: firebaseUser.displayName || 'User',
            email: firebaseUser.email || '',
          });
        } else {
          setUser(null);
        }
        setIsLoadingAuth(false);
      });
      return () => unsubscribe();
    }
  }, []);
  
  const [subscription, setSubscription] = useState<Subscription>({
    plan: 'free',
    status: 'active',
    limits: PLANS.free.limits
  });

  const [usage, setUsage] = useState({
    dailyCount: 0,
    monthlyCount: 0
  });

  // Fetch User Subscription & Usage from Firestore
  useEffect(() => {
    if (isFirebaseConfigured && db && auth?.currentUser) {
      const userDocRef = doc(db, 'users', auth.currentUser.uid);
      const unsubscribe = onSnapshot(userDocRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          if (data.subscription) setSubscription(data.subscription);
          if (data.usage) setUsage(data.usage);
        }
      });
      return () => unsubscribe();
    }
  }, [user]);

  const submitSubscriptionRequest = async (data: Omit<SubscriptionRequest, 'userId' | 'userEmail' | 'status' | 'createdAt'>) => {
    if (!isFirebaseConfigured || !db || !auth?.currentUser) return;

    const request: SubscriptionRequest = {
      ...data,
      userId: auth.currentUser.uid,
      userEmail: auth.currentUser.email || '',
      status: 'pending',
      createdAt: new Date()
    };

    await setDoc(doc(collection(db, 'subscriptionRequests')), request);
    addNotification({
      title: 'Request Submitted',
      message: `Your ${data.planId} plan request is being verified.`,
      type: 'info'
    });
  };

  const [apiKeys, setApiKeys] = useState<ApiKeyData[]>([]);
  const [currentKeyIndex, setCurrentKeyIndex] = useState(0);

  // Fetch API Keys from Firestore
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      const q = query(collection(db, 'apiKeys'), where('status', '==', 'Active'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const keys = snapshot.docs.map(doc => ({
          id: doc.id,
          provider: doc.data().provider || 'Google Gemini',
          key: doc.data().key,
          status: doc.data().status
        }));
        setApiKeys(keys);
      });
      return () => unsubscribe();
    }
  }, []);

  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [analysisStep, setAnalysisStep] = useState<AnalysisStep>('idle');
  const [analyses, setAnalyses] = useState<any[]>([]);

  // Fetch Analyses from Firestore
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      const unsubscribe = onSnapshot(collection(db, 'analyses'), (snapshot) => {
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          date: doc.data().createdAt?.toDate ? doc.data().createdAt.toDate().toLocaleDateString() : 'Just now'
        }));
        setAnalyses(data);
      });
      return () => unsubscribe();
    }
  }, []);

  const removeAnalysis = async (id: string) => {
    if (isFirebaseConfigured && db) {
      try {
        await deleteDoc(doc(db, 'analyses', id));
      } catch (e) {
        console.error("Failed to delete analysis", e);
      }
    } else {
      setAnalyses(prev => prev.filter(a => a.id !== id));
    }
  };

  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: 'n1', title: 'Analysis Complete', message: 'Your analysis for codara-core is ready.', type: 'success', read: false, createdAt: '2026-03-10T12:00:00Z' },
    { id: 'n2', title: 'New Feature', message: 'Architecture mapping now supports Mermaid v10.', type: 'info', read: true, createdAt: '2026-03-09T12:00:00Z' },
  ]);
  
  const isAdmin = user?.email === 'nafizofe8@gmail.com';

  const [userRequests, setUserRequests] = useState<SubscriptionRequest[]>([]);

  // Fetch User Subscription Requests from Firestore
  useEffect(() => {
    if (isFirebaseConfigured && db && auth?.currentUser) {
      const q = query(
        collection(db, 'subscriptionRequests'), 
        where('userId', '==', auth.currentUser.uid)
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as SubscriptionRequest[];
        
        // Sort client-side to avoid composite index requirement
        const sortedData = [...data].sort((a, b) => {
          const getTime = (val: any) => {
            if (!val) return 0;
            if (val.toMillis) return val.toMillis();
            if (val.seconds) return val.seconds * 1000;
            return new Date(val).getTime();
          };
          return getTime(b.createdAt) - getTime(a.createdAt);
        });
        
        setUserRequests(sortedData);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const addNotification = (notif: Omit<Notification, 'id' | 'createdAt' | 'read'>) => {
    const newNotif: Notification = {
      ...notif,
      id: Math.random().toString(36).substring(7),
      createdAt: new Date().toISOString(),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  // Sync theme with document
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const [siteConfig, setSiteConfig] = useState<SiteConfig>({
    name: 'Codara AI',
    title: 'Project Intelligence',
    description: 'AI-driven code analysis and architecture mapping.',
    logoUrl: '/logo.svg',
    footerText: '© 2026 Codara AI. All rights reserved.',
    headerLinks: [
      { label: 'Documentation', href: '/docs' },
      { label: 'Support', href: '/support' }
    ],
    footerLinks: [
      { label: 'Privacy Policy', href: '/privacy' },
      { label: 'Terms of Service', href: '/terms' },
      { label: 'Contact', href: '/contact' }
    ],
    featuresTitle: 'Everything you need to ship faster',
    featuresSubtitle: 'Powerful tools to understand, document, and improve your codebase.',
    pricingTitle: 'Simple, transparent pricing',
    pricingSubtitle: 'Choose the perfect plan for your needs. No hidden fees.',
    features: [
      { id: 'f1', title: 'Automated Documentation', description: 'Generate comprehensive READMEs, function docs, and API references directly from your source code.', iconName: 'Code2', isPremium: false },
      { id: 'f2', title: 'Architecture Mapping', description: 'Visualize your system structure with automatically generated architecture and data flow diagrams.', iconName: 'GitBranch', isPremium: true },
      { id: 'f3', title: 'Security & Bug Analysis', description: 'Identify vulnerabilities and logical bugs before they reach production with our advanced AI scanner.', iconName: 'ShieldAlert', isPremium: true },
      { id: 'f4', title: 'Code Health Scoring', description: 'Get instant insights into your project\'s quality, security, and documentation completeness.', iconName: 'BarChart3', isPremium: false },
      { id: 'f5', title: 'Multi-Language Support', description: 'Native support for JavaScript, TypeScript, Python, Java, Go, C++, and more.', iconName: 'Terminal', isPremium: false },
      { id: 'f6', title: 'Enterprise Security', description: 'Your code is processed securely and never stored. We prioritize your data privacy and security.', iconName: 'ShieldCheck', isPremium: true }
    ],
    pricingPlans: [
      { id: 'free', name: 'Free', price: 0, description: 'Perfect for side projects and open source.', features: ['f1', 'f4', 'f5'], limits: { dailyAnalysis: 3, monthlyRequests: 100 } },
      { id: 'pro', name: 'Pro', price: 29, description: 'For professional developers and small teams.', features: ['f1', 'f2', 'f3', 'f4', 'f5'], limits: { dailyAnalysis: 50, monthlyRequests: 5000 }, isPopular: true },
      { id: 'enterprise', name: 'Enterprise', price: 99, description: 'Custom solutions for large organizations.', features: ['f1', 'f2', 'f3', 'f4', 'f5', 'f6'], limits: { dailyAnalysis: 500, monthlyRequests: 50000 } }
    ],
    heroTitlePrefix: 'Automate Your Repository',
    heroTitleGradient: 'Intelligence',
    heroCtaPrimaryText: 'Start Analyzing Free',
    heroCtaPrimaryHref: '/dashboard/analyze',
    heroCtaSecondaryText: 'View on GitHub',
    heroCtaSecondaryHref: 'https://github.com',
    previewUrl: 'codara.ai/dashboard',
    previewSidebarText: 'Project Overview',
    previewMainTitle: 'Developer Intelligence Dashboard',
    previewMainImage: 'https://picsum.photos/seed/dashboard/800/600',
    faviconUrl: '/logo.png',
    hero3dImageUrl: 'https://picsum.photos/seed/3d/800/800',
    galleryImages: [
      { url: 'https://picsum.photos/seed/img1/800/600', isVisible: true },
      { url: 'https://picsum.photos/seed/img2/800/600', isVisible: true }
    ],
    paymentNumbers: {
      bkash: '017XXXXXXXX',
      nagad: '017XXXXXXXX',
      rocket: '017XXXXXXXX'
    },
    usdExchangeRate: 120,
    binancePayLink: '',
    binanceInstructions: [
      'Open your Binance App',
      'Go to Pay section',
      'Enter the Pay ID or scan the QR code',
      'Enter the amount in USD',
      'Complete the payment and save the Transaction ID'
    ],
    enableEmailNotifications: false,
    adminNotificationEmail: ''
  });

  // Fetch Site Config from Firestore
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      const unsubscribe = onSnapshot(doc(db, 'settings', 'site'), (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as SiteConfig;
          setSiteConfig(prev => ({ ...prev, ...data }));
        }
      });
      return () => unsubscribe();
    }
  }, []);

  // Fetch Pricing Plans (Packages) from Firestore
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      const unsubscribe = onSnapshot(collection(db, 'packages'), (snapshot) => {
        const plans = snapshot.docs
          .map(doc => ({ id: doc.id, ...doc.data() } as any))
          .filter(p => p.status === 'Active')
          .map(p => ({
            id: p.id,
            name: p.name,
            price: p.price,
            description: p.description || '',
            features: p.features || [],
            limits: p.limits || { dailyAnalysis: 0, monthlyRequests: 0 },
            isPopular: p.isPopular || false
          }));
        
        setSiteConfig(prev => ({ ...prev, pricingPlans: plans }));
      });
      return () => unsubscribe();
    }
  }, []);

  const updateSiteConfig = async (config: Partial<SiteConfig>) => {
    const newConfig = { ...siteConfig, ...config };
    setSiteConfig(newConfig);
    if (isFirebaseConfigured && db) {
      await setDoc(doc(db, 'settings', 'site'), newConfig, { merge: true });
    }
  };

  const incrementUsage = async () => {
    if (usage.dailyCount >= subscription.limits.dailyAnalysis) {
      return false;
    }
    
    const newUsage = {
      ...usage,
      dailyCount: usage.dailyCount + 1,
      monthlyCount: usage.monthlyCount + 1
    };
    
    setUsage(newUsage);
    
    if (isFirebaseConfigured && db && auth?.currentUser) {
      await setDoc(doc(db, 'users', auth.currentUser.uid), { usage: newUsage }, { merge: true });
    }
    
    return true;
  };

  const checkFeatureAccess = (featureId: string) => {
    const plan = siteConfig.pricingPlans.find(p => p.id === subscription.plan);
    if (!plan) return false;
    return plan.features.includes(featureId);
  };

  return (
    <AppContext.Provider value={{ 
      user, setUser,
      subscription, setSubscription,
      apiKeys, setApiKeys, 
      currentKeyIndex, setCurrentKeyIndex, 
      analysisResult, setAnalysisResult,
      analysisStep, setAnalysisStep,
      analyses, setAnalyses, removeAnalysis,
      theme, setTheme,
      notifications, addNotification, markAsRead,
      siteConfig, updateSiteConfig,
      usage, incrementUsage, checkFeatureAccess, submitSubscriptionRequest,
      isAdmin, isLoadingAuth, userRequests
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within AppProvider');
  return context;
}

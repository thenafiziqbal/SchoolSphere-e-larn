export enum Type {
  TYPE_UNSPECIFIED = "TYPE_UNSPECIFIED",
  STRING = "STRING",
  NUMBER = "NUMBER",
  INTEGER = "INTEGER",
  BOOLEAN = "BOOLEAN",
  ARRAY = "ARRAY",
  OBJECT = "OBJECT",
  NULL = "NULL",
}

export interface ApiKeyData {
  id?: string;
  provider: string;
  key: string;
  status?: string;
}

export async function generateAIContent(
  prompt: string, 
  apiKeys: ApiKeyData[], 
  systemInstruction?: string,
  responseSchema?: any
): Promise<any> {
  if (!apiKeys || apiKeys.length === 0) {
    throw new Error("No API keys available.");
  }

  let lastError: any = null;

  for (const apiKey of apiKeys) {
    if (apiKey.status === 'Disabled') continue;

    try {
      if (apiKey.provider === 'Google Gemini') {
        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey.key}`;
        
        const payload: any = {
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            thinkingConfig: { thinkingLevel: 'LOW' }
          }
        };

        if (systemInstruction) {
          payload.systemInstruction = { parts: [{ text: systemInstruction }] };
        }

        if (responseSchema) {
          payload.generationConfig.responseMimeType = 'application/json';
          payload.generationConfig.responseSchema = responseSchema;
        }

        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`Google Gemini error: ${res.status} ${errText}`);
        }

        const data = await res.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
        
        if (responseSchema) {
          try {
            return JSON.parse(text);
          } catch (e) {
            const match = text.match(/```json\n([\s\S]*?)\n```/);
            if (match) return JSON.parse(match[1]);
            throw new Error("Failed to parse JSON from response");
          }
        }
        return text;
      } 
      else if (apiKey.provider === 'Groq' || apiKey.provider === 'OpenRouter' || apiKey.provider === 'OpenAI') {
        let endpoint = '';
        let model = '';
        
        if (apiKey.provider === 'Groq') {
          endpoint = 'https://api.groq.com/openai/v1/chat/completions';
          model = 'llama3-70b-8192';
        } else if (apiKey.provider === 'OpenRouter') {
          endpoint = 'https://openrouter.ai/api/v1/chat/completions';
          model = 'google/gemini-2.5-flash'; // Default fast model
        } else if (apiKey.provider === 'OpenAI') {
          endpoint = 'https://api.openai.com/v1/chat/completions';
          model = 'gpt-4o-mini';
        }

        let finalPrompt = prompt;
        if (responseSchema) {
          const isArray = responseSchema.type === Type.ARRAY || responseSchema.type === 'ARRAY';
          finalPrompt += `\n\nYou MUST return ONLY a valid JSON ${isArray ? 'array' : 'object'} that matches this schema:\n${JSON.stringify(responseSchema, null, 2)}`;
        }

        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey.key}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: model,
            messages: [
              ...(systemInstruction ? [{ role: 'system', content: systemInstruction }] : []),
              { role: 'user', content: finalPrompt }
            ]
          })
        });

        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`${apiKey.provider} error: ${res.status} ${errText}`);
        }
        
        const data = await res.json();
        const text = data.choices[0].message.content;
        
        if (responseSchema) {
          try {
            return JSON.parse(text);
          } catch (e) {
            // Sometimes models wrap json in markdown blocks
            const match = text.match(/```json\n([\s\S]*?)\n```/);
            if (match) {
              return JSON.parse(match[1]);
            }
            throw new Error("Failed to parse JSON from response");
          }
        }
        return text;
      }
    } catch (error: any) {
      console.warn(`Failed with provider ${apiKey.provider}:`, error);
      lastError = error;
      // Continue to the next key
      continue;
    }
  }

  throw new Error(`All API keys failed. Last error: ${lastError?.message || 'Unknown error'}`);
}

export async function generateAIImage(prompt: string, apiKeys: ApiKeyData[]): Promise<string | null> {
  if (!apiKeys || apiKeys.length === 0) return null;

  for (const apiKey of apiKeys) {
    if (apiKey.status === 'Disabled') continue;

    try {
      if (apiKey.provider === 'Google Gemini') {
        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=${apiKey.key}`;
        
        const payload = {
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            imageConfig: { aspectRatio: "16:9" }
          }
        };

        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`Google Gemini Image error: ${res.status} ${errText}`);
        }

        const data = await res.json();
        for (const part of data.candidates?.[0]?.content?.parts || []) {
          if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
      // Other providers for image generation can be added here
      // For now, if it's not Gemini, we just skip image generation or use a fallback
    } catch (error) {
      console.warn(`Image generation failed with provider ${apiKey.provider}:`, error);
      continue;
    }
  }
  return null;
}

// lib/api-key-rotation.ts

interface APIKey {
  id: string;
  provider: 'openai' | 'gemini' | 'claude';
  key: string;
  usageCount: number;
  quotaLimit: number;
  status: 'active' | 'exhausted' | 'disabled';
}

// In-memory store for demonstration. In production, use MongoDB.
let apiKeys: APIKey[] = [
  { id: '1', provider: 'gemini', key: 'AIzaSyDasDqgoDxUZsfVOHP3KGRKwv4NS77eGDk', usageCount: 0, quotaLimit: 1000, status: 'active' },
];

export class KeyRotationService {
  static async getActiveKey(provider: string): Promise<APIKey> {
    const activeKeys = apiKeys.filter(k => k.provider === provider && k.status === 'active');
    
    if (activeKeys.length === 0) {
      throw new Error('No active keys available for provider: ' + provider);
    }

    // Simple rotation: get key with lowest usage
    return activeKeys.sort((a, b) => a.usageCount - b.usageCount)[0];
  }

  static async incrementUsage(keyId: string): Promise<void> {
    const key = apiKeys.find(k => k.id === keyId);
    if (key) {
      key.usageCount += 1;
      if (key.usageCount >= key.quotaLimit) {
        key.status = 'exhausted';
      }
    }
  }
}

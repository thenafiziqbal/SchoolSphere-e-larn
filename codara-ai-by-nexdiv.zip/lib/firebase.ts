import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyDN7SB77akt3hVTbXEGbLSFnufDgfKhIi4",
  authDomain: "edu1-4a91f.firebaseapp.com",
  databaseURL: "https://edu1-4a91f-default-rtdb.firebaseio.com",
  projectId: "edu1-4a91f",
  storageBucket: "edu1-4a91f.firebasestorage.app",
  messagingSenderId: "99164691896",
  appId: "1:99164691896:web:23973a25f587a43be8834d",
  measurementId: "G-L8ZMHENZLV"
};

// Only initialize if we have an API key
const isFirebaseConfigured = true;

const app = isFirebaseConfigured 
  ? (getApps().length > 0 ? getApp() : initializeApp(firebaseConfig))
  : null;

const db = app ? getFirestore(app) : null;
const auth = app ? getAuth(app) : null;

export { app, db, auth, isFirebaseConfigured };
